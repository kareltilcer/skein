// Library · "New …" creation flows
// Reached from the Library (screen 07) when the user taps the full-width
// "New {pattern|sequence|row}" CTA on the matching tab. Each is a full-screen
// "definer" — same chrome as the Custom-stitch screen (X · draft pill · Save,
// big display title, a LIVE PREVIEW of the library tile being built, then the
// builder itself) — shown mid-creation so the working surface reads clearly.
//
//   New Row      → atomic: a single line of stitches, with a stitch dock.
//   New Sequence → a stack of rows, each its own line of stitches.
//   New Pattern  → parts, each holding several sequences (no stitch dock —
//                  at this altitude you assemble sequences, not stitches).

// Stitch → accent color, matching the rhythm used across the app's charts.
function lcStitchColor(id, t) {
  if (['k', 'sl', 'kfb', 'm1'].includes(id)) return t.brick;
  if (['p', 'p2tog', 'mb'].includes(id)) return t.mustard;
  return t.forest;
}

// ─── Shared chrome ──────────────────────────────────────────
function LCTopBar({ kind, ready, dark }) {
  const t = pickT(dark);
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', minHeight: 36 }}>
      <IconBtn name="x" dark={dark}/>
      <div style={{
        fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.2em',
        textTransform: 'uppercase', padding: '4px 10px', borderRadius: 999,
        background: t.cream2, border: `1px solid ${t.rule}`,
      }}>{kind} · draft</div>
      <button style={{
        background: 'transparent', border: 'none', cursor: ready ? 'pointer' : 'not-allowed',
        color: ready ? t.brick : t.inkMute, fontFamily: FontBody, fontWeight: 700, fontSize: 14,
        padding: '6px 4px', letterSpacing: '-0.005em',
      }}>Save</button>
    </div>
  );
}

function LCHeader({ title, sub, dark }) {
  const t = pickT(dark);
  return (
    <div style={{ marginTop: 8 }}>
      <div style={{ fontFamily: FontDisplay, fontSize: 32, color: t.brick, letterSpacing: '-0.01em', lineHeight: 1 }}>{title}</div>
      <div style={{ fontSize: 13.5, color: t.inkSoft, marginTop: 6, lineHeight: 1.4 }}>{sub}</div>
    </div>
  );
}

function LCLabel({ children, hint, dark }) {
  const t = pickT(dark);
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 8 }}>
      <div style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute, letterSpacing: '0.18em', textTransform: 'uppercase' }}>{children}</div>
      {hint && <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.04em' }}>{hint}</div>}
    </div>
  );
}

// Name input + knit/crochet toggle — the shared identity block for all three.
function LCIdentity({ name, placeholder, craft, dark }) {
  const t = pickT(dark);
  const fieldStyle = {
    width: '100%', background: t.card, border: `1.5px solid ${name ? t.brick : t.rule}`, borderRadius: 12,
    padding: '12px 14px', fontFamily: FontBody, fontSize: 16, color: name ? t.ink : t.inkMute, outline: 'none',
    letterSpacing: '-0.005em', boxSizing: 'border-box',
  };
  return (
    <div style={{ marginTop: 22 }}>
      <LCLabel dark={dark} hint="shown in your library">Name &amp; craft</LCLabel>
      <div style={fieldStyle}>{name || placeholder}{name && <span style={{ display: 'inline-block', width: 2, height: 18, background: t.brick, marginLeft: 2, transform: 'translateY(3px)' }}/>}</div>
      <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
        {[
          { id: 'knit', label: 'Knit', icon: 'needle' },
          { id: 'crochet', label: 'Crochet', icon: 'loop' },
        ].map(c => {
          const active = craft === c.id;
          return (
            <div key={c.id} style={{
              flex: 1, padding: '11px 14px', borderRadius: 12,
              background: active ? t.brick : t.card,
              color: active ? '#FBF6EC' : t.ink,
              border: active ? 'none' : `1px solid ${t.rule}`,
              fontFamily: FontBody, fontSize: 14.5, fontWeight: 700,
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              letterSpacing: '-0.005em', cursor: 'pointer',
            }}>
              <Icon name={c.icon} size={16} color={active ? '#FBF6EC' : t.brick}/>
              {c.label}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// A single chart cell — glyph + abbreviation. `active` = just-tapped highlight.
function LCChartCell({ id, dark, active = false }) {
  const t = pickT(dark);
  const s = Stitches.find(s => s.id === id);
  if (!s) return null;
  const c = lcStitchColor(id, t);
  return (
    <div style={{
      width: 30, height: 40, borderRadius: 7,
      background: active ? c : t.cream2,
      border: `1.4px solid ${c}`,
      boxShadow: active ? `0 4px 10px -4px ${c}` : 'none',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2,
    }}>
      <StitchGlyph symbol={s.symbol} color={active ? '#FBF6EC' : c} size={15} stroke={1.9}/>
      <div style={{ fontFamily: FontMono, fontSize: 7.5, fontWeight: 700, color: active ? '#FBF6EC' : c, lineHeight: 1 }}>{s.abbr}</div>
    </div>
  );
}

// Pinned stitch dock — the tap-to-add surface for Row + Sequence builders.
function LCStitchDock({ target, dark }) {
  const t = pickT(dark);
  const quick = ['k', 'p', 'yo', 'k2tog', 'ssk', 'sl'];
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      background: t.bg, borderTop: `1px solid ${t.rule}`,
      padding: '10px 20px 28px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
        <div style={{ fontFamily: FontMono, fontSize: 10, color: t.brick, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase' }}>Tap to add to {target} ✱</div>
        <div style={{ color: t.brick, fontSize: 11, fontFamily: FontMono, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 4 }}>
          All 30 stitches <Icon name="chevR" size={12} color={t.brick}/>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 6 }}>
        {quick.map((id) => {
          const s = Stitches.find(s => s.id === id);
          const c = lcStitchColor(id, t);
          return (
            <div key={id} style={{
              flex: 1, background: t.card, border: `1px solid ${t.rule}`, borderRadius: 10,
              padding: '6px 0', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            }}>
              <div style={{
                width: 28, height: 28, borderRadius: 8, background: c,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <StitchGlyph symbol={s.symbol} color="#FBF6EC" size={16}/>
              </div>
              <div style={{ fontSize: 9.5, fontFamily: FontMono, color: t.inkSoft, fontWeight: 700 }}>{s.abbr}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// Dashed "new / from library" pair — mirrors ReuseChooser from the setup wizard.
function LCReuseChooser({ kind, count, dark }) {
  const t = pickT(dark);
  const libLabel = kind === 'row' ? 'Row from lib' : 'Seq. from lib';
  return (
    <div style={{ display: 'flex', gap: 8 }}>
      <div style={{
        flex: 1.1, background: 'transparent', border: `1.5px dashed ${t.brick}`, color: t.brick,
        padding: '12px', borderRadius: 14, fontFamily: FontBody, fontSize: 13, fontWeight: 700, cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      }}>
        <Icon name="plus" size={14} color={t.brick}/> New {kind}
      </div>
      <div style={{
        flex: 1, background: t.card, border: `1px solid ${t.rule}`, color: t.ink,
        padding: '12px', borderRadius: 14, fontFamily: FontBody, fontSize: 13, fontWeight: 600, cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      }}>
        <Icon name="library" size={14} color={t.mustardDk}/>
        {libLabel}
        <span style={{
          fontFamily: FontMono, fontSize: 10, color: t.inkMute, fontWeight: 700,
          background: t.cream2, padding: '1px 6px', borderRadius: 6,
        }}>{count}</span>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════
// 1 · NEW ROW — atomic stitch builder
// ════════════════════════════════════════════════════════════
function NewRowScreen({ dark = false }) {
  const t = pickT(dark);
  // Mid-creation snapshot: "Eyelet rib" being typed out stitch by stitch.
  const name = 'Eyelet rib';
  const stitches = ['k', 'p', 'yo', 'k2tog', 'p', 'k'];
  const notation = 'k1, p1, yo, k2tog, p1, k1';
  const activeIdx = stitches.length - 1;

  return (
    <Phone dark={dark}>
      <div style={{ padding: '8px 20px 4px' }}>
        <LCTopBar kind="Row" ready dark={dark}/>
        <LCHeader title="New row" sub="A single line of stitches — saved once, reused across every project." dark={dark}/>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '14px 20px 150px' }}>

        {/* LIVE PREVIEW — exactly the tile that lands in the Rows tab */}
        <div style={{
          background: t.card, borderRadius: 18, padding: 14,
          border: `1.5px solid ${t.brick}`, boxShadow: `0 8px 22px -16px ${t.brick}`,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.18em', textTransform: 'uppercase' }}>Live preview</div>
            <div style={{ position: 'relative' }}>
              <div style={{
                fontFamily: FontMono, fontWeight: 700, fontSize: 9, color: t.ink, background: t.mustard,
                padding: '3px 7px', borderRadius: 6, letterSpacing: '0.08em',
              }}>NEW · {stitches.length} STS</div>
            </div>
          </div>
          <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 15.5, color: t.ink, letterSpacing: '-0.005em' }}>{name}</div>
          <div style={{ display: 'flex', gap: 3, marginTop: 8, flexWrap: 'wrap' }}>
            {stitches.map((id, i) => {
              const s = Stitches.find(s => s.id === id);
              const c = lcStitchColor(id, t);
              return (
                <div key={i} style={{
                  width: 22, height: 26, borderRadius: 6, background: t.cream2,
                  border: `1.2px solid ${c}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <StitchGlyph symbol={s.symbol} color={c} size={12} stroke={1.8}/>
                </div>
              );
            })}
          </div>
          <div style={{ marginTop: 8, fontFamily: FontMono, fontSize: 11, color: t.inkMute }}>{notation}</div>
        </div>

        <LCIdentity name={name} placeholder="e.g. Eyelet rib" craft="knit" dark={dark}/>

        {/* THE BUILDER — chart strip of stitches laid down so far */}
        <div style={{ marginTop: 22 }}>
          <LCLabel dark={dark} hint={`${stitches.length} stitches`}>Build the row</LCLabel>
          <div style={{
            background: t.cream2, border: `1px solid ${t.rule}`, borderRadius: 16, padding: 12,
          }}>
            <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
              {stitches.map((id, i) => (
                <LCChartCell key={i} id={id} dark={dark} active={i === activeIdx}/>
              ))}
              {/* caret / next-slot affordance */}
              <div style={{
                width: 30, height: 40, borderRadius: 7, border: `1.5px dashed ${t.brick}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: 0.8,
              }}>
                <div style={{ width: 2, height: 20, background: t.brick }}/>
              </div>
            </div>
            {/* row toolbar — mark repeat / backspace / clear */}
            <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
              {[
                { icon: 'repeat', label: 'Mark repeat' },
                { icon: 'backspace', label: 'Undo last' },
              ].map(b => (
                <div key={b.label} style={{
                  display: 'inline-flex', alignItems: 'center', gap: 6, padding: '7px 12px',
                  background: t.card, border: `1px solid ${t.rule}`, borderRadius: 10,
                  fontFamily: FontBody, fontSize: 12, fontWeight: 600, color: t.inkSoft, cursor: 'pointer',
                }}>
                  <Icon name={b.icon} size={14} color={t.inkSoft}/>{b.label}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* NOTATION — written read-out, auto-generated as you tap */}
        <div style={{ marginTop: 22 }}>
          <LCLabel dark={dark} hint="auto · editable">Written as</LCLabel>
          <div style={{
            background: t.card, border: `1px solid ${t.rule}`, borderRadius: 12, padding: '12px 14px',
            fontFamily: FontMono, fontSize: 13.5, color: t.ink, letterSpacing: '0.01em',
          }}>{notation}<span style={{ color: t.inkMute }}> — rep to end</span></div>
          <div style={{ marginTop: 6, fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.04em' }}>
            We write it for you. Tap to fix a word if your shorthand differs.
          </div>
        </div>

        <div style={{
          marginTop: 24, textAlign: 'center', fontFamily: FontMono, fontSize: 10, color: t.inkMute,
          letterSpacing: '0.18em', textTransform: 'uppercase',
        }}>✻ one row, endlessly reusable ✻</div>
      </div>

      <LCStitchDock target="this row" dark={dark}/>
    </Phone>
  );
}

// ════════════════════════════════════════════════════════════
// 2 · NEW SEQUENCE — a stack of rows
// ════════════════════════════════════════════════════════════
function NewSequenceScreen({ dark = false }) {
  const t = pickT(dark);
  const name = 'Moss stitch panel';
  const accent = t.forest;
  const rows = [
    { label: 'Row 1', stitches: ['k', 'p', 'k', 'p', 'k', 'p', 'k', 'p'] },
    { label: 'Row 2', stitches: ['p', 'k', 'p', 'k', 'p', 'k', 'p', 'k'], active: true },
    { label: 'Row 3', stitches: [] },
  ];
  const swatch = ['vline', 'dash', 'dash', 'vline'];

  return (
    <Phone dark={dark}>
      <div style={{ padding: '8px 20px 4px' }}>
        <LCTopBar kind="Sequence" ready dark={dark}/>
        <LCHeader title="New sequence" sub="A stack of rows — a rib, a body, a border — saved together as one block." dark={dark}/>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '14px 20px 200px' }}>

        {/* LIVE PREVIEW — the Sequences-tab tile */}
        <div style={{
          background: t.card, borderRadius: 18, padding: 14,
          border: `1.5px solid ${t.brick}`, boxShadow: `0 8px 22px -16px ${t.brick}`,
          display: 'flex', gap: 12, alignItems: 'center',
        }}>
          <div style={{
            width: 52, height: 52, borderRadius: 12, background: accent,
            display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 2, padding: 6, flexShrink: 0,
          }}>
            {swatch.map((sym, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <StitchGlyph symbol={sym} color="#FBF6EC" size={15} stroke={1.8}/>
              </div>
            ))}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.18em', textTransform: 'uppercase' }}>Live preview</div>
            <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 15.5, color: t.ink, marginTop: 3, letterSpacing: '-0.005em' }}>{name}</div>
            <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, marginTop: 3 }}>2 rows · 1 in progress</div>
          </div>
        </div>

        <LCIdentity name={name} placeholder="e.g. Moss stitch panel" craft="knit" dark={dark}/>

        {/* THE ROWS — stacked, the active one targeted by the dock */}
        <div style={{ marginTop: 22 }}>
          <LCLabel dark={dark} hint="3 rows">Rows in this sequence</LCLabel>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingLeft: 10, borderLeft: `2px solid ${t.cream2}`, marginLeft: 6 }}>
            {rows.map((row, ri) => {
              const empty = row.stitches.length === 0;
              return (
                <div key={ri} style={{
                  background: t.card, border: row.active ? `2px solid ${t.brick}` : `1px solid ${t.rule}`,
                  borderRadius: 14, padding: '10px 12px',
                  boxShadow: row.active ? `0 0 0 4px ${dark ? 'rgba(255,122,77,0.10)' : 'rgba(156,61,46,0.07)'}` : 'none',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: empty ? 0 : 10, gap: 8 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
                      <Icon name="grip" size={14} color={t.inkMute}/>
                      <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 13, color: row.active ? t.brick : t.ink }}>{row.label}{row.active && ' ✱'}</div>
                      <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute }}>· {row.stitches.length} sts</div>
                    </div>
                    <Icon name="more" size={16} color={t.inkMute}/>
                  </div>
                  {!empty ? (
                    <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
                      {row.stitches.map((id, i) => {
                        const s = Stitches.find(s => s.id === id);
                        const c = lcStitchColor(id, t);
                        return (
                          <div key={i} style={{
                            width: 26, height: 34, borderRadius: 6, background: t.cream2, border: `1.2px solid ${c}`,
                            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 1,
                          }}>
                            <StitchGlyph symbol={s.symbol} color={c} size={13} stroke={1.8}/>
                            <div style={{ fontFamily: FontMono, fontSize: 7, color: c, fontWeight: 700, lineHeight: 1 }}>{s.abbr}</div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, fontStyle: 'italic', padding: '6px 0 2px' }}>
                      empty · tap a stitch below to start filling
                    </div>
                  )}
                </div>
              );
            })}
            <div style={{ marginTop: 2 }}>
              <LCReuseChooser kind="row" count={28} dark={dark}/>
            </div>
          </div>
        </div>

        <div style={{
          marginTop: 16, padding: '10px 12px', background: t.cream2, borderRadius: 12,
          fontSize: 12, color: t.inkSoft, display: 'flex', gap: 8, alignItems: 'flex-start',
        }}>
          <Icon name="bulb" size={14} color={t.mustardDk}/>
          <span><b style={{ color: t.ink }}>Tip:</b> Tap any row to focus it — the stitch dock fills that row.</span>
        </div>
      </div>

      <LCStitchDock target="Row 2" dark={dark}/>
    </Phone>
  );
}

// ════════════════════════════════════════════════════════════
// 3 · NEW PATTERN — parts, each holding sequences
// ════════════════════════════════════════════════════════════
function NewPatternScreen({ dark = false }) {
  const t = pickT(dark);
  const name = 'Raglan pullover';
  const parts = [
    { name: 'Body', color: t.brick, active: true, seqs: [
      { num: 1, name: 'Ribbed hem', color: t.mustard, rows: 2 },
      { num: 2, name: 'Stockinette yoke', color: t.brick, rows: 6, active: true },
      { num: 3, name: 'Raglan increases', color: t.forest, rows: 4 },
    ] },
    { name: 'Sleeve 1', color: t.mustard, seqCount: 2 },
    { name: 'Sleeve 2', color: t.forest, seqCount: 2 },
  ];
  const totalSeq = 5;

  return (
    <Phone dark={dark}>
      <div style={{ padding: '8px 20px 4px' }}>
        <LCTopBar kind="Pattern" ready dark={dark}/>
        <LCHeader title="New pattern" sub="The whole make — parts, each with its own sequences. Your master recipe." dark={dark}/>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '14px 20px 130px' }}>

        {/* LIVE PREVIEW — the Patterns-tab tile */}
        <div style={{
          background: t.card, borderRadius: 18, padding: 14,
          border: `1.5px solid ${t.brick}`, boxShadow: `0 8px 22px -16px ${t.brick}`,
        }}>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            <div style={{
              width: 48, height: 48, borderRadius: 12, background: t.brick, color: '#FBF6EC',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              fontFamily: FontDisplay, fontSize: 20,
            }}>{parts.length}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.18em', textTransform: 'uppercase' }}>Live preview</div>
              <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 15.5, color: t.ink, marginTop: 3, letterSpacing: '-0.005em' }}>{name}</div>
              <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, marginTop: 3 }}>{parts.length} parts · {totalSeq} sequences</div>
            </div>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3, marginTop: 10, paddingLeft: 60 }}>
            {['Ribbed hem', 'Stockinette yoke', 'Raglan increases', 'Cuff', 'Sleeve body'].slice(0, 4).map((s, i) => (
              <div key={i} style={{
                padding: '2px 7px', borderRadius: 6, background: t.cream2,
                fontFamily: FontMono, fontSize: 9.5, color: t.inkSoft, fontWeight: 600,
              }}>{s}</div>
            ))}
            <div style={{ padding: '2px 7px', borderRadius: 6, fontFamily: FontMono, fontSize: 9.5, color: t.inkMute, fontWeight: 600 }}>+ 1 more</div>
          </div>
        </div>

        <LCIdentity name={name} placeholder="e.g. Raglan pullover" craft="knit" dark={dark}/>

        {/* PARTS — the active part is expanded to reveal its sequences */}
        <div style={{ marginTop: 22 }}>
          <LCLabel dark={dark} hint={`${parts.length} parts`}>Parts &amp; sequences</LCLabel>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {parts.map((p, pi) => (
              <div key={pi}>
                {/* Part header */}
                <div style={{
                  background: t.card,
                  border: p.active ? `2px solid ${t.brick}` : `1px solid ${t.rule}`,
                  borderRadius: 16, padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10,
                  boxShadow: p.active ? `0 0 0 4px ${dark ? 'rgba(255,122,77,0.10)' : 'rgba(156,61,46,0.07)'}` : 'none',
                }}>
                  <Icon name="grip" size={18} color={t.inkMute}/>
                  <div style={{
                    width: 34, height: 34, borderRadius: 10, background: p.color, color: '#FBF6EC',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontFamily: FontDisplay, fontSize: 16, flexShrink: 0,
                  }}>{pi + 1}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 16, color: t.ink }}>{p.name}{p.active && <span style={{ display: 'inline-block', width: 2, height: 15, background: t.brick, marginLeft: 3, transform: 'translateY(2px)' }}/>}</div>
                    <div style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute, marginTop: 2 }}>
                      {(p.seqs ? p.seqs.length : p.seqCount)} sequences{p.active ? ' · editing ✱' : ''}
                    </div>
                  </div>
                  <Icon name={p.active ? 'chevDown' : 'edit'} size={16} color={t.inkSoft}/>
                </div>

                {/* Expanded sequences under the active part */}
                {p.active && p.seqs && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingLeft: 12, borderLeft: `2px solid ${t.cream2}`, marginLeft: 16, marginTop: 8 }}>
                    {p.seqs.map(sq => (
                      <div key={sq.num} style={{
                        background: t.card,
                        border: sq.active ? `1.5px solid ${t.brick}` : `1px solid ${t.rule}`,
                        borderRadius: 12, padding: '10px 12px', display: 'flex', alignItems: 'center', gap: 10,
                      }}>
                        <div style={{
                          width: 28, height: 28, borderRadius: 8, background: sq.color, color: '#FBF6EC',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          fontFamily: FontDisplay, fontSize: 14, flexShrink: 0,
                        }}>{sq.num}</div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 14, color: sq.active ? t.brick : t.ink }}>{sq.name}</div>
                          <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, marginTop: 1 }}>{sq.rows} rows{sq.active ? ' · open' : ''}</div>
                        </div>
                        <Icon name="chevR" size={15} color={t.inkSoft}/>
                      </div>
                    ))}
                    <div style={{ marginTop: 2 }}>
                      <LCReuseChooser kind="sequence" count={12} dark={dark}/>
                    </div>
                  </div>
                )}
              </div>
            ))}

            {/* Add another part */}
            <div style={{
              background: 'transparent', border: `1.5px dashed ${t.rule}`, color: t.brick, padding: '14px',
              borderRadius: 16, fontFamily: FontBody, fontSize: 14, fontWeight: 700, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            }}>
              <Icon name="plus" size={16} color={t.brick}/> Add another part
            </div>
          </div>
        </div>

        <div style={{
          marginTop: 16, padding: '10px 12px', background: t.cream2, borderRadius: 12,
          fontSize: 12, color: t.inkSoft, display: 'flex', gap: 8, alignItems: 'flex-start',
        }}>
          <Icon name="bulb" size={14} color={t.mustardDk}/>
          <span><b style={{ color: t.ink }}>Tip:</b> A scarf is one part. A cardigan is three. Drag parts to set your knitting order.</span>
        </div>
      </div>

      {/* Footer — at pattern altitude you save, not tap stitches */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        padding: '14px 20px 28px', background: t.bg, borderTop: `1px solid ${t.rule}`,
      }}>
        <Btn variant="primary" size="lg" full icon="save" dark={dark}>Save pattern to library</Btn>
      </div>
    </Phone>
  );
}

Object.assign(window, { NewRowScreen, NewSequenceScreen, NewPatternScreen });
