
// ====================== desktop-ui.jsx ======================
// Desktop shared UI — theme context, color helpers, reusable atoms.
// Reuses from window: Stitches, StitchGlyph, SkeinLogo, pickT, SkeinTokens, Icon, FontDisplay, FontBody, FontMono.

const ThemeCtx = React.createContext({ dark: false, setDark: () => {}, t: null });
function useT() {
  const ctx = React.useContext(ThemeCtx);
  return ctx;
}

// Stitch → accent colour, the rhythm used across YarnLog charts.
function stitchHue(t, id) {
  if (['k', 'sl', 'kfb', 'm1', 'c4f', 'c4b', 'tbl'].includes(id)) return t.brick;
  if (['p', 'p2tog', 'mb', 'dash'].includes(id)) return t.mustard;
  return t.forest;
}

// ─── Section eyebrow label (mono, tracked) ───────────────────
function Eyebrow({ children, color, style }) {
  const { t } = useT();
  return (
    <div style={{
      fontFamily: FontMono, fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase',
      color: color || t.inkMute, ...style,
    }}>{children}</div>
  );
}

// ─── Card surface ────────────────────────────────────────────
function Card({ children, style, pad = 20, hover, onClick, active }) {
  const { t } = useT();
  const [h, setH] = React.useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        background: t.card, border: `1px solid ${active ? t.brick : t.rule}`, borderRadius: 18,
        padding: pad, position: 'relative',
        boxShadow: active ? `0 0 0 4px ${t.dark ? 'rgba(255,122,77,0.12)' : 'rgba(156,61,46,0.08)'}` : 'none',
        transition: 'border-color 140ms ease, box-shadow 140ms ease, transform 140ms ease',
        ...(hover && h ? { transform: 'translateY(-2px)', borderColor: t.inkMute } : null),
        cursor: onClick ? 'pointer' : 'default',
        ...style,
      }}>
      {children}
    </div>
  );
}

// ─── Round icon button ───────────────────────────────────────
function RIconBtn({ name, onClick, size = 40, color, title, tone = 'soft', stroke = 2 }) {
  const { t } = useT();
  const [h, setH] = React.useState(false);
  const tones = {
    soft:  { bg: t.card, bd: t.rule, fg: color || t.ink },
    plain: { bg: 'transparent', bd: 'transparent', fg: color || t.inkSoft },
    brick: { bg: t.brick, bd: t.brick, fg: '#FBF6EC' },
  };
  const c = tones[tone];
  return (
    <button onClick={onClick} title={title} style={{
      width: size, height: size, borderRadius: size / 2.6,
      background: h && tone === 'plain' ? t.cream2 : c.bg,
      border: `1px solid ${c.bd}`,
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
      color: c.fg, flexShrink: 0, transition: 'background 120ms ease, transform 120ms ease',
      transform: h ? 'translateY(-1px)' : 'none',
    }}>
      <Icon name={name} size={Math.round(size * 0.46)} color={c.fg} stroke={stroke}/>
    </button>
  );
}

// ─── Segmented control ───────────────────────────────────────
function Segmented({ items, value, onChange, size = 'md', style }) {
  const { t } = useT();
  const pad = size === 'sm' ? '7px 12px' : '10px 16px';
  const fs = size === 'sm' ? 12.5 : 14;
  return (
    <div style={{ display: 'inline-flex', gap: 4, background: t.cream2, padding: 4, borderRadius: 12, ...style }}>
      {items.map(it => {
        const active = value === it.id;
        return (
          <button key={it.id} onClick={() => onChange && onChange(it.id)} style={{
            padding: pad, background: active ? t.card : 'transparent', border: 'none', borderRadius: 9,
            fontFamily: FontBody, fontWeight: 600, fontSize: fs, color: active ? t.brick : t.inkSoft,
            cursor: 'pointer', boxShadow: active ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
            display: 'inline-flex', alignItems: 'center', gap: 7, transition: 'color 120ms ease',
          }}>
            {it.icon && <Icon name={it.icon} size={15} color={active ? t.brick : t.inkSoft}/>}
            {it.label}
            {it.count != null && (
              <span style={{
                fontFamily: FontMono, fontSize: 10, fontWeight: 700, color: active ? t.brick : t.inkMute,
                background: active ? t.cream2 : 'transparent', padding: '1px 6px', borderRadius: 6,
              }}>{it.count}</span>
            )}
          </button>
        );
      })}
    </div>
  );
}

// ─── Pill chip (filter / tag) ────────────────────────────────
function Chip({ children, active, onClick, icon, tone = 'brick', size = 'md' }) {
  const { t } = useT();
  const activeBg = tone === 'ink' ? t.ink : tone === 'mustard' ? t.mustard : t.brick;
  const activeFg = tone === 'mustard' ? t.ink : tone === 'ink' ? t.bg : '#FBF6EC';
  const pad = size === 'sm' ? '6px 12px' : '8px 14px';
  return (
    <button onClick={onClick} style={{
      padding: pad, borderRadius: 999, fontSize: size === 'sm' ? 12.5 : 13.5, fontWeight: 600,
      fontFamily: FontBody, cursor: 'pointer', whiteSpace: 'nowrap',
      background: active ? activeBg : t.card, color: active ? activeFg : t.inkSoft,
      border: active ? 'none' : `1px solid ${t.rule}`,
      display: 'inline-flex', alignItems: 'center', gap: 7, transition: 'background 120ms ease',
    }}>
      {icon && <Icon name={icon} size={14} color={active ? activeFg : t.brick}/>}
      {children}
    </button>
  );
}

// ─── A chart stitch tile (chart cell) ────────────────────────
function STile({ id, w = 30, h = 40, active, dim, big }) {
  const { t } = useT();
  const s = Stitches.find(x => x.id === id) || { symbol: 'dot', abbr: id };
  const c = stitchHue(t, id);
  const glyph = big ? Math.round(h * 0.42) : Math.round(h * 0.36);
  return (
    <div style={{
      width: w, height: h, borderRadius: 8, flexShrink: 0,
      background: active ? c : t.cream2, border: `1.4px solid ${c}`,
      opacity: dim ? 0.4 : 1,
      boxShadow: active ? `0 4px 12px -4px ${c}` : 'none',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2,
      transition: 'all 140ms ease',
    }}>
      <StitchGlyph symbol={s.symbol} color={active ? '#FBF6EC' : c} size={glyph} stroke={2}/>
      {h >= 30 && <div style={{ fontFamily: FontMono, fontSize: big ? 9 : 7.5, fontWeight: 700, color: active ? '#FBF6EC' : c, lineHeight: 1 }}>{s.abbr}</div>}
    </div>
  );
}

// ─── Mini 2×2 swatch tile (library item thumbnail) ──────────
function SwatchTile({ pattern, color, size = 52 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: 13, background: color,
      display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 2, padding: size * 0.12, flexShrink: 0,
    }}>
      {pattern.slice(0, 4).map((sym, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <StitchGlyph symbol={sym} color="#FBF6EC" size={size * 0.28} stroke={1.8}/>
        </div>
      ))}
    </div>
  );
}

// ─── Yarn ball thumbnail ─────────────────────────────────────
function YarnThumb({ color, size = 64 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" style={{ display: 'block' }}>
      <circle cx="32" cy="32" r="24" fill={color}/>
      <path d="M12 28 Q 32 22 52 28" stroke="rgba(255,255,255,0.45)" strokeWidth="2.2" fill="none" strokeLinecap="round"/>
      <path d="M10 36 Q 32 30 54 36" stroke="rgba(255,255,255,0.45)" strokeWidth="2.2" fill="none" strokeLinecap="round"/>
      <path d="M14 44 Q 32 38 50 44" stroke="rgba(255,255,255,0.45)" strokeWidth="2.2" fill="none" strokeLinecap="round"/>
      <path d="M18 20 Q 32 26 46 20" stroke="rgba(255,255,255,0.45)" strokeWidth="2.2" fill="none" strokeLinecap="round"/>
      <path d="M52 28 Q 60 26 58 18" stroke={color} strokeWidth="2.4" fill="none" strokeLinecap="round"/>
      <circle cx="58" cy="17" r="1.8" fill={color}/>
    </svg>
  );
}

// ─── Modal scaffolding (centered dialog / sheet for desktop) ──
function Modal({ children, onClose, width = 560, align = 'center' }) {
  const { t } = useT();
  React.useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose && onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 200,
      display: 'flex', alignItems: align === 'top' ? 'flex-start' : 'center', justifyContent: 'center',
      padding: align === 'top' ? '64px 24px' : 24,
    }}>
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0,
        background: t.dark ? 'rgba(0,0,0,0.6)' : 'rgba(43,24,16,0.4)',
        backdropFilter: 'blur(5px)', WebkitBackdropFilter: 'blur(5px)',
        animation: 'yl-scrim 160ms ease',
      }}/>
      <div className="yl-scroll" style={{
        position: 'relative', width, maxWidth: '100%', maxHeight: '100%', overflow: 'auto',
        background: t.bg, borderRadius: 24, border: `1px solid ${t.rule}`,
        boxShadow: t.dark ? '0 40px 90px rgba(0,0,0,0.7)' : '0 40px 90px -20px rgba(43,24,16,0.4)',
        animation: 'yl-pop 200ms cubic-bezier(0.2,0.8,0.2,1)',
      }}>
        {children}
      </div>
    </div>
  );
}

// ─── Tip / hint banner ───────────────────────────────────────
function Tip({ children, style }) {
  const { t } = useT();
  return (
    <div style={{
      padding: '12px 16px', background: t.cream2, borderRadius: 14,
      fontSize: 13.5, color: t.inkSoft, display: 'flex', gap: 10, alignItems: 'flex-start',
      lineHeight: 1.5, ...style,
    }}>
      <Icon name="bulb" size={17} color={t.mustardDk}/>
      <span>{children}</span>
    </div>
  );
}

// ─── Hold-to-confirm button (desktop) ────────────────────────
// Press & hold; ring fills; fires onComplete. Pointer + spacebar.
function HoldBtn({ label, sub, holdMs = 2400, color, ringColor, height = 76, width, onComplete, icon }) {
  const { t } = useT();
  color = color || t.brick;
  ringColor = ringColor || t.mustard;
  const [progress, setProgress] = React.useState(0);
  const [active, setActive] = React.useState(false);
  const [w, setW] = React.useState(width || 300);
  const wrapRef = React.useRef(null);
  const raf = React.useRef(null);
  const started = React.useRef(0);

  React.useEffect(() => {
    if (width || !wrapRef.current || typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver((es) => { for (const e of es) { const x = Math.round(e.contentRect.width); if (x > 0) setW(x); } });
    ro.observe(wrapRef.current);
    return () => ro.disconnect();
  }, [width]);

  const start = (e) => {
    e && e.preventDefault();
    if (active) return;
    setActive(true); started.current = performance.now();
    const tick = () => {
      const p = Math.min(1, (performance.now() - started.current) / holdMs);
      setProgress(p);
      if (p >= 1) { setActive(false); setProgress(0); onComplete && onComplete(); return; }
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
  };
  const stop = () => { if (raf.current) cancelAnimationFrame(raf.current); setActive(false); setProgress(0); };
  React.useEffect(() => () => { if (raf.current) cancelAnimationFrame(raf.current); }, []);

  const h = height, r = h / 2, sw = 6;
  const perim = 2 * Math.max(0, w - h) + 2 * Math.PI * (r - sw / 2);

  return (
    <div ref={wrapRef} style={{ width: width || '100%', position: 'relative' }}>
      <div
        onPointerDown={start} onPointerUp={stop} onPointerLeave={stop} onPointerCancel={stop}
        style={{ position: 'relative', width: '100%', height: h, userSelect: 'none', touchAction: 'none' }}>
        <div style={{
          position: 'absolute', inset: 0, borderRadius: r, background: color,
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12,
          color: '#FBF6EC', cursor: 'pointer',
          boxShadow: t.dark ? '0 0 0 1px rgba(255,255,255,0.06)' : `0 18px 44px -10px ${color}66, 0 4px 14px ${color}33`,
          transform: active ? 'scale(0.985)' : 'scale(1)', transition: 'transform 120ms ease',
        }}>
          {icon && <Icon name={icon} size={26} color="#FBF6EC"/>}
          <div style={{ textAlign: 'left' }}>
            <div style={{ fontFamily: FontDisplay, fontSize: 26, letterSpacing: '-0.01em', lineHeight: 1 }}>{label}</div>
            {sub && <div style={{ fontFamily: FontMono, fontSize: 11, opacity: 0.85, marginTop: 3, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{sub}</div>}
          </div>
        </div>
        <svg width="100%" height={h} viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" style={{
          position: 'absolute', inset: 0, pointerEvents: 'none', transform: 'rotate(-90deg)', transformOrigin: 'center',
        }}>
          <rect x={sw / 2} y={sw / 2} width={w - sw} height={h - sw} rx={r - sw / 2}
            fill="none" stroke={ringColor} strokeWidth={sw} strokeDasharray={perim}
            strokeDashoffset={perim * (1 - progress)} strokeLinecap="round" opacity={active ? 1 : 0}/>
        </svg>
      </div>
    </div>
  );
}

// Group consecutive identical stitch ids into runs → "k2, p2, …"
function groupRuns(ids) {
  const out = [];
  for (const id of ids) {
    const last = out[out.length - 1];
    if (last && last.id === id) last.count += 1; else out.push({ id, count: 1 });
  }
  return out;
}
function runsNotation(ids) {
  return groupRuns(ids).map(r => {
    const ab = (Stitches.find(s => s.id === r.id) || {}).abbr || r.id;
    return r.count > 1 ? `${ab}${r.count}` : ab;
  }).join(', ');
}

Object.assign(window, {
  ThemeCtx, useT, stitchHue, Eyebrow, Card, RIconBtn, Segmented, Chip, STile, SwatchTile,
  YarnThumb, Modal, Tip, HoldBtn, groupRuns, runsNotation,
});


// ====================== desktop-home.jsx ======================
// Home — projects dashboard.

function PageHeader({ eyebrow, title, sub, right }) {
  const { t } = useT();
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 24, flexWrap: 'wrap', marginBottom: 28 }}>
      <div>
        {eyebrow && <Eyebrow color={t.mustardDk} style={{ marginBottom: 10 }}>{eyebrow}</Eyebrow>}
        <div style={{ fontFamily: FontDisplay, fontSize: 48, color: t.brick, lineHeight: 0.98, letterSpacing: '-0.02em' }}>{title}</div>
        {sub && <div style={{ fontSize: 16, color: t.inkSoft, marginTop: 12, maxWidth: 620, lineHeight: 1.45 }}>{sub}</div>}
      </div>
      {right}
    </div>
  );
}

// Search field used across pages.
function SearchField({ placeholder = 'Search…', width = 280 }) {
  const { t } = useT();
  const [v, setV] = React.useState('');
  const [focus, setFocus] = React.useState(false);
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10, width, maxWidth: '100%',
      background: t.card, border: `1.5px solid ${focus ? t.brick : t.rule}`, borderRadius: 13, padding: '11px 14px',
      transition: 'border-color 140ms ease',
    }}>
      <Icon name="search" size={18} color={focus ? t.brick : t.inkMute}/>
      <input value={v} onChange={(e) => setV(e.target.value)} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        placeholder={placeholder} style={{
          flex: 1, minWidth: 0, background: 'transparent', border: 'none', outline: 'none',
          fontFamily: FontBody, fontSize: 14, color: t.ink,
        }}/>
      <kbd style={{
        fontFamily: FontMono, fontSize: 10.5, color: t.inkMute, background: t.cream2, borderRadius: 6,
        padding: '2px 6px', border: `1px solid ${t.rule}`,
      }}>/</kbd>
    </div>
  );
}

function ProjectCard({ p, go }) {
  const { t } = useT();
  const cmap = { brick: t.brick, mustard: t.mustard, forest: t.forest, ink: t.ink };
  const c = cmap[p.color] || t.brick;
  const done = p.tag === 'Finished';
  const [hover, setHover] = React.useState(false);
  return (
    <div onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      onClick={() => go('knit', { projectId: p.id })}
      style={{
        background: t.card, border: `1px solid ${hover ? t.inkMute : t.rule}`, borderRadius: 22, padding: 20,
        cursor: 'pointer', opacity: done ? 0.78 : 1, transition: 'border-color 140ms ease, transform 140ms ease, box-shadow 140ms ease',
        transform: hover ? 'translateY(-3px)' : 'none',
        boxShadow: hover ? (t.dark ? '0 20px 40px rgba(0,0,0,0.4)' : '0 20px 40px -16px rgba(43,24,16,0.22)') : 'none',
        display: 'flex', flexDirection: 'column',
      }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <div style={{ width: 72, height: 72, borderRadius: 18, background: t.cream2, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <YarnThumb color={c} size={60}/>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ fontFamily: FontDisplay, fontSize: 24, color: t.ink, letterSpacing: '-0.01em', lineHeight: 1.05, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', minWidth: 0 }}>{p.name}</div>
            {done && <div style={{ flexShrink: 0, fontFamily: FontMono, fontSize: 10, fontWeight: 700, color: t.forest, border: `1px solid ${t.forest}`, padding: '3px 7px', borderRadius: 7, letterSpacing: '0.06em', textTransform: 'uppercase' }}>done</div>}
          </div>
          <div style={{ fontSize: 13, color: t.inkMute, marginTop: 3, fontFamily: FontMono }}>{p.sub}</div>
        </div>
      </div>

      {/* parts — just the pieces in this project; knitters move between them freely */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, alignItems: 'center', marginTop: 16 }}>
        <span style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute, letterSpacing: '0.06em', textTransform: 'uppercase', marginRight: 2 }}>{p.parts.length} {p.parts.length === 1 ? 'part' : 'parts'}</span>
        {p.parts.map((name, i) => (
          <span key={i} style={{ fontFamily: FontBody, fontSize: 12, color: t.inkSoft, background: t.cream2, borderRadius: 8, padding: '4px 9px', whiteSpace: 'nowrap' }}>{name}</span>
        ))}
      </div>
    </div>
  );
}

function HomeView({ go }) {
  const { t } = useT();
  const [finishedOpen, setFinishedOpen] = React.useState(false);
  const active = YL_PROJECTS.filter(p => p.tag !== 'Finished');
  const finished = YL_PROJECTS.filter(p => p.tag === 'Finished');

  return (
    <div style={{ padding: '40px 48px 64px', maxWidth: 1320, margin: '0 auto' }}>
      <PageHeader
        eyebrow="Your workspace"
        title="Hey, Marigold"
        sub={`${active.length} on the needles · ${finished.length} in the basket. Pick up where you left off, or cast something new on.`}
        right={<div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <SearchField placeholder="Search projects…"/>
        </div>}
      />

      {/* Featured cast-on banner */}
      <div onClick={() => go('setup')} style={{
        background: `linear-gradient(110deg, ${t.brick} 0%, ${t.brickDk} 100%)`, borderRadius: 24, padding: '28px 32px',
        display: 'flex', alignItems: 'center', gap: 24, cursor: 'pointer', marginBottom: 36,
        boxShadow: t.dark ? 'none' : `0 18px 40px -18px ${t.brick}`, position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ width: 64, height: 64, borderRadius: 18, background: 'rgba(255,255,255,0.16)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Icon name="plus" size={32} color="#FBF6EC" stroke={2.2}/>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: FontDisplay, fontSize: 30, color: '#FBF6EC', letterSpacing: '-0.01em', lineHeight: 1 }}>Cast on a project</div>
          <div style={{ fontSize: 15, color: 'rgba(251,246,236,0.82)', marginTop: 8, maxWidth: 540, lineHeight: 1.4 }}>
            Build your pattern step by step — name it, break it into parts, plan the sequences, and we'll keep your place row by row.
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#FBF6EC', fontFamily: FontBody, fontWeight: 700, fontSize: 15 }}>
          Start <Icon name="chevR" size={20} color="#FBF6EC"/>
        </div>
        <div style={{ position: 'absolute', right: -30, bottom: -50, opacity: 0.12 }}>
          <SkeinLogo size={220} fg="#FBF6EC" accent="#FBF6EC"/>
        </div>
      </div>

      {/* On the needles */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
        <Eyebrow>On the needles</Eyebrow>
        <span style={{ fontFamily: FontMono, fontSize: 11, fontWeight: 700, color: t.brick, background: t.cream2, padding: '2px 8px', borderRadius: 7 }}>{active.length}</span>
        <div style={{ flex: 1, height: 1, background: t.rule }}/>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: 20 }}>
        {active.map(p => <ProjectCard key={p.id} p={p} go={go}/>)}
      </div>

      {/* Finished */}
      {finished.length > 0 && (
        <div style={{ marginTop: 36 }}>
          <button onClick={() => setFinishedOpen(o => !o)} style={{
            display: 'flex', alignItems: 'center', gap: 12, background: 'none', border: 'none', cursor: 'pointer', padding: 0, width: '100%',
          }}>
            <Eyebrow>In the basket · finished</Eyebrow>
            <span style={{ fontFamily: FontMono, fontSize: 11, fontWeight: 700, color: t.forest, background: t.cream2, padding: '2px 8px', borderRadius: 7 }}>{finished.length}</span>
            <div style={{ flex: 1, height: 1, background: t.rule }}/>
            <Icon name="chevDown" size={18} color={t.inkMute} stroke={2.2}/>
          </button>
          {finishedOpen && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: 20, marginTop: 18, animation: 'yl-fade 200ms ease' }}>
              {finished.map(p => <ProjectCard key={p.id} p={p} go={go}/>)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

Object.assign(window, { HomeView, PageHeader, SearchField, ProjectCard });


// ====================== desktop-knit.jsx ======================
// Knitting screen — the hero. Focal current-row chart + persistent full-pattern rail.

const KNIT_SEQUENCES = [
  { name: 'Ribbed hem', color: 'mustard', repeatTotal: 1, rows: [
    { label: 'Row 1', stitches: ['p', 'p', 'k', 'k', 'p', 'p', 'k', 'k', 'p', 'p'] },
    { label: 'Row 2', stitches: ['p', 'k', 'p', 'k', 'p', 'k', 'p', 'k', 'p', 'k'] },
  ] },
  { name: 'Stockinette body', color: 'brick', repeatTotal: 6, rows: [
    { label: 'Row 1', stitches: ['k', 'k', 'p', 'p', 'k', 'k', 'yo', 'k2tog', 'k', 'k', 'p', 'p'] },
    { label: 'Row 2', stitches: ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'] },
  ] },
  { name: 'Decrease shaping', color: 'forest', repeatTotal: 1, rows: [
    { label: 'Row 1', stitches: ['k', 'k', 'k2tog', 'k', 'k', 'k', 'ssk', 'k', 'k', 'k'] },
    { label: 'Row 2', stitches: ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'] },
  ] },
];

// Big focal stitch chip.
function FocalChip({ id, idx }) {
  const { t } = useT();
  const s = Stitches.find(x => x.id === id) || { symbol: 'dot', abbr: id };
  const c = stitchHue(t, id);
  return (
    <div style={{
      width: 78, height: 96, borderRadius: 20, background: c, color: '#FBF6EC',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, flexShrink: 0,
      boxShadow: t.dark ? '0 6px 16px rgba(0,0,0,0.4)' : `0 8px 18px -6px ${c}88`,
    }}>
      <StitchGlyph symbol={s.symbol} color="#FBF6EC" size={40} stroke={2.6}/>
      <div style={{ fontFamily: FontMono, fontWeight: 700, fontSize: 17, letterSpacing: '0.02em' }}>{s.abbr}</div>
    </div>
  );
}

// Compact row strip in the pattern rail.
function RailRow({ row, active, done, onClick }) {
  const { t } = useT();
  return (
    <button onClick={onClick} style={{
      width: '100%', textAlign: 'left', cursor: 'pointer',
      background: active ? (t.dark ? 'rgba(255,122,77,0.12)' : '#FBEFEA') : 'transparent',
      border: active ? `1.5px solid ${t.brick}` : `1px solid transparent`,
      borderRadius: 12, padding: '9px 11px', opacity: done && !active ? 0.5 : 1,
      transition: 'background 120ms ease, opacity 120ms ease',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 7 }}>
        {done && !active
          ? <Icon name="check" size={13} color={t.forest} stroke={2.6}/>
          : <span style={{ width: 13, height: 13, borderRadius: 7, border: `2px solid ${active ? t.brick : t.inkMute}`, background: active ? t.brick : 'transparent', flexShrink: 0 }}/>}
        <span style={{ fontFamily: FontMono, fontSize: 11, fontWeight: 700, color: active ? t.brick : t.inkSoft }}>{row.label}</span>
        <span style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute }}>· {row.stitches.length} sts</span>
      </div>
      <div style={{ display: 'flex', gap: 2.5, flexWrap: 'wrap' }}>
        {row.stitches.map((id, i) => <STile key={i} id={id} w={17} h={21}/>)}
      </div>
    </button>
  );
}

function KnitView({ go, params }) {
  const { t, dark } = useT();
  const project = YL_PROJECTS.find(p => p.id === (params && params.projectId)) || YL_PROJECTS[0];
  const seqs = KNIT_SEQUENCES;

  // structural position
  const [pos, setPos] = React.useState({ seqIdx: 1, rowIdx: 0, repeat: 3 });
  const [globalRow, setGlobalRow] = React.useState(12);
  const total = 40;
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [finished, setFinished] = React.useState(false);
  const railRef = React.useRef(null);

  const seq = seqs[pos.seqIdx];
  const row = seq.rows[pos.rowIdx];
  const cmap = { brick: t.brick, mustard: t.mustard, forest: t.forest };
  const seqColor = cmap[seq.color];

  const advance = React.useCallback(() => {
    setPos(p => {
      const s = seqs[p.seqIdx];
      let { seqIdx, rowIdx, repeat } = p;
      if (rowIdx + 1 < s.rows.length) { rowIdx++; }
      else if (repeat < s.repeatTotal) { repeat++; rowIdx = 0; }
      else if (seqIdx + 1 < seqs.length) { seqIdx++; rowIdx = 0; repeat = 1; }
      else { return p; }
      return { seqIdx, rowIdx, repeat };
    });
    setGlobalRow(g => Math.min(total, g + 1));
  }, [seqs]);

  const back = React.useCallback(() => {
    setPos(p => {
      let { seqIdx, rowIdx, repeat } = p;
      if (rowIdx > 0) { rowIdx--; }
      else if (repeat > 1) { repeat--; rowIdx = seqs[seqIdx].rows.length - 1; }
      else if (seqIdx > 0) { seqIdx--; repeat = seqs[seqIdx].repeatTotal; rowIdx = seqs[seqIdx].rows.length - 1; }
      else { return p; }
      return { seqIdx, rowIdx, repeat };
    });
    setGlobalRow(g => Math.max(1, g - 1));
  }, [seqs]);

  // keyboard nav
  React.useEffect(() => {
    const onKey = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if (e.key === 'ArrowRight' || e.key === ' ') { e.preventDefault(); advance(); }
      if (e.key === 'ArrowLeft') { e.preventDefault(); back(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [advance, back]);

  const isCurrent = (si, ri) => si === pos.seqIdx && ri === pos.rowIdx;
  const isDone = (si, ri) => si < pos.seqIdx || (si === pos.seqIdx && ri < pos.rowIdx);

  return (
    <div style={{ display: 'flex', height: '100%', minHeight: 0 }}>
      {/* ── MAIN focal column ── */}
      <div className="yl-scroll" style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
        {/* top bar */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '22px 36px 0', gap: 16 }}>
          <button onClick={() => go('home')} style={{
            display: 'inline-flex', alignItems: 'center', gap: 8, background: 'none', border: 'none', cursor: 'pointer',
            color: t.inkSoft, fontFamily: FontBody, fontWeight: 600, fontSize: 14,
          }}>
            <Icon name="chevL" size={18} color={t.inkSoft}/> Projects
          </button>
          <div style={{ textAlign: 'center', flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: FontDisplay, fontSize: 22, color: t.ink, letterSpacing: '-0.01em', lineHeight: 1 }}>{project.name}</div>
            <div style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute, letterSpacing: '0.14em', textTransform: 'uppercase', marginTop: 5 }}>Body{finished ? ' · finished' : ' · in progress'}</div>
          </div>
          <div style={{ position: 'relative' }}>
            <RIconBtn name="more" tone="soft" size={40} onClick={() => setMenuOpen(o => !o)}/>
            {menuOpen && (
              <>
                <div onClick={() => setMenuOpen(false)} style={{ position: 'fixed', inset: 0, zIndex: 40 }}/>
                <div style={{
                  position: 'absolute', top: 'calc(100% + 8px)', right: 0, zIndex: 50, minWidth: 230, padding: 6,
                  background: t.card, borderRadius: 14, border: `1px solid ${t.rule}`,
                  boxShadow: dark ? '0 16px 40px rgba(0,0,0,0.55)' : '0 16px 40px -10px rgba(43,24,16,0.3)',
                  animation: 'yl-menu 140ms ease', transformOrigin: 'top right',
                }}>
                  {[
                    { icon: 'edit', label: 'Edit project', fn: () => { setMenuOpen(false); go('setup'); } },
                    { icon: finished ? 'undo' : 'flag', label: finished ? 'Unmark as finished' : 'Mark as finished', accent: !finished, fn: () => setFinished(f => !f) },
                    { icon: 'layers', label: 'Switch part', fn: () => setMenuOpen(false) },
                  ].map((it, i) => (
                    <button key={i} onClick={it.fn} style={{
                      width: '100%', display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px',
                      borderRadius: 11, border: 'none', cursor: 'pointer', background: 'transparent', textAlign: 'left',
                    }}
                      onMouseEnter={(e) => e.currentTarget.style.background = dark ? 'rgba(255,234,200,0.07)' : t.cream2}
                      onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
                      <span style={{ width: 30, height: 30, borderRadius: 9, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: it.accent ? (dark ? 'rgba(136,185,140,0.14)' : 'rgba(63,107,74,0.1)') : t.cream2 }}>
                        <Icon name={it.icon} size={17} color={it.accent ? t.forest : t.ink}/>
                      </span>
                      <span style={{ fontFamily: FontBody, fontWeight: 600, fontSize: 14.5, color: it.accent ? t.forest : t.ink }}>{it.label}</span>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        {/* counter + repeat + progress */}
        <div style={{ padding: '24px 48px 0', maxWidth: 920, margin: '0 auto', width: '100%' }}>
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 24, flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
              <span style={{ fontFamily: FontMono, fontSize: 13, color: t.inkMute, letterSpacing: '0.16em', textTransform: 'uppercase' }}>Row</span>
              <span style={{ fontFamily: FontDisplay, fontSize: 96, color: t.brick, lineHeight: 0.8, letterSpacing: '-0.03em' }}>{globalRow}</span>
              <span style={{ fontFamily: FontDisplay, fontSize: 34, color: t.inkSoft, lineHeight: 1 }}>/ {total}</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 10 }}>
              <div style={{
                background: t.mustard, color: dark ? '#1A0F08' : '#2B1810', padding: '9px 16px', borderRadius: 999,
                display: 'flex', alignItems: 'center', gap: 8,
              }}>
                <Icon name="repeat" size={16} color={dark ? '#1A0F08' : '#2B1810'}/>
                <span style={{ fontFamily: FontMono, fontWeight: 700, fontSize: 14 }}>Repeat {pos.repeat}/{seq.repeatTotal}</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute }}>{Math.round(globalRow / total * 100)}%</span>
                <div style={{ width: 160, height: 7, background: dark ? 'rgba(255,234,200,0.12)' : t.cream2, borderRadius: 4, overflow: 'hidden' }}>
                  <div style={{ width: `${globalRow / total * 100}%`, height: '100%', background: t.brick, borderRadius: 4, transition: 'width 240ms ease' }}/>
                </div>
              </div>
            </div>
          </div>

          {/* active sequence label */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 22 }}>
            <span style={{ width: 28, height: 28, borderRadius: 8, background: seqColor, color: '#FBF6EC', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontFamily: FontDisplay, fontSize: 15 }}>{pos.seqIdx + 1}</span>
            <span style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 17, color: t.ink }}>{seq.name}</span>
            <span style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute }}>· {row.label} · {row.stitches.length} sts</span>
          </div>
        </div>

        {/* FOCAL current row */}
        <div style={{ flex: 1, padding: '20px 48px', maxWidth: 920, margin: '0 auto', width: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div style={{
            background: dark ? 'rgba(255,234,200,0.04)' : t.card, border: `1.5px solid ${dark ? 'rgba(255,234,200,0.1)' : t.rule}`,
            borderRadius: 26, padding: '26px 28px', display: 'flex', flexDirection: 'column', minHeight: 320,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 }}>
              <Eyebrow>This row · read left → right</Eyebrow>
              <span style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute }}>{row.stitches.length} stitches</span>
            </div>
            <div key={`${pos.seqIdx}-${pos.rowIdx}-${pos.repeat}`} style={{ flex: 1, display: 'flex', flexWrap: 'wrap', gap: 12, alignContent: 'center', justifyContent: 'center' }}>
              {row.stitches.map((id, i) => <FocalChip key={i} id={id} idx={i}/>)}
            </div>
            <div style={{
              marginTop: 22, padding: '14px 18px', background: dark ? 'rgba(255,234,200,0.06)' : t.cream2, borderRadius: 14,
              fontFamily: FontMono, fontSize: 15, color: t.inkSoft, textAlign: 'center', letterSpacing: '0.02em',
            }}>{runsNotation(row.stitches)}</div>
          </div>
        </div>

        {/* controls */}
        <div style={{ padding: '4px 48px 28px', maxWidth: 920, margin: '0 auto', width: '100%' }}>
          <div style={{ display: 'flex', alignItems: 'stretch', gap: 14 }}>
            <button onClick={back} style={{
              width: 130, borderRadius: 38, cursor: 'pointer',
              background: dark ? 'rgba(255,217,134,0.06)' : t.card, border: `1.5px solid ${dark ? 'rgba(255,217,134,0.28)' : t.brick + '33'}`,
              color: t.brick, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4,
            }}>
              <Icon name="chevL" size={26} color={t.brick} stroke={2.4}/>
              <span style={{ fontFamily: FontMono, fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase' }}>Back a row</span>
            </button>
            <div style={{ flex: 1 }}>
              <HoldBtn label="Row done" sub="hold to advance" icon="check" height={76} color={t.brick} ringColor={t.mustard} holdMs={1400} onComplete={advance}/>
            </div>
          </div>
          <div style={{ textAlign: 'center', marginTop: 12, fontFamily: FontMono, fontSize: 11, color: t.inkMute, letterSpacing: '0.06em' }}>
            Press & hold so your cat can't ruin everything · or tap <kbd style={{ background: t.cream2, border: `1px solid ${t.rule}`, borderRadius: 5, padding: '1px 6px' }}>Space</kbd> / <kbd style={{ background: t.cream2, border: `1px solid ${t.rule}`, borderRadius: 5, padding: '1px 6px' }}>←</kbd>
          </div>
        </div>
      </div>

      {/* ── PATTERN RAIL ── */}
      <aside className="yl-scroll" ref={railRef} style={{
        width: 360, flexShrink: 0, height: '100%', overflow: 'auto',
        background: dark ? t.bgAlt : t.card, borderLeft: `1px solid ${t.rule}`, padding: '22px 18px 40px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
          <Eyebrow>Full pattern</Eyebrow>
          <span style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute }}>{seqs.length} sequences</span>
        </div>
        <div style={{ fontSize: 13, color: t.inkMute, marginBottom: 18, lineHeight: 1.4 }}>The whole Body part, top to bottom. Your spot is marked.</div>

        {seqs.map((s, si) => {
          const active = si === pos.seqIdx;
          const c = cmap[s.color];
          return (
            <div key={si} style={{ marginBottom: 18 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 9, padding: '0 2px' }}>
                <span style={{ width: 26, height: 26, borderRadius: 8, background: c, color: '#FBF6EC', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontFamily: FontDisplay, fontSize: 14, flexShrink: 0 }}>{si + 1}</span>
                <span style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 14.5, color: active ? t.ink : t.inkSoft, flex: 1, minWidth: 0 }}>{s.name}</span>
                {s.repeatTotal > 1 && (
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontFamily: FontMono, fontSize: 9.5, fontWeight: 700, color: t.brick, background: dark ? 'rgba(255,122,77,0.14)' : '#FBEFEA', border: `1px solid ${dark ? 'rgba(255,122,77,0.28)' : 'rgba(156,61,46,0.18)'}`, padding: '2px 7px', borderRadius: 999 }}>
                    <Icon name="repeat" size={10} color={t.brick}/>{active ? `${pos.repeat}/${s.repeatTotal}` : `×${s.repeatTotal}`}
                  </span>
                )}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4, paddingLeft: 12, borderLeft: `2px solid ${active ? c : t.cream2}`, marginLeft: 11 }}>
                {s.rows.map((r, ri) => (
                  <RailRow key={ri} row={r} active={isCurrent(si, ri)} done={isDone(si, ri)}
                    onClick={() => { setPos({ seqIdx: si, rowIdx: ri, repeat: si === pos.seqIdx ? pos.repeat : 1 }); }}/>
                ))}
              </div>
            </div>
          );
        })}

        <button onClick={() => go('setup')} style={{
          width: '100%', marginTop: 6, padding: '11px', borderRadius: 12, cursor: 'pointer',
          background: 'transparent', border: `1.5px dashed ${t.rule}`, color: t.inkSoft,
          fontFamily: FontBody, fontWeight: 600, fontSize: 13, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 7,
        }}>
          <Icon name="edit" size={14} color={t.inkSoft}/> Edit this pattern
        </button>
      </aside>
    </div>
  );
}

Object.assign(window, { KnitView, KNIT_SEQUENCES });


// ====================== desktop-setup.jsx ======================
// Setup wizard — 4 steps with a vertical step rail.

const SETUP_STEPS = [
  { id: 0, label: 'Basics', icon: 'edit', sub: 'Name, yarn & tool' },
  { id: 1, label: 'Parts', icon: 'layers', sub: 'Break it into pieces' },
  { id: 2, label: 'Sequences', icon: 'library', sub: 'Plan the rows' },
  { id: 3, label: 'Arrange', icon: 'grid', sub: 'Order & repeats' },
];

function StepRail({ step, setStep }) {
  const { t } = useT();
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {SETUP_STEPS.map(s => {
        const active = s.id === step;
        const done = s.id < step;
        return (
          <button key={s.id} onClick={() => setStep(s.id)} style={{
            display: 'flex', alignItems: 'center', gap: 13, padding: '14px 16px', borderRadius: 14, cursor: 'pointer',
            background: active ? t.card : 'transparent', border: `1px solid ${active ? t.brick : 'transparent'}`,
            textAlign: 'left', width: '100%', transition: 'background 120ms ease',
          }}>
            <span style={{
              width: 36, height: 36, borderRadius: 11, flexShrink: 0, display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              background: active ? t.brick : done ? t.forest : t.cream2, color: active || done ? '#FBF6EC' : t.inkMute,
              fontFamily: FontDisplay, fontSize: 16,
            }}>{done ? <Icon name="check" size={18} color="#FBF6EC" stroke={2.6}/> : s.id + 1}</span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 15, color: active ? t.brick : t.ink }}>{s.label}</div>
              <div style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute, marginTop: 2 }}>{s.sub}</div>
            </div>
          </button>
        );
      })}
    </div>
  );
}

function FieldLabel({ children, hint, required }) {
  const { t } = useT();
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <Eyebrow>{children}</Eyebrow>
        {required && <span style={{ fontFamily: FontMono, fontSize: 9, fontWeight: 700, color: '#FBF6EC', background: t.brick, padding: '2px 7px', borderRadius: 6, letterSpacing: '0.1em' }}>REQUIRED</span>}
      </div>
      {hint && <span style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute }}>{hint}</span>}
    </div>
  );
}

// ── STEP 1 — Basics ──
function Step1({ data, set }) {
  const { t } = useT();
  const weights = ['Lace', 'Fingering', 'Sport', 'DK', 'Worsted', 'Aran', 'Bulky', 'Chunky', 'Jumbo'];
  const colors = [t.brick, t.mustard, t.forest, '#7A5A8C', '#3B5B7A', '#C2547B', t.ink];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 30 }}>
      <div>
        <FieldLabel required={data.name.length === 0}>Name your project</FieldLabel>
        <input value={data.name} onChange={(e) => set({ name: e.target.value.slice(0, 60) })} placeholder="e.g. The Granny Cardigan" style={{
          width: '100%', background: t.card, border: `2px solid ${data.name ? t.brick : t.rule}`, borderRadius: 16, padding: '18px 20px',
          fontFamily: FontDisplay, fontSize: 28, color: t.ink, outline: 'none', letterSpacing: '-0.01em',
        }}/>
        <div style={{ marginTop: 8, fontFamily: FontMono, fontSize: 11, color: data.name ? t.forest : t.inkMute }}>{data.name ? 'Looks good. Future-you will thank you.' : 'Give it a name — anything will do.'} · {data.name.length}/60</div>
      </div>

      <div>
        <FieldLabel>What kind?</FieldLabel>
        <div style={{ display: 'flex', gap: 10 }}>
          {[{ id: 'knit', label: 'Knit', icon: 'needle' }, { id: 'crochet', label: 'Crochet', icon: 'loop' }, { id: 'both', label: 'Both', icon: 'yarn' }].map(c => (
            <button key={c.id} onClick={() => set({ craft: c.id })} style={{
              padding: '12px 22px', borderRadius: 999, cursor: 'pointer',
              background: data.craft === c.id ? t.brick : t.card, color: data.craft === c.id ? '#FBF6EC' : t.ink,
              border: data.craft === c.id ? 'none' : `1px solid ${t.rule}`, fontFamily: FontBody, fontWeight: 600, fontSize: 15,
              display: 'inline-flex', alignItems: 'center', gap: 9,
            }}>
              <Icon name={c.icon} size={17} color={data.craft === c.id ? '#FBF6EC' : t.brick}/>{c.label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 30 }}>
        <div>
          <FieldLabel hint="whatever's on the label">Yarn weight</FieldLabel>
          <div style={{ display: 'flex', gap: 7, flexWrap: 'wrap' }}>
            {weights.map(w => (
              <button key={w} onClick={() => set({ weight: w })} style={{
                padding: '9px 14px', borderRadius: 999, fontSize: 13.5, fontWeight: 600, cursor: 'pointer',
                background: data.weight === w ? t.brick : t.card, color: data.weight === w ? '#FBF6EC' : t.ink,
                border: data.weight === w ? 'none' : `1px solid ${t.rule}`, fontFamily: FontBody,
              }}>{w}</button>
            ))}
          </div>
        </div>
        <div>
          <FieldLabel hint={data.craft === 'crochet' ? 'hook' : 'needle'}>{data.craft === 'crochet' ? 'Hook' : 'Needle'} size</FieldLabel>
          <div style={{ background: t.card, border: `1px solid ${t.rule}`, borderRadius: 16, padding: 16, display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: t.cream2, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name={data.craft === 'crochet' ? 'loop' : 'needle'} size={22} color={t.brick}/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
                <span style={{ fontFamily: FontDisplay, fontSize: 30, color: t.ink, lineHeight: 1 }}>{data.size.toFixed(1)}</span>
                <span style={{ fontFamily: FontMono, fontSize: 13, color: t.inkSoft, fontWeight: 600 }}>mm</span>
              </div>
              <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, marginTop: 2 }}>typical for {data.weight}</div>
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <RIconBtn name="x" tone="soft" size={36} onClick={() => set({ size: Math.max(1, +(data.size - 0.5).toFixed(1)) })} title="Smaller"/>
              <RIconBtn name="plus" tone="soft" size={36} onClick={() => set({ size: +(data.size + 0.5).toFixed(1) })} title="Bigger"/>
            </div>
          </div>
        </div>
      </div>

      <div>
        <FieldLabel hint="just for vibes">Yarn color</FieldLabel>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          {colors.map((c, i) => (
            <button key={c} onClick={() => set({ color: i })} style={{
              width: 46, height: 46, borderRadius: 14, background: c, cursor: 'pointer', border: 'none',
              boxShadow: data.color === i ? `0 0 0 3px ${t.bg}, 0 0 0 5px ${t.ink}` : 'none',
            }}/>
          ))}
          <div style={{ width: 46, height: 46, borderRadius: 14, border: `1.5px dashed ${t.rule}`, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <Icon name="plus" size={18} color={t.brick}/>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── STEP 2 — Parts ──
function Step2({ data, set }) {
  const { t } = useT();
  const cmap = [t.brick, t.mustard, t.forest, '#7A5A8C', '#3B5B7A'];
  const addPart = () => set({ parts: [...data.parts, { name: `Part ${data.parts.length + 1}`, seq: 1, rows: 20 }] });
  const removePart = (i) => set({ parts: data.parts.filter((_, idx) => idx !== i) });
  return (
    <div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {data.parts.map((p, i) => (
          <div key={i} style={{ background: t.card, border: `1px solid ${t.rule}`, borderRadius: 18, padding: 18, display: 'flex', alignItems: 'center', gap: 16 }}>
            <Icon name="grip" size={22} color={t.inkMute}/>
            <div style={{ width: 42, height: 42, borderRadius: 12, background: cmap[i % cmap.length], color: '#FBF6EC', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: FontDisplay, fontSize: 18 }}>{i + 1}</div>
            <div style={{ flex: 1 }}>
              <input value={p.name} onChange={(e) => set({ parts: data.parts.map((x, idx) => idx === i ? { ...x, name: e.target.value } : x) })} style={{
                background: 'transparent', border: 'none', outline: 'none', fontFamily: FontBody, fontWeight: 700, fontSize: 18, color: t.ink, width: '100%',
              }}/>
              <div style={{ fontFamily: FontMono, fontSize: 12, color: t.inkMute, marginTop: 2 }}>{p.seq} sequences · ~{p.rows} rows</div>
            </div>
            <RIconBtn name="trash" tone="plain" size={38} color={t.inkMute} onClick={() => removePart(i)} title="Remove part"/>
          </div>
        ))}
        <button onClick={addPart} style={{
          background: 'transparent', border: `1.5px dashed ${t.rule}`, color: t.brick, padding: 18, borderRadius: 18, cursor: 'pointer',
          fontFamily: FontBody, fontWeight: 600, fontSize: 15, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 9,
        }}>
          <Icon name="plus" size={18} color={t.brick}/> Add another part
        </button>
      </div>
      <Tip style={{ marginTop: 20 }}><b style={{ color: t.ink }}>Tip:</b> Drag to reorder. A cardigan has a body and two sleeves; a scarf has one part. Knit them in whatever order makes sense — YarnLog only tracks one part at a time.</Tip>
    </div>
  );
}

// ── STEP 3 — Sequences (per part, with stitch dock) ──
function Step3({ data, set, openPicker, openRemove }) {
  const { t, dark } = useT();
  const [activePart, setActivePart] = React.useState(0);
  const cmap = { brick: t.brick, mustard: t.mustard, forest: t.forest };
  const seqs = [
    { num: 1, name: 'Ribbed hem', color: 'mustard', rows: [{ label: 'Row 1', stitches: ['p', 'p', 'k', 'k', 'p', 'p'] }, { label: 'Row 2', stitches: ['p', 'k', 'p', 'k', 'p', 'k'] }] },
    { num: 2, name: 'Stockinette body', color: 'brick', editing: true, rows: [{ label: 'Row 1', stitches: ['k', 'k', 'k', 'k', 'k', 'k'] }, { label: 'Row 2', stitches: ['p', 'p', 'p', 'p', 'p', 'p'], active: true }, { label: 'Row 3', stitches: [] }] },
    { num: 3, name: 'Decrease shaping', color: 'forest', rows: [{ label: 'Row 1', stitches: ['k', 'k2tog', 'k', 'ssk', 'k'] }] },
  ];
  const quick = ['k', 'p', 'yo', 'k2tog', 'ssk', 'sl'];
  return (
    <div>
      <Segmented value={String(activePart)} onChange={(v) => setActivePart(+v)} style={{ marginBottom: 20 }}
        items={data.parts.map((p, i) => ({ id: String(i), label: p.name, count: p.seq }))}/>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
        {seqs.map(s => (
          <div key={s.num}>
            <div style={{
              background: t.card, border: s.editing ? `2px solid ${t.brick}` : `1px solid ${t.rule}`, borderRadius: 16, padding: '14px 16px',
              display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10,
              boxShadow: s.editing ? `0 0 0 4px ${dark ? 'rgba(255,122,77,0.1)' : 'rgba(156,61,46,0.07)'}` : 'none',
            }}>
              <span style={{ width: 34, height: 34, borderRadius: 10, background: cmap[s.color], color: '#FBF6EC', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontFamily: FontDisplay, fontSize: 17 }}>{s.num}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: FontDisplay, fontSize: 22, color: t.ink, letterSpacing: '-0.01em' }}>{s.name}{s.editing && <span style={{ display: 'inline-block', width: 2, height: 20, background: t.brick, marginLeft: 3, transform: 'translateY(2px)' }}/>}</div>
                <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, marginTop: 2 }}>{s.rows.length} rows{s.editing && <span style={{ color: t.brick, fontWeight: 700 }}> · editing ✱</span>}</div>
              </div>
              {s.editing
                ? <button onClick={() => openRemove('seq')} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: dark ? 'rgba(255,122,77,0.12)' : '#FBEFEA', border: `1px solid ${dark ? 'rgba(255,122,77,0.32)' : 'rgba(156,61,46,0.22)'}`, color: t.brick, borderRadius: 10, padding: '8px 12px', cursor: 'pointer', fontFamily: FontMono, fontSize: 10.5, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}><Icon name="trash" size={14} color={t.brick}/> Delete</button>
                : <div style={{ display: 'flex', gap: 10 }}><Icon name="edit" size={18} color={t.inkSoft}/><Icon name="chevDown" size={18} color={t.inkSoft}/></div>}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingLeft: 16, borderLeft: `2px solid ${t.cream2}`, marginLeft: 12 }}>
              {s.rows.map((r, ri) => {
                const empty = r.stitches.length === 0;
                return (
                  <div key={ri} style={{ background: t.card, border: r.active ? `2px solid ${t.brick}` : `1px solid ${t.rule}`, borderRadius: 14, padding: '12px 14px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: empty ? 0 : 12 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                        <Icon name="grip" size={15} color={t.inkMute}/>
                        <span style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 14, color: r.active ? t.brick : t.ink }}>{r.label}{r.active && ' ✱'}</span>
                        <span style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute }}>· {r.stitches.length} sts</span>
                      </div>
                      <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                        <Icon name="repeat" size={15} color={t.inkMute}/>
                        <Icon name="backspace" size={15} color={t.inkMute}/>
                        <button onClick={() => openRemove('row')} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, display: 'flex' }}><Icon name="trash" size={15} color={t.inkMute}/></button>
                      </div>
                    </div>
                    {empty
                      ? <div style={{ fontFamily: FontMono, fontSize: 12, color: t.inkMute, fontStyle: 'italic' }}>empty · tap a stitch below to start filling</div>
                      : <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>{r.stitches.map((id, i) => <STile key={i} id={id} w={30} h={40}/>)}</div>}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* sticky stitch dock */}
      <div style={{ marginTop: 24, background: t.card, border: `1px solid ${t.rule}`, borderRadius: 18, padding: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <span style={{ fontFamily: FontMono, fontSize: 11, color: t.brick, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase' }}>Tap to add to Stockinette · Row 2 ✱</span>
          <button onClick={openPicker} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', cursor: 'pointer', color: t.brick, fontFamily: FontMono, fontSize: 12, fontWeight: 700 }}>All 30 stitches <Icon name="chevR" size={14} color={t.brick}/></button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 10 }}>
          {quick.map(id => {
            const s = Stitches.find(x => x.id === id);
            const c = stitchHue(t, id);
            return (
              <button key={id} onClick={openPicker} style={{ background: t.cream2, border: `1px solid ${t.rule}`, borderRadius: 12, padding: '10px 0', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
                <div style={{ width: 38, height: 38, borderRadius: 10, background: c, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><StitchGlyph symbol={s.symbol} color="#FBF6EC" size={20}/></div>
                <span style={{ fontFamily: FontMono, fontSize: 11, color: t.inkSoft, fontWeight: 700 }}>{s.abbr}</span>
              </button>
            );
          })}
        </div>
      </div>
      <Tip style={{ marginTop: 18 }}><b style={{ color: t.ink }}>Tip:</b> Tap any row to focus it — the stitch dock fills that row. Mark a repeat with the ↻ icon, then tap the first &amp; last stitch.</Tip>
    </div>
  );
}

// ── STEP 4 — Arrange ──
function Step4({ data }) {
  const { t } = useT();
  const cmap = { brick: t.brick, mustard: t.mustard, forest: t.forest };
  const seqs = [
    { name: 'Ribbed hem', color: 'mustard', rows: 2, rep: 1 },
    { name: 'Stockinette body', color: 'brick', rows: 2, rep: 6 },
    { name: 'Decrease shaping', color: 'forest', rows: 2, rep: 1 },
  ];
  return (
    <div>
      <Segmented value="0" onChange={() => {}} style={{ marginBottom: 20 }} items={data.parts.map((p, i) => ({ id: String(i), label: p.name }))}/>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {seqs.map((s, i) => (
          <div key={i} style={{ background: t.card, border: `1px solid ${t.rule}`, borderRadius: 16, padding: 18, display: 'flex', alignItems: 'center', gap: 16 }}>
            <Icon name="grip" size={22} color={t.inkMute}/>
            <span style={{ width: 38, height: 38, borderRadius: 11, background: cmap[s.color], color: '#FBF6EC', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontFamily: FontDisplay, fontSize: 17 }}>{i + 1}</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 17, color: t.ink }}>{s.name}</div>
              <div style={{ fontFamily: FontMono, fontSize: 11.5, color: t.inkMute, marginTop: 2 }}>{s.rows} rows</div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: t.cream2, borderRadius: 10, padding: '6px 8px' }}>
              <Icon name="repeat" size={15} color={t.brick}/>
              <RIconBtn name="x" tone="plain" size={28} title="fewer"/>
              <span style={{ fontFamily: FontDisplay, fontSize: 18, color: t.ink, minWidth: 22, textAlign: 'center' }}>{s.rep}</span>
              <RIconBtn name="plus" tone="plain" size={28} title="more"/>
            </div>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 16, display: 'flex', alignItems: 'center', gap: 12, background: t.cream2, borderRadius: 16, padding: '16px 18px' }}>
        <Icon name="refresh" size={20} color={t.forest}/>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 15, color: t.ink }}>Loop the whole part</div>
          <div style={{ fontSize: 12.5, color: t.inkMute, marginTop: 2 }}>Repeat every sequence until your piece reaches length.</div>
        </div>
        <div style={{ width: 48, height: 28, borderRadius: 14, background: t.forest, position: 'relative', cursor: 'pointer' }}>
          <div style={{ position: 'absolute', top: 3, right: 3, width: 22, height: 22, borderRadius: 11, background: '#FBF6EC' }}/>
        </div>
      </div>
      <Tip style={{ marginTop: 18 }}><b style={{ color: t.ink }}>Almost there.</b> Drag sequences to set knitting order, dial in repeats, then cast on — we'll keep your place from Row 1.</Tip>
    </div>
  );
}

function SetupWizard({ go }) {
  const { t } = useT();
  const [step, setStep] = React.useState(0);
  const [picker, setPicker] = React.useState(false);
  const [remove, setRemove] = React.useState(null); // 'row' | 'seq'
  const [data, setData] = React.useState({
    name: 'The Granny Cardigan', craft: 'knit', weight: 'Bulky', size: 4.5, color: 0,
    parts: [{ name: 'Body', seq: 3, rows: 96 }, { name: 'Sleeve 1', seq: 2, rows: 64 }, { name: 'Sleeve 2', seq: 2, rows: 64 }],
  });
  const set = (patch) => setData(d => ({ ...d, ...patch }));
  const blocked = step === 0 && data.name.trim().length === 0;

  const titles = ['What are we making?', 'Break it into parts.', 'Plan every sequence.', 'Arrange & cast on.'];
  const subs = [
    "Name it, pick your yarn and your tool — we'll remember.",
    'A cardigan has a body and two sleeves. A scarf has one part. You decide.',
    "Pick a part, then fill each sequence's rows.",
    'Order the sequences, set the repeats, and you\'re ready to knit.',
  ];

  const next = () => { if (step < 3) setStep(step + 1); else go('knit', { projectId: 'cardigan' }); };

  return (
    <div style={{ minHeight: '100%', position: 'relative' }}>
      {/* top bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '24px 40px 0' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <SkeinLogo size={32} fg={t.brick} accent={t.mustard}/>
          <span style={{ fontFamily: FontDisplay, fontSize: 22, color: t.brick }}>Cast on</span>
        </div>
        <button onClick={() => go('home')} style={{ display: 'inline-flex', alignItems: 'center', gap: 7, background: 'none', border: 'none', cursor: 'pointer', color: t.inkSoft, fontFamily: FontBody, fontWeight: 600, fontSize: 14 }}>
          Cancel <Icon name="x" size={18} color={t.inkSoft}/>
        </button>
      </div>

      <div style={{ display: 'flex', gap: 40, padding: '28px 40px 120px', maxWidth: 1240, margin: '0 auto' }}>
        {/* step rail */}
        <div style={{ width: 240, flexShrink: 0 }}>
          <div style={{ position: 'sticky', top: 20 }}>
            <StepRail step={step} setStep={setStep}/>
          </div>
        </div>

        {/* content */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <Eyebrow color={t.mustardDk} style={{ marginBottom: 10 }}>Step {step + 1} of 4 · {SETUP_STEPS[step].label}</Eyebrow>
          <div style={{ fontFamily: FontDisplay, fontSize: 38, color: t.brick, letterSpacing: '-0.01em', lineHeight: 1.02 }}>{titles[step]}</div>
          <div style={{ fontSize: 15.5, color: t.inkSoft, marginTop: 10, marginBottom: 30, maxWidth: 620, lineHeight: 1.45 }}>{subs[step]}</div>

          {step === 0 && <Step1 data={data} set={set}/>}
          {step === 1 && <Step2 data={data} set={set}/>}
          {step === 2 && <Step3 data={data} set={set} openPicker={() => setPicker(true)} openRemove={setRemove}/>}
          {step === 3 && <Step4 data={data}/>}
        </div>
      </div>

      {/* footer */}
      <div style={{ position: 'sticky', bottom: 0, background: t.bg, borderTop: `1px solid ${t.rule}`, padding: '16px 40px' }}>
        <div style={{ maxWidth: 1240, margin: '0 auto', display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ display: 'flex', gap: 6, flex: 1 }}>
            {SETUP_STEPS.map(s => <div key={s.id} style={{ width: 44, height: 6, borderRadius: 4, background: s.id < step ? t.brick : s.id === step ? t.mustard : t.cream2 }}/>)}
          </div>
          {step > 0 && <Btn variant="ghost" size="lg" dark={t.dark} onClick={() => setStep(step - 1)}>Back</Btn>}
          {blocked
            ? <button aria-disabled="true" style={{ height: 52, padding: '0 28px', borderRadius: 14, background: t.dark ? 'rgba(255,122,77,0.18)' : '#E8D6CF', border: `1.5px dashed ${t.brick}`, color: t.brick, fontFamily: FontBody, fontWeight: 700, fontSize: 15, cursor: 'not-allowed', display: 'inline-flex', alignItems: 'center', gap: 8 }}><span style={{ width: 18, height: 18, borderRadius: 999, background: t.brick, color: '#FBF6EC', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontFamily: FontDisplay, fontSize: 12 }}>!</span>Add a project name first</button>
            : <Btn variant="primary" size="lg" icon={step === 3 ? 'play' : 'chevR'} dark={t.dark} onClick={next}>{step === 3 ? 'Cast on!' : `Next: ${SETUP_STEPS[step + 1].label}`}</Btn>}
        </div>
      </div>

      {picker && <StitchPickerModal onClose={() => setPicker(false)}/>}
      {remove === 'row' && <RemoveDialog kind="row" onClose={() => setRemove(null)}/>}
      {remove === 'seq' && <RemoveDialog kind="seq" onClose={() => setRemove(null)}/>}
    </div>
  );
}

Object.assign(window, { SetupWizard });


// ====================== desktop-library.jsx ======================
// Library — browse patterns / sequences / rows, create flows, stitch picker.

const LIB_SEQUENCES = [
  { id: 'stk', title: 'Stockinette body', meta: '4 rows · used in 6 projects', color: 'brick', pattern: ['vline', 'vline', 'vline', 'vline'], craft: 'knit', rows: 4 },
  { id: 'rib', title: '2×2 Rib', meta: '2 rows · used in 11 projects', color: 'mustard', pattern: ['vline', 'vline', 'dash', 'dash'], craft: 'knit', rows: 2 },
  { id: 'seed', title: 'Seed stitch', meta: '2 rows · used in 4 projects', color: 'forest', pattern: ['vline', 'dash', 'vline', 'dash'], craft: 'knit', rows: 2 },
  { id: 'gar', title: 'Garter', meta: '2 rows · used in 9 projects', color: 'brick', pattern: ['vline', 'vline'], craft: 'knit', rows: 2 },
  { id: 'cab', title: 'Cable panel · 6st', meta: '8 rows · used in 2 projects', color: 'mustard', pattern: ['cableL', 'cableL', 'vline', 'vline'], craft: 'knit', rows: 8 },
  { id: 'bob', title: 'Bobble row', meta: '1 row · used in 3 projects', color: 'forest', pattern: ['vline', 'dot', 'vline', 'dot'], craft: 'knit', rows: 1 },
  { id: 'gs', title: 'Granny square ring', meta: '6 rows · used in 7 projects', color: 'brick', pattern: ['cross', 'teeBar', 'teeBar', 'cross'], craft: 'crochet', rows: 6 },
  { id: 'sh', title: 'Shell border', meta: '2 rows · used in 5 projects', color: 'mustard', pattern: ['fan', 'ch', 'fan', 'ch'], craft: 'crochet', rows: 2 },
];
const LIB_PATTERNS = [
  { id: 'gc', title: 'Granny Cardigan v3', meta: '3 parts · 12 sequences', color: 'brick', pattern: ['vline', 'vline', 'dash', 'dash'], craft: 'knit' },
  { id: 'sk', title: 'Sock recipe — short row heel', meta: '2 parts · 8 sequences', color: 'mustard', pattern: ['vline', 'vline', 'vline', 'vline'], craft: 'knit' },
  { id: 'mb', title: 'Magic ring beanie', meta: '1 part · 5 sequences', color: 'forest', pattern: ['cross', 'teeBar', 'teeBar', 'cross'], craft: 'crochet' },
  { id: 'hx', title: 'Hexagon throw', meta: '1 part · 4 sequences', color: 'brick', pattern: ['cross', 'teeBar', 'triUp', 'cross'], craft: 'crochet' },
];
const LIB_ROWS = [
  { name: 'k1, *p2, k1*, rep', notation: 'k1, *p2, k1*, rep', stitches: ['k', 'p', 'p', 'k', 'p', 'p', 'k'], craft: 'knit' },
  { name: 'All knit', notation: 'k all', stitches: ['k', 'k', 'k', 'k', 'k', 'k', 'k'], craft: 'knit' },
  { name: 'All purl', notation: 'p all', stitches: ['p', 'p', 'p', 'p', 'p', 'p', 'p'], craft: 'knit' },
  { name: 'Decrease right', notation: 'k2tog, k to end', stitches: ['k2tog', 'k', 'k', 'k', 'k'], craft: 'knit' },
  { name: 'YO eyelet row', notation: 'k1, yo, k2tog *', stitches: ['k', 'yo', 'k2tog', 'k', 'yo', 'k2tog'], craft: 'knit' },
  { name: 'Granny shell', notation: '3dc, ch1 *', stitches: ['dc', 'dc', 'dc', 'ch', 'dc', 'dc', 'dc'], craft: 'crochet' },
];

// Overflow menu used on every library card.
function CardMenu({ label, onView }) {
  const { t, dark } = useT();
  const [open, setOpen] = React.useState(false);
  return (
    <div style={{ position: 'relative', flexShrink: 0 }}>
      <RIconBtn name="more" tone="plain" size={36} onClick={(e) => { e && e.stopPropagation && e.stopPropagation(); setOpen(o => !o); }}/>
      {open && (
        <>
          <div onClick={(e) => { e.stopPropagation(); setOpen(false); }} style={{ position: 'fixed', inset: 0, zIndex: 40 }}/>
          <div style={{ position: 'absolute', top: 'calc(100% + 6px)', right: 0, zIndex: 50, minWidth: 180, padding: 6, background: t.card, borderRadius: 12, border: `1px solid ${t.rule}`, boxShadow: dark ? '0 16px 40px rgba(0,0,0,0.55)' : '0 16px 40px -10px rgba(43,24,16,0.3)', animation: 'yl-menu 130ms ease', transformOrigin: 'top right' }}>
            {[{ icon: 'book', label: `View ${label}`, fn: onView }, { icon: 'edit', label: 'Edit' }, { icon: 'plus', label: 'Add to project' }, { icon: 'trash', label: 'Delete', danger: true }].map((it, i) => (
              <button key={i} onClick={(e) => { e.stopPropagation(); setOpen(false); it.fn && it.fn(); }} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 11, padding: '9px 11px', borderRadius: 9, border: 'none', cursor: 'pointer', background: 'transparent', textAlign: 'left' }}
                onMouseEnter={(e) => e.currentTarget.style.background = dark ? 'rgba(255,234,200,0.06)' : t.cream2}
                onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
                <Icon name={it.icon} size={16} color={it.danger ? t.brick : t.inkSoft}/>
                <span style={{ fontFamily: FontBody, fontWeight: 600, fontSize: 13.5, color: it.danger ? t.brick : t.ink }}>{it.label}</span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function LibCard({ item, big, onView }) {
  const { t } = useT();
  const cmap = { brick: t.brick, mustard: t.mustard, forest: t.forest };
  return (
    <Card hover pad={18} onClick={onView} style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
      <SwatchTile pattern={item.pattern} color={cmap[item.color]} size={big ? 60 : 52}/>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 16, color: t.ink, letterSpacing: '-0.005em' }}>{item.title}</div>
        <div style={{ fontFamily: FontMono, fontSize: 12, color: t.inkMute, marginTop: 4 }}>{item.meta}</div>
      </div>
      <CardMenu label={big ? 'pattern' : 'sequence'} onView={onView}/>
    </Card>
  );
}

function RowCard({ item, onView }) {
  const { t } = useT();
  return (
    <Card hover pad={16} onClick={onView}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 15, color: t.ink }}>{item.name}</div>
        <CardMenu label="row" onView={onView}/>
      </div>
      <div style={{ display: 'flex', gap: 3, marginTop: 10, flexWrap: 'wrap' }}>
        {item.stitches.map((id, i) => <STile key={i} id={id} w={26} h={32}/>)}
      </div>
      <div style={{ marginTop: 10, fontFamily: FontMono, fontSize: 11.5, color: t.inkMute }}>{item.notation}</div>
    </Card>
  );
}

function LibraryView({ go }) {
  const { t } = useT();
  const [tab, setTab] = React.useState('seq');
  const [craft, setCraft] = React.useState('all');
  const [create, setCreate] = React.useState(false);
  const [detail, setDetail] = React.useState(null);

  const tabSingular = { pat: 'pattern', seq: 'sequence', row: 'row' }[tab];
  const byCraft = (items) => craft === 'all' ? items : items.filter(i => i.craft === craft);
  const seqs = byCraft(LIB_SEQUENCES), pats = byCraft(LIB_PATTERNS), rows = byCraft(LIB_ROWS);

  return (
    <div style={{ padding: '40px 48px 64px', maxWidth: 1100, margin: '0 auto' }}>
      <PageHeader eyebrow="Building blocks" title="Library"
        sub="Reuse what you've already built — patterns, sequences and rows. So you never retype k1, p1 again."
        right={<button onClick={() => setCreate(true)} style={{ display: 'inline-flex', alignItems: 'center', gap: 9, background: t.brick, color: '#FBF6EC', border: 'none', borderRadius: 13, padding: '13px 20px', cursor: 'pointer', fontFamily: FontBody, fontWeight: 700, fontSize: 15, boxShadow: t.dark ? 'none' : `0 8px 20px -10px ${t.brick}` }}><Icon name="plus" size={18} color="#FBF6EC"/> New {tabSingular}</button>}/>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, flexWrap: 'wrap', marginBottom: 24 }}>
        <Segmented value={tab} onChange={setTab} items={[
          { id: 'pat', label: 'Patterns', count: LIB_PATTERNS.length },
          { id: 'seq', label: 'Sequences', count: LIB_SEQUENCES.length },
          { id: 'row', label: 'Rows', count: LIB_ROWS.length },
        ]}/>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <SearchField placeholder="Search by name, stitch, vibe…" width={240}/>
          <div style={{ display: 'flex', gap: 7 }}>
            {[{ id: 'all', label: 'All' }, { id: 'knit', label: 'Knit', icon: 'needle' }, { id: 'crochet', label: 'Crochet', icon: 'loop' }].map(c => (
              <Chip key={c.id} active={craft === c.id} onClick={() => setCraft(c.id)} icon={c.icon} tone="ink" size="sm">{c.label}</Chip>
            ))}
          </div>
        </div>
      </div>

      {tab === 'seq' && <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: 14 }}>{seqs.map(s => <LibCard key={s.id} item={s} onView={() => setDetail({ kind: 'seq', item: s })}/>)}</div>}
      {tab === 'pat' && <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: 14 }}>{pats.map(p => <LibCard key={p.id} item={p} big onView={() => setDetail({ kind: 'pat', item: p })}/>)}</div>}
      {tab === 'row' && <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 14 }}>{rows.map((r, i) => <RowCard key={i} item={r} onView={() => setDetail({ kind: 'row', item: r })}/>)}</div>}

      {create && <CreateModal kind={tab} onClose={() => setCreate(false)}/>}
      {detail && <SeqDetailModal data={detail} onClose={() => setDetail(null)}/>}
    </div>
  );
}

// ─── Stitch picker modal (shared by setup + create) ──────────
const STITCH_GROUPS = [
  { id: 'basic_k', label: 'Knit · basics', ids: ['k', 'p', 'yo', 'sl', 'ns', 'tbl'] },
  { id: 'inc_k', label: 'Knit · increases', ids: ['kfb', 'm1'] },
  { id: 'dec_k', label: 'Knit · decreases', ids: ['k2tog', 'ssk', 'k3tog', 'p2tog'] },
  { id: 'cab_k', label: 'Knit · texture & cables', ids: ['mb', 'c4f', 'c4b'] },
  { id: 'basic_c', label: 'Crochet · basics', ids: ['ch', 'slst', 'sc', 'hdc', 'dc', 'tr', 'dtr'] },
  { id: 'dec_c', label: 'Crochet · decreases', ids: ['sc2tog', 'dc2tog'] },
  { id: 'tex_c', label: 'Crochet · texture', ids: ['pic', 'mr', 'shell', 'vst', 'fpdc', 'bpdc'] },
];

function StitchPickerModal({ onClose, onPick }) {
  const { t } = useT();
  const [filter, setFilter] = React.useState('all');
  const [sel, setSel] = React.useState(null);
  const chips = [{ id: 'all', label: 'All' }, { id: 'knit', label: 'Knit' }, { id: 'crochet', label: 'Crochet' }, { id: 'custom', label: 'Custom' }];
  const groupVisible = (g) => filter === 'all' ? true : filter === 'knit' ? g.id.endsWith('_k') : filter === 'crochet' ? g.id.endsWith('_c') : false;
  const groups = STITCH_GROUPS.filter(groupVisible);
  return (
    <Modal onClose={onClose} width={680}>
      <div style={{ padding: '24px 28px 12px', borderBottom: `1px solid ${t.rule}`, position: 'sticky', top: 0, background: t.bg, zIndex: 2 }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 16 }}>
          <div>
            <div style={{ fontFamily: FontDisplay, fontSize: 28, color: t.brick, letterSpacing: '-0.01em' }}>Pick a stitch</div>
            <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, letterSpacing: '0.08em', textTransform: 'uppercase', marginTop: 4 }}>Tap to add · {Stitches.length} predefined + custom</div>
          </div>
          <RIconBtn name="x" tone="plain" onClick={onClose}/>
        </div>
        <div style={{ display: 'flex', gap: 7 }}>{chips.map(c => <Chip key={c.id} active={filter === c.id} onClick={() => setFilter(c.id)} size="sm">{c.label}</Chip>)}</div>
      </div>
      <div style={{ padding: '18px 28px 24px' }}>
        {filter === 'custom' ? (
          <div style={{ textAlign: 'center', padding: '20px 0' }}>
            <div style={{ fontFamily: FontDisplay, fontSize: 22, color: t.brick, marginBottom: 8 }}>Roll your own.</div>
            <div style={{ fontSize: 14, color: t.inkSoft, maxWidth: 380, margin: '0 auto 18px', lineHeight: 1.5 }}>Got a stitch that's not in the list — fisherman's rib, your grandma's secret? Define it once, reuse it forever.</div>
            <Btn variant="primary" size="md" icon="plus" dark={t.dark} onClick={onClose}>Define a custom stitch</Btn>
          </div>
        ) : (
          <>
            {groups.map(g => {
              const items = g.ids.map(id => Stitches.find(s => s.id === id)).filter(Boolean);
              return (
                <div key={g.id} style={{ marginBottom: 18 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}><Eyebrow>{g.label}</Eyebrow><span style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute }}>{items.length}</span></div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 8 }}>
                    {items.map((s, i) => {
                      const c = [t.brick, t.mustard, t.forest, t.brickDk][i % 4];
                      const on = sel === s.id;
                      return (
                        <button key={s.id} onClick={() => { setSel(s.id); onPick && onPick(s.id); }} style={{ background: on ? c : t.card, border: on ? `1.5px solid ${c}` : `1px solid ${t.rule}`, borderRadius: 12, padding: '10px 4px 8px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
                          <div style={{ width: 36, height: 36, borderRadius: 10, background: on ? 'rgba(255,255,255,0.18)' : c, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><StitchGlyph symbol={s.symbol} color="#FBF6EC" size={20}/></div>
                          <span style={{ fontFamily: FontMono, fontSize: 10.5, fontWeight: 700, color: on ? '#FBF6EC' : t.inkSoft }}>{s.abbr}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
            <button onClick={onClose} style={{ width: '100%', background: 'transparent', border: `1.5px dashed ${t.brick}`, color: t.brick, padding: 13, borderRadius: 12, fontFamily: FontBody, fontSize: 14, fontWeight: 600, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 7 }}><Icon name="plus" size={15} color={t.brick}/> Define a custom stitch</button>
          </>
        )}
      </div>
    </Modal>
  );
}

// ─── Sequence/Pattern/Row detail modal ───────────────────────
function SeqDetailModal({ data, onClose }) {
  const { t } = useT();
  const { kind, item } = data;
  const cmap = { brick: t.brick, mustard: t.mustard, forest: t.forest };
  const c = cmap[item.color] || t.brick;
  const sampleRows = kind === 'row'
    ? [item]
    : [{ label: 'Row 1', stitches: ['k', 'k', 'p', 'p', 'k', 'k', 'p', 'p'] }, { label: 'Row 2', stitches: ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'] }, { label: 'Row 3', stitches: ['k', 'yo', 'k2tog', 'k', 'k', 'yo', 'k2tog', 'k'] }, { label: 'Row 4', stitches: ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'] }];
  return (
    <Modal onClose={onClose} width={560}>
      <div style={{ padding: '24px 28px', display: 'flex', alignItems: 'center', gap: 16, borderBottom: `1px solid ${t.rule}` }}>
        {kind === 'row'
          ? <div style={{ width: 56, height: 56, borderRadius: 14, background: t.cream2, border: `1px solid ${t.rule}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="library" size={26} color={t.brick}/></div>
          : <SwatchTile pattern={item.pattern} color={c} size={56}/>}
        <div style={{ flex: 1, minWidth: 0 }}>
          <Eyebrow color={t.mustardDk}>{kind === 'pat' ? 'Pattern' : kind === 'seq' ? 'Sequence' : 'Row'}</Eyebrow>
          <div style={{ fontFamily: FontDisplay, fontSize: 26, color: t.ink, letterSpacing: '-0.01em', lineHeight: 1.05, marginTop: 4 }}>{item.title || item.name}</div>
          <div style={{ fontFamily: FontMono, fontSize: 12, color: t.inkMute, marginTop: 4 }}>{item.meta || item.notation}</div>
        </div>
        <RIconBtn name="x" tone="plain" onClick={onClose}/>
      </div>
      <div className="yl-scroll" style={{ padding: '20px 28px', maxHeight: '52vh', overflow: 'auto' }}>
        <Eyebrow style={{ marginBottom: 14 }}>{kind === 'row' ? 'The stitches' : `${kind === 'pat' ? 'A peek inside' : 'Every row'}`}</Eyebrow>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {sampleRows.map((r, ri) => (
            <div key={ri} style={{ background: t.card, border: `1px solid ${t.rule}`, borderRadius: 12, padding: '10px 12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: r.stitches.length ? 8 : 0 }}>
                <span style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 13, color: t.ink }}>{r.label}</span>
                <span style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute }}>· {r.stitches.length} sts</span>
              </div>
              <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>{r.stitches.map((id, i) => <STile key={i} id={id} w={26} h={34}/>)}</div>
              <div style={{ marginTop: 8, fontFamily: FontMono, fontSize: 11, color: t.inkMute }}>{runsNotation(r.stitches)}</div>
            </div>
          ))}
        </div>
      </div>
      <div style={{ padding: '16px 28px 24px', borderTop: `1px solid ${t.rule}`, display: 'flex', gap: 10 }}>
        <Btn variant="ghost" size="md" dark={t.dark} onClick={onClose}>Close</Btn>
        <Btn variant="primary" size="md" full icon="plus" dark={t.dark} onClick={onClose}>Add to a project</Btn>
      </div>
    </Modal>
  );
}

Object.assign(window, { LibraryView, StitchPickerModal, SeqDetailModal, LIB_SEQUENCES, LIB_PATTERNS, LIB_ROWS });


// ====================== desktop-extra.jsx ======================
// Desktop extras — create modals, destructive dialogs, Settings, Welcome.

// ─── Create modal (New row / sequence / pattern) ─────────────
function CreateModal({ kind, onClose }) {
  const { t, dark } = useT();
  const [name, setName] = React.useState(kind === 'row' ? 'Eyelet rib' : kind === 'seq' ? 'Moss stitch panel' : 'Raglan pullover');
  const [craft, setCraft] = React.useState('knit');
  const [picker, setPicker] = React.useState(false);
  const titles = { row: 'New row', seq: 'New sequence', pat: 'New pattern' };
  const subs = {
    row: 'A single line of stitches — saved once, reused across every project.',
    seq: 'A stack of rows — a rib, a body, a border — saved together as one block.',
    pat: 'The whole make — parts, each with its own sequences. Your master recipe.',
  };
  const ready = name.trim().length > 0;

  const fieldStyle = { width: '100%', background: t.card, border: `1.5px solid ${name ? t.brick : t.rule}`, borderRadius: 12, padding: '12px 14px', fontFamily: FontBody, fontSize: 16, color: t.ink, outline: 'none' };

  const rowStitches = ['k', 'p', 'yo', 'k2tog', 'p', 'k'];
  const seqRows = [{ label: 'Row 1', stitches: ['k', 'p', 'k', 'p', 'k', 'p', 'k', 'p'] }, { label: 'Row 2', stitches: ['p', 'k', 'p', 'k', 'p', 'k', 'p', 'k'], active: true }, { label: 'Row 3', stitches: [] }];
  const patParts = [
    { name: 'Body', color: t.brick, active: true, seqs: [{ n: 1, name: 'Ribbed hem', color: t.mustard, rows: 2 }, { n: 2, name: 'Stockinette yoke', color: t.brick, rows: 6, active: true }, { n: 3, name: 'Raglan increases', color: t.forest, rows: 4 }] },
    { name: 'Sleeve 1', color: t.mustard, seqCount: 2 },
    { name: 'Sleeve 2', color: t.forest, seqCount: 2 },
  ];
  const quick = ['k', 'p', 'yo', 'k2tog', 'ssk', 'sl'];

  return (
    <Modal onClose={onClose} width={kind === 'pat' ? 680 : 600}>
      <div style={{ padding: '22px 28px', borderBottom: `1px solid ${t.rule}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, background: t.bg, zIndex: 2 }}>
        <div>
          <Eyebrow color={t.mustardDk}>{titles[kind]} · draft</Eyebrow>
          <div style={{ fontFamily: FontDisplay, fontSize: 26, color: t.brick, letterSpacing: '-0.01em', marginTop: 4 }}>{titles[kind]}</div>
        </div>
        <RIconBtn name="x" tone="plain" onClick={onClose}/>
      </div>

      <div className="yl-scroll" style={{ padding: '20px 28px', maxHeight: '60vh', overflow: 'auto' }}>
        <div style={{ fontSize: 14, color: t.inkSoft, lineHeight: 1.45, marginBottom: 20 }}>{subs[kind]}</div>

        {/* live preview tile */}
        <div style={{ background: t.card, borderRadius: 16, padding: 16, border: `1.5px solid ${t.brick}`, boxShadow: `0 8px 22px -16px ${t.brick}`, marginBottom: 22, display: 'flex', gap: 14, alignItems: 'center' }}>
          {kind === 'seq' && <SwatchTile pattern={['vline', 'dash', 'dash', 'vline']} color={t.forest} size={52}/>}
          {kind === 'pat' && <div style={{ width: 52, height: 52, borderRadius: 13, background: t.brick, color: '#FBF6EC', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: FontDisplay, fontSize: 22, flexShrink: 0 }}>3</div>}
          <div style={{ flex: 1, minWidth: 0 }}>
            <Eyebrow>Live preview</Eyebrow>
            <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 16, color: t.ink, marginTop: 4 }}>{name || 'Untitled'}</div>
            {kind === 'row' && <div style={{ display: 'flex', gap: 3, marginTop: 8, flexWrap: 'wrap' }}>{rowStitches.map((id, i) => <STile key={i} id={id} w={22} h={28}/>)}</div>}
            {kind === 'seq' && <div style={{ fontFamily: FontMono, fontSize: 11.5, color: t.inkMute, marginTop: 4 }}>2 rows · 1 in progress</div>}
            {kind === 'pat' && <div style={{ fontFamily: FontMono, fontSize: 11.5, color: t.inkMute, marginTop: 4 }}>3 parts · 5 sequences</div>}
          </div>
        </div>

        {/* identity */}
        <FieldLabel hint="shown in your library">Name &amp; craft</FieldLabel>
        <input value={name} onChange={(e) => setName(e.target.value.slice(0, 48))} style={fieldStyle}/>
        <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
          {[{ id: 'knit', label: 'Knit', icon: 'needle' }, { id: 'crochet', label: 'Crochet', icon: 'loop' }].map(c => (
            <button key={c.id} onClick={() => setCraft(c.id)} style={{ flex: 1, padding: '11px 14px', borderRadius: 12, cursor: 'pointer', background: craft === c.id ? t.brick : t.card, color: craft === c.id ? '#FBF6EC' : t.ink, border: craft === c.id ? 'none' : `1px solid ${t.rule}`, fontFamily: FontBody, fontSize: 14.5, fontWeight: 700, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
              <Icon name={c.icon} size={16} color={craft === c.id ? '#FBF6EC' : t.brick}/>{c.label}
            </button>
          ))}
        </div>

        {/* builder */}
        {kind === 'row' && (
          <div style={{ marginTop: 22 }}>
            <FieldLabel hint={`${rowStitches.length} stitches`}>Build the row</FieldLabel>
            <div style={{ background: t.cream2, border: `1px solid ${t.rule}`, borderRadius: 16, padding: 14 }}>
              <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', alignItems: 'center' }}>
                {rowStitches.map((id, i) => <STile key={i} id={id} w={30} h={40} active={i === rowStitches.length - 1}/>)}
                <div style={{ width: 30, height: 40, borderRadius: 7, border: `1.5px dashed ${t.brick}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><div style={{ width: 2, height: 20, background: t.brick }}/></div>
              </div>
            </div>
            <div style={{ marginTop: 8, fontFamily: FontMono, fontSize: 12, color: t.inkMute }}>Written as <span style={{ color: t.ink }}>{runsNotation(rowStitches)}</span> — rep to end</div>
          </div>
        )}
        {kind === 'seq' && (
          <div style={{ marginTop: 22 }}>
            <FieldLabel hint="3 rows">Rows in this sequence</FieldLabel>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingLeft: 14, borderLeft: `2px solid ${t.cream2}`, marginLeft: 10 }}>
              {seqRows.map((r, ri) => {
                const empty = r.stitches.length === 0;
                return (
                  <div key={ri} style={{ background: t.card, border: r.active ? `2px solid ${t.brick}` : `1px solid ${t.rule}`, borderRadius: 14, padding: '10px 12px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: empty ? 0 : 9 }}>
                      <Icon name="grip" size={14} color={t.inkMute}/>
                      <span style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 13, color: r.active ? t.brick : t.ink }}>{r.label}{r.active && ' ✱'}</span>
                      <span style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute }}>· {r.stitches.length} sts</span>
                    </div>
                    {empty ? <div style={{ fontFamily: FontMono, fontSize: 11.5, color: t.inkMute, fontStyle: 'italic' }}>empty · tap a stitch below to start</div>
                      : <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>{r.stitches.map((id, i) => <STile key={i} id={id} w={26} h={34}/>)}</div>}
                  </div>
                );
              })}
            </div>
          </div>
        )}
        {kind === 'pat' && (
          <div style={{ marginTop: 22 }}>
            <FieldLabel hint="3 parts">Parts &amp; sequences</FieldLabel>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {patParts.map((p, pi) => (
                <div key={pi}>
                  <div style={{ background: t.card, border: p.active ? `2px solid ${t.brick}` : `1px solid ${t.rule}`, borderRadius: 14, padding: '11px 14px', display: 'flex', alignItems: 'center', gap: 11 }}>
                    <Icon name="grip" size={17} color={t.inkMute}/>
                    <span style={{ width: 32, height: 32, borderRadius: 9, background: p.color, color: '#FBF6EC', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontFamily: FontDisplay, fontSize: 15 }}>{pi + 1}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 15, color: t.ink }}>{p.name}</div>
                      <div style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute, marginTop: 1 }}>{(p.seqs ? p.seqs.length : p.seqCount)} sequences{p.active ? ' · editing ✱' : ''}</div>
                    </div>
                    <Icon name={p.active ? 'chevDown' : 'edit'} size={16} color={t.inkSoft}/>
                  </div>
                  {p.active && p.seqs && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 7, paddingLeft: 14, borderLeft: `2px solid ${t.cream2}`, marginLeft: 16, marginTop: 8 }}>
                      {p.seqs.map(sq => (
                        <div key={sq.n} style={{ background: t.card, border: sq.active ? `1.5px solid ${t.brick}` : `1px solid ${t.rule}`, borderRadius: 11, padding: '9px 11px', display: 'flex', alignItems: 'center', gap: 10 }}>
                          <span style={{ width: 26, height: 26, borderRadius: 8, background: sq.color, color: '#FBF6EC', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontFamily: FontDisplay, fontSize: 13 }}>{sq.n}</span>
                          <span style={{ flex: 1, fontFamily: FontBody, fontWeight: 700, fontSize: 13.5, color: sq.active ? t.brick : t.ink }}>{sq.name}</span>
                          <span style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute }}>{sq.rows} rows</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* footer / dock */}
      {kind === 'pat' ? (
        <div style={{ padding: '16px 28px 24px', borderTop: `1px solid ${t.rule}`, display: 'flex', gap: 10 }}>
          <Btn variant="ghost" size="lg" dark={dark} onClick={onClose}>Cancel</Btn>
          <Btn variant="primary" size="lg" full icon="save" dark={dark} onClick={onClose}>Save pattern to library</Btn>
        </div>
      ) : (
        <div style={{ padding: '14px 28px 22px', borderTop: `1px solid ${t.rule}`, background: t.bg }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <span style={{ fontFamily: FontMono, fontSize: 10.5, color: t.brick, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase' }}>Tap to add to {kind === 'row' ? 'this row' : 'Row 2'} ✱</span>
            <button onClick={() => setPicker(true)} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', cursor: 'pointer', color: t.brick, fontFamily: FontMono, fontSize: 11.5, fontWeight: 700 }}>All 30 stitches <Icon name="chevR" size={13} color={t.brick}/></button>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8 }}>
            {quick.map(id => {
              const s = Stitches.find(x => x.id === id); const c = stitchHue(t, id);
              return (
                <button key={id} onClick={() => setPicker(true)} style={{ background: t.card, border: `1px solid ${t.rule}`, borderRadius: 10, padding: '7px 0', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, cursor: 'pointer' }}>
                  <div style={{ width: 32, height: 32, borderRadius: 9, background: c, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><StitchGlyph symbol={s.symbol} color="#FBF6EC" size={18}/></div>
                  <span style={{ fontFamily: FontMono, fontSize: 10, color: t.inkSoft, fontWeight: 700 }}>{s.abbr}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
      {picker && <StitchPickerModal onClose={() => setPicker(false)}/>}
    </Modal>
  );
}

// ─── Destructive confirm dialog ──────────────────────────────
function RemoveDialog({ kind, onClose }) {
  const { t, dark } = useT();
  const isSeq = kind === 'seq';
  const rows = [
    { label: 'Row 1', stitches: ['k', 'k', 'k', 'k', 'k', 'k', 'k', 'k', 'k', 'k'] },
    { label: 'Row 2', stitches: ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'] },
    { label: 'Row 3', stitches: ['k', 'yo', 'k2tog', 'k', 'k', 'k', 'k', 'yo', 'k2tog', 'k'] },
  ];
  const single = rows[1];
  const totalSts = rows.reduce((a, r) => a + r.stitches.length, 0);
  return (
    <Modal onClose={onClose} width={460}>
      <div style={{ padding: '26px 26px 18px', background: dark ? 'rgba(255,122,77,0.08)' : '#FBEFEA', borderBottom: `1px solid ${dark ? 'rgba(255,122,77,0.18)' : 'rgba(156,61,46,0.15)'}`, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
        <div style={{ width: 60, height: 60, borderRadius: 17, background: t.brick, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: `0 10px 24px -10px ${t.brick}`, transform: 'rotate(-4deg)' }}><Icon name="trash" size={28} color="#FBF6EC" stroke={2.2}/></div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: FontDisplay, fontSize: 26, color: t.brick, letterSpacing: '-0.01em', lineHeight: 1.05 }}>{isSeq ? 'Delete this whole sequence?' : 'Remove this row?'}</div>
          <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, letterSpacing: '0.12em', textTransform: 'uppercase', marginTop: 7 }}>No undo · {isSeq ? `${rows.length} rows · ${totalSts} stitches` : '10 stitches'} lost</div>
        </div>
      </div>
      <div style={{ padding: '18px 26px 6px' }}>
        <div style={{ background: t.card, border: `1px solid ${t.rule}`, borderRadius: 12, padding: '12px 14px' }}>
          {isSeq ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {rows.map((r, ri) => (
                <div key={ri} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontFamily: FontMono, fontSize: 9.5, fontWeight: 700, color: t.inkMute, width: 28 }}>{r.label.replace('Row ', 'R')}</span>
                  <div style={{ display: 'flex', gap: 2.5, flexWrap: 'wrap' }}>{r.stitches.map((id, i) => <STile key={i} id={id} w={15} h={19}/>)}</div>
                </div>
              ))}
            </div>
          ) : (
            <>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 9 }}>
                <span style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 13, color: t.ink }}>{single.label}</span>
                <span style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute }}>· {single.stitches.length} sts · Stockinette body</span>
              </div>
              <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>{single.stitches.map((id, i) => <STile key={i} id={id} w={22} h={28}/>)}</div>
            </>
          )}
        </div>
        <div style={{ marginTop: 12, fontSize: 13.5, color: t.inkSoft, textAlign: 'center', lineHeight: 1.45 }}>{isSeq ? 'Every row inside moves with it. Other sequences shift up — they aren\'t affected.' : 'The rows above and below shift up — neighboring rows aren\'t affected.'}</div>
      </div>
      <div style={{ padding: '16px 26px 24px', display: 'flex', flexDirection: 'column', gap: 9 }}>
        <button onClick={onClose} style={{ height: 50, borderRadius: 14, border: 'none', cursor: 'pointer', background: t.brick, color: '#FBF6EC', fontFamily: FontBody, fontWeight: 700, fontSize: 15, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8, boxShadow: `0 8px 18px -10px ${t.brick}` }}>
          <Icon name="trash" size={16} color="#FBF6EC"/> Yes, {isSeq ? 'delete sequence' : 'remove row'}
        </button>
        <button onClick={onClose} style={{ height: 46, borderRadius: 12, cursor: 'pointer', background: 'transparent', color: t.ink, border: `1.5px solid ${t.rule}`, fontFamily: FontBody, fontWeight: 600, fontSize: 14.5 }}>Keep it</button>
      </div>
    </Modal>
  );
}

// ─── Settings ────────────────────────────────────────────────
function SettingsRow({ icon, iconColor, title, value }) {
  const { t } = useT();
  return (
    <Card hover pad={16} onClick={() => {}} style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
      <div style={{ width: 42, height: 42, borderRadius: 12, background: t.cream2, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name={icon} size={21} color={iconColor}/></div>
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 15, color: t.ink }}>{title}</div>
        <div style={{ fontFamily: FontMono, fontSize: 12, color: t.inkMute, marginTop: 2 }}>{value}</div>
      </div>
      <Icon name="chevR" size={17} color={t.inkMute}/>
    </Card>
  );
}

function SettingsView({ go }) {
  const { t, dark, setDark } = useT();
  return (
    <div style={{ padding: '40px 48px 64px', maxWidth: 880, margin: '0 auto' }}>
      <PageHeader eyebrow="The cozy customization corner" title="Settings" sub="Make YarnLog yours. Theme, language, and an optional account — no pestering, ever."/>

      <Eyebrow style={{ marginBottom: 14 }}>Appearance</Eyebrow>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 14 }}>
        {[{ id: 'light', label: 'Light', dk: false }, { id: 'dark', label: 'Dark', dk: true }, { id: 'auto', label: 'Auto', dk: null }].map(opt => {
          const active = opt.dk === dark || (opt.id === 'auto' && false);
          const lt = SkeinTokens.light, dt = SkeinTokens.dark;
          return (
            <button key={opt.id} onClick={() => opt.dk != null && setDark(opt.dk)} style={{ background: t.card, borderRadius: 16, padding: 12, border: active ? `2px solid ${t.brick}` : `1px solid ${t.rule}`, cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
              <div style={{ width: '100%', height: 64, borderRadius: 11, background: opt.id === 'auto' ? `linear-gradient(120deg, ${lt.bg} 0 50%, ${dt.bg} 50% 100%)` : opt.dk ? dt.bg : lt.bg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <div style={{ width: 30, height: 30, borderRadius: 15, background: opt.id === 'auto' ? `linear-gradient(120deg, ${lt.brick} 0 50%, ${dt.brick} 50% 100%)` : opt.dk ? dt.brick : lt.brick }}/>
              </div>
              <span style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 13.5, color: active ? t.brick : t.ink }}>{opt.label}</span>
            </button>
          );
        })}
      </div>
      <Tip style={{ marginBottom: 30 }}><b style={{ color: t.ink }}>Dark mode</b> shifts everything to a deep warm red so your eyes stay relaxed during late-night knit-alongs. <b style={{ color: t.ink }}>Auto</b> follows your system — light by day, dark at night.</Tip>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 30 }}>
        <SettingsRow icon="globe" iconColor={t.forest} title="Language" value="English (US)"/>
        <SettingsRow icon="needle" iconColor={t.brick} title="Default craft" value="Knit · Metric mm"/>
        <SettingsRow icon="bulb" iconColor={t.mustardDk} title="Hold time to advance" value="1.4 seconds"/>
      </div>

      {/* account */}
      <div style={{ background: `linear-gradient(180deg, ${t.cream2} 0%, ${t.card} 100%)`, borderRadius: 22, padding: 24, border: `1px solid ${t.rule}`, marginBottom: 30 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 10 }}>
          <div style={{ width: 46, height: 46, borderRadius: 13, background: t.brick, color: '#FBF6EC', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="cloud" size={24} color="#FBF6EC"/></div>
          <div>
            <div style={{ fontFamily: FontDisplay, fontSize: 22, color: t.brick }}>Cloud backup</div>
            <div style={{ fontFamily: FontMono, fontSize: 11.5, color: t.inkMute }}>Totally optional. Always.</div>
          </div>
          <div style={{ flex: 1 }}/>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '6px 12px', borderRadius: 999, background: dark ? 'rgba(136,185,140,0.12)' : 'rgba(63,107,74,0.1)', border: `1px solid ${t.forest}33`, color: t.forest, fontFamily: FontMono, fontSize: 10.5, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            <span style={{ width: 6, height: 6, borderRadius: 3, background: t.forest }}/>synced
          </div>
        </div>
        <div style={{ fontSize: 14, color: t.inkSoft, lineHeight: 1.5, marginBottom: 16 }}>Signed in as <b style={{ color: t.ink }}>marigold@example.com</b> — projects sync across devices and your pattern library is backed up.</div>
        <div style={{ display: 'flex', gap: 10 }}>
          <Btn variant="ghost" size="md" dark={dark}>Manage account</Btn>
          <Btn variant="ghost" size="md" dark={dark}>Sign out</Btn>
        </div>
      </div>

      <Eyebrow style={{ marginBottom: 14 }}>More</Eyebrow>
      <Card pad={0} style={{ overflow: 'hidden' }}>
        {[{ icon: 'save', label: 'Export pattern as PDF' }, { icon: 'sparkle', label: 'YarnLog Pro · ad-free forever', accent: true }, { icon: 'user', label: 'Tell a friend (please?)' }, { icon: 'book', label: 'The little knitting glossary', last: true }].map((it, i) => (
          <div key={i} style={{ padding: '15px 18px', display: 'flex', alignItems: 'center', gap: 13, borderBottom: it.last ? 'none' : `1px solid ${t.rule}`, cursor: 'pointer' }}>
            <Icon name={it.icon} size={19} color={it.accent ? t.mustardDk : t.inkSoft}/>
            <span style={{ flex: 1, fontFamily: FontBody, fontSize: 14.5, color: t.ink, fontWeight: it.accent ? 700 : 500 }}>{it.label}</span>
            <Icon name="chevR" size={15} color={t.inkMute}/>
          </div>
        ))}
      </Card>

      <div style={{ textAlign: 'center', fontFamily: FontMono, fontSize: 10.5, color: t.inkMute, letterSpacing: '0.14em', textTransform: 'uppercase', marginTop: 26 }}>YarnLog 1.0 · made with yarn &amp; code</div>
    </div>
  );
}

// ─── Welcome / first launch ──────────────────────────────────
function WelcomeView({ go }) {
  const { t, dark } = useT();
  return (
    <div style={{ minHeight: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 48 }}>
      <div style={{ maxWidth: 520, textAlign: 'center' }}>
        <div style={{ position: 'relative', display: 'inline-block', marginBottom: 28 }}>
          <SkeinLogo size={132} fg={t.brick} accent={t.mustard}/>
          <div style={{ position: 'absolute', top: -8, left: -26, fontFamily: FontMono, fontSize: 11, color: t.mustardDk, transform: 'rotate(-12deg)' }}>* * *</div>
          <div style={{ position: 'absolute', bottom: -6, right: -30, fontFamily: FontMono, fontSize: 11, color: t.forest, transform: 'rotate(8deg)' }}>// // //</div>
        </div>
        <div style={{ fontFamily: FontDisplay, fontSize: 56, color: t.brick, lineHeight: 0.95, letterSpacing: '-0.02em' }}>Welcome to YarnLog.</div>
        <div style={{ fontFamily: FontDisplay, fontSize: 19, color: t.mustardDk, marginTop: 14, letterSpacing: '0.04em' }}>stitch happens.</div>
        <div style={{ fontSize: 16, color: t.inkSoft, marginTop: 20, lineHeight: 1.5, maxWidth: 420, margin: '20px auto 0' }}>Build a pattern, hit start, and we'll keep your place — row by row, repeat by repeat. Both hands free for the needles.</div>
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', marginTop: 36 }}>
          <Btn variant="primary" size="lg" icon="plus" dark={dark} onClick={() => go('setup')}>Cast on first project</Btn>
          <Btn variant="ghost" size="lg" icon="book" dark={dark} onClick={() => go('library')}>Peek at the library</Btn>
        </div>
        <div style={{ marginTop: 30, fontFamily: FontMono, fontSize: 11.5, color: t.inkMute, letterSpacing: '0.1em', textTransform: 'uppercase' }}>no account needed · ever</div>
      </div>
    </div>
  );
}

Object.assign(window, { CreateModal, RemoveDialog, SettingsView, WelcomeView, FieldLabel });


// ====================== desktop-shell.jsx ======================
// Desktop shell — brick left sidebar, theme system, view router.

// ─── Shared sample data ──────────────────────────────────────
const YL_PROJECTS = [
  { id: 'cardigan', name: 'The Granny Cardigan', sub: 'Bulky merino · 4.5mm', color: 'brick', tag: 'In progress',
    parts: ['Back', 'Left front', 'Right front', 'Sleeves', 'Button band'], craft: 'knit', row: 12, total: 40, pct: 30 },
  { id: 'socks', name: 'Saturday Socks', sub: 'Sport · 2.25mm DPN', color: 'mustard', tag: 'In progress',
    parts: ['Cuff', 'Leg', 'Heel', 'Foot', 'Toe'], craft: 'knit', row: 48, total: 64, pct: 75 },
  { id: 'blanket', name: "Hank's Blanket", sub: 'Chunky · 8mm hook', color: 'forest', tag: 'Just started',
    parts: ['Body', 'Border'], craft: 'crochet', row: 4, total: 120, pct: 3 },
  { id: 'beanie', name: 'Pumpkin Beanie', sub: 'Worsted · 5mm', color: 'ink', tag: 'Finished',
    parts: ['Brim', 'Body', 'Crown'], craft: 'knit', row: 88, total: 88, pct: 100 },
];

window.YL_PROJECTS = YL_PROJECTS;

// ─── Sidebar ─────────────────────────────────────────────────
function Sidebar({ route, go, dark, setDark, collapsed }) {
  const t = pickT(dark);
  const onBrick = !dark;
  // Sidebar palette adapts to theme. Light = saturated brick rail; dark = deep card rail.
  const sb = onBrick ? {
    bg: 'linear-gradient(176deg, #A8442F 0%, #7A2C1F 100%)',
    text: 'rgba(251,246,236,0.72)', textStrong: '#FBF6EC', mute: 'rgba(251,246,236,0.5)',
    hover: 'rgba(251,246,236,0.10)', active: 'rgba(251,246,236,0.16)', activeText: '#FBF6EC',
    bar: t.mustard, border: 'rgba(0,0,0,0.18)', cardBg: 'rgba(0,0,0,0.16)',
  } : {
    bg: t.bgAlt, text: t.inkSoft, textStrong: t.ink, mute: t.inkMute,
    hover: 'rgba(255,234,200,0.05)', active: 'rgba(255,122,77,0.13)', activeText: t.brick,
    bar: t.brick, border: t.rule, cardBg: t.card,
  };

  const NavItem = ({ icon, label, view, badge }) => {
    const active = route.view === view || (view === 'home' && route.view === 'knit');
    const [h, setH] = React.useState(false);
    return (
      <button onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)} onClick={() => go(view)} title={collapsed ? label : undefined}
        style={{
          position: 'relative', width: '100%', display: 'flex', alignItems: 'center', gap: 13,
          padding: collapsed ? '12px 0' : '12px 14px', justifyContent: collapsed ? 'center' : 'flex-start',
          borderRadius: 13, border: 'none', cursor: 'pointer', textAlign: 'left',
          background: active ? sb.active : (h ? sb.hover : 'transparent'),
          color: active ? sb.activeText : sb.text, transition: 'background 120ms ease, color 120ms ease',
        }}>
        {active && <div style={{ position: 'absolute', left: -10, top: '50%', transform: 'translateY(-50%)', width: 4, height: 22, borderRadius: 3, background: sb.bar }}/>}
        <Icon name={icon} size={21} color={active ? sb.activeText : sb.text} stroke={active ? 2.3 : 2}/>
        {!collapsed && <span style={{ fontFamily: FontBody, fontWeight: active ? 700 : 600, fontSize: 15, letterSpacing: '-0.005em', flex: 1 }}>{label}</span>}
        {!collapsed && badge != null && (
          <span style={{ fontFamily: FontMono, fontSize: 10.5, fontWeight: 700, color: sb.mute, background: sb.cardBg, padding: '2px 7px', borderRadius: 7 }}>{badge}</span>
        )}
      </button>
    );
  };

  const active = YL_PROJECTS.filter(p => p.tag !== 'Finished').length;

  return (
    <aside style={{
      width: collapsed ? 76 : 248, flexShrink: 0, height: '100%',
      background: sb.bg, borderRight: `1px solid ${sb.border}`,
      display: 'flex', flexDirection: 'column', padding: collapsed ? '20px 14px' : '22px 18px',
      transition: 'width 200ms ease',
    }}>
      {/* Wordmark */}
      <button onClick={() => go('home')} style={{
        display: 'flex', alignItems: 'center', gap: 11, background: 'none', border: 'none', cursor: 'pointer',
        padding: 0, marginBottom: 28, justifyContent: collapsed ? 'center' : 'flex-start',
      }}>
        <SkeinLogo size={collapsed ? 38 : 40} fg={onBrick ? '#FBF6EC' : t.brick} accent={t.mustard}/>
        {!collapsed && (
          <div style={{ textAlign: 'left' }}>
            <div style={{ fontFamily: FontDisplay, fontSize: 26, color: sb.textStrong, lineHeight: 0.9, letterSpacing: '-0.01em' }}>YarnLog</div>
            <div style={{ fontFamily: FontDisplay, fontSize: 10.5, color: onBrick ? t.mustard : t.mustardDk, letterSpacing: '0.04em', marginTop: 2 }}>stitch happens.</div>
          </div>
        )}
      </button>

      {/* Cast on CTA */}
      <button onClick={() => go('setup')} title={collapsed ? 'Cast on' : undefined} style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9,
        background: t.mustard, color: t.ink, border: 'none', borderRadius: 14,
        padding: collapsed ? '12px 0' : '13px 16px', cursor: 'pointer', marginBottom: 22,
        fontFamily: FontBody, fontWeight: 700, fontSize: 15, letterSpacing: '-0.005em',
        boxShadow: onBrick ? '0 8px 20px -8px rgba(0,0,0,0.4)' : 'none',
      }}>
        <Icon name="plus" size={19} color={t.ink} stroke={2.4}/>
        {!collapsed && 'Cast on'}
      </button>

      {!collapsed && <div style={{ fontFamily: FontMono, fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: sb.mute, padding: '0 4px 10px' }}>Workspace</div>}
      <nav style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <NavItem icon="home" label="Projects" view="home" badge={active}/>
        <NavItem icon="library" label="Library" view="library" badge={44}/>
        <NavItem icon="settings" label="Settings" view="settings"/>
      </nav>

      <div style={{ flex: 1 }}/>

      {/* Theme toggle */}
      <div style={{
        display: 'flex', gap: 4, background: sb.cardBg, borderRadius: 12, padding: 4, marginBottom: 14,
        flexDirection: collapsed ? 'column' : 'row',
      }}>
        {[{ id: false, icon: 'sun', label: 'Light' }, { id: true, icon: 'moon', label: 'Dark' }].map(opt => {
          const on = dark === opt.id;
          return (
            <button key={opt.label} onClick={() => setDark(opt.id)} title={opt.label} style={{
              flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
              padding: collapsed ? '9px 0' : '8px 10px', borderRadius: 9, border: 'none', cursor: 'pointer',
              background: on ? (onBrick ? '#FBF6EC' : t.brick) : 'transparent',
              color: on ? (onBrick ? t.brick : '#FBF6EC') : sb.text,
              fontFamily: FontBody, fontWeight: 600, fontSize: 12.5,
            }}>
              <Icon name={opt.icon} size={15} color={on ? (onBrick ? t.brick : '#FBF6EC') : sb.text}/>
              {!collapsed && opt.label}
            </button>
          );
        })}
      </div>

      {/* Account chip */}
      {!collapsed ? (
        <button onClick={() => go('settings')} style={{
          display: 'flex', alignItems: 'center', gap: 11, background: sb.cardBg, border: 'none',
          borderRadius: 14, padding: '11px 12px', cursor: 'pointer', textAlign: 'left',
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 11, background: t.mustard, color: t.ink, flexShrink: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: FontDisplay, fontSize: 18,
          }}>M</div>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 13.5, color: sb.textStrong, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Marigold</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 1 }}>
              <span style={{ width: 6, height: 6, borderRadius: 3, background: onBrick ? t.mustard : t.forest }}/>
              <span style={{ fontFamily: FontMono, fontSize: 10, color: sb.mute, letterSpacing: '0.06em', textTransform: 'uppercase' }}>synced</span>
            </div>
          </div>
        </button>
      ) : (
        <div style={{ width: 40, height: 40, margin: '0 auto', borderRadius: 12, background: t.mustard, color: t.ink, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: FontDisplay, fontSize: 18 }}>M</div>
      )}
    </aside>
  );
}

// ─── App root ────────────────────────────────────────────────
function App() {
  const [dark, setDarkRaw] = React.useState(() => {
    try { return localStorage.getItem('yl-dark') === '1'; } catch (e) { return false; }
  });
  const setDark = (v) => { setDarkRaw(v); try { localStorage.setItem('yl-dark', v ? '1' : '0'); } catch (e) {} };
  const t = pickT(dark);

  const [route, setRoute] = React.useState({ view: 'home', params: {} });
  const scrollRef = React.useRef(null);
  const go = (view, params = {}) => {
    setRoute({ view, params });
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
  };

  // collapse sidebar on narrow viewports
  const [collapsed, setCollapsed] = React.useState(false);
  React.useEffect(() => {
    const onResize = () => setCollapsed(window.innerWidth < 1080);
    onResize();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  const ctx = { dark, setDark, t: { ...t, dark } };

  const views = {
    home: <HomeView go={go}/>,
    knit: <KnitView go={go} params={route.params}/>,
    setup: <SetupWizard go={go} params={route.params}/>,
    library: <LibraryView go={go} params={route.params}/>,
    settings: <SettingsView go={go}/>,
    welcome: <WelcomeView go={go}/>,
  };

  // The knitting screen manages its own scroll/layout (immersive); others scroll.
  const immersive = route.view === 'knit';

  return (
    <ThemeCtx.Provider value={ctx}>
      <div style={{ display: 'flex', height: '100vh', width: '100vw', background: t.bg, overflow: 'hidden' }}>
        <Sidebar route={route} go={go} dark={dark} setDark={setDark} collapsed={collapsed}/>
        <main style={{ flex: 1, minWidth: 0, height: '100%', position: 'relative', display: 'flex', flexDirection: 'column' }}>
          {immersive ? (
            <div style={{ flex: 1, minHeight: 0 }}>{views[route.view]}</div>
          ) : (
            <div ref={scrollRef} className="yl-scroll" style={{ flex: 1, overflow: 'auto' }}>
              {views[route.view] || views.home}
            </div>
          )}
        </main>
      </div>
    </ThemeCtx.Provider>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);

