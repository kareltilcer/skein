// Shared UI primitives for Skein.

const FontDisplay = 'Caprasimo, "Cooper Std", Georgia, serif';
const FontBody = '"DM Sans", system-ui, sans-serif';
const FontMono = '"DM Mono", ui-monospace, monospace';

// ─── Phone shell ─────────────────────────────────────────────
// Wraps content in IOSDevice w/ our theme background.
function Phone({ dark = false, mode, children, statusTone }) {
  // Allow either a boolean or a mode string.
  if (mode === 'dark') dark = true;
  const t = pickT(dark);
  return (
    <IOSDevice dark={dark} width={390} height={844}>
      <div style={{
        position: 'absolute', inset: 0,
        background: t.bg,
        fontFamily: FontBody, color: t.ink,
        WebkitFontSmoothing: 'antialiased',
        paddingTop: 60, // below status bar
        display: 'flex', flexDirection: 'column',
      }}>
        {children}
      </div>
    </IOSDevice>
  );
}

// ─── Top app bar ─────────────────────────────────────────────
function AppBar({ title, leading, trailing, dark = false, big = false, sub }) {
  const t = pickT(dark);
  return (
    <div style={{ padding: '8px 20px 4px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', minHeight: 36 }}>
        <div style={{ width: 36, display: 'flex', alignItems: 'center' }}>{leading}</div>
        {!big && (
          <div style={{ fontFamily: FontBody, fontWeight: 600, fontSize: 16, color: t.ink, letterSpacing: '-0.01em' }}>{title}</div>
        )}
        <div style={{ width: 36, display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>{trailing}</div>
      </div>
      {big && (
        <div style={{ marginTop: 10 }}>
          <div style={{ fontFamily: FontDisplay, fontSize: 36, color: t.brick, letterSpacing: '-0.01em', lineHeight: 1 }}>{title}</div>
          {sub && <div style={{ fontSize: 14, color: t.inkSoft, marginTop: 6 }}>{sub}</div>}
        </div>
      )}
    </div>
  );
}

// ─── Icon (very simple stroke icons) ─────────────────────────
function Icon({ name, size = 22, color = 'currentColor', stroke = 2 }) {
  const p = { stroke: color, strokeWidth: stroke, strokeLinecap: 'round', strokeLinejoin: 'round', fill: 'none' };
  const M = { display: 'block' };
  const paths = {
    plus:     <><line x1="12" y1="5" x2="12" y2="19" {...p}/><line x1="5" y1="12" x2="19" y2="12" {...p}/></>,
    chevL:    <polyline points="15,5 8,12 15,19" {...p}/>,
    chevR:    <polyline points="9,5 16,12 9,19" {...p}/>,
    chevDown: <polyline points="6,9 12,16 18,9" {...p}/>,
    x:        <><line x1="6" y1="6" x2="18" y2="18" {...p}/><line x1="18" y1="6" x2="6" y2="18" {...p}/></>,
    search:   <><circle cx="11" cy="11" r="6" {...p}/><line x1="16" y1="16" x2="21" y2="21" {...p}/></>,
    book:     <path d="M5 4 L5 20 L19 20 L19 4 L12 7 L5 4 Z" {...p}/>,
    home:     <path d="M4 11 L12 4 L20 11 V20 H4 Z" {...p}/>,
    gear:     <><circle cx="12" cy="12" r="3.2" {...p}/><path d="M12 3 V6 M12 18 V21 M3 12 H6 M18 12 H21 M5.5 5.5 L7.5 7.5 M16.5 16.5 L18.5 18.5 M5.5 18.5 L7.5 16.5 M16.5 7.5 L18.5 5.5" {...p}/></>,
    more:     <><circle cx="6"  cy="12" r="1.4" fill={color}/><circle cx="12" cy="12" r="1.4" fill={color}/><circle cx="18" cy="12" r="1.4" fill={color}/></>,
    back:     <polyline points="15,5 8,12 15,19" {...p}/>,
    check:    <polyline points="5,12 10,17 19,7" {...p}/>,
    moon:     <path d="M20 14 A 8 8 0 1 1 10 4 A 6 6 0 0 0 20 14 Z" {...p}/>,
    sun:      <><circle cx="12" cy="12" r="4" {...p}/><line x1="12" y1="3" x2="12" y2="5" {...p}/><line x1="12" y1="19" x2="12" y2="21" {...p}/><line x1="3" y1="12" x2="5" y2="12" {...p}/><line x1="19" y1="12" x2="21" y2="12" {...p}/></>,
    bulb:     <><path d="M9 18 H15" {...p}/><path d="M10 14 C 7 12 7 8 12 6 C 17 8 17 12 14 14 Z" {...p}/><path d="M10 18 V20 H14 V18" {...p}/></>,
    edit:     <><path d="M4 20 L8 19 L20 7 L17 4 L5 16 Z" {...p}/></>,
    trash:    <><path d="M5 7 H19 M9 7 V5 H15 V7 M7 7 L8 20 H16 L17 7" {...p}/></>,
    yarn:     <><circle cx="12" cy="13" r="7" {...p}/><path d="M6 10 Q 12 7 18 10 M5 14 Q 12 11 19 14 M8 18 Q 12 15 16 18" {...p}/></>,
    needle:   <><line x1="4" y1="20" x2="20" y2="4" {...p}/><circle cx="5.5" cy="18.5" r="2" {...p}/></>,
    loop:     <path d="M6 14 C 6 9 18 9 18 14 C 18 19 6 19 6 14 Z" {...p}/>,
    refresh:  <><path d="M4 12 A 8 8 0 0 1 18 7" {...p}/><polyline points="18,3 18,7 14,7" {...p}/><path d="M20 12 A 8 8 0 0 1 6 17" {...p}/><polyline points="6,21 6,17 10,17" {...p}/></>,
    backspace:<><path d="M9 5 L20 5 L20 19 L9 19 L3 12 Z" {...p}/><line x1="12" y1="9" x2="16" y2="15" {...p}/><line x1="16" y1="9" x2="12" y2="15" {...p}/></>,
    undo:     <><polyline points="9,7 4,12 9,17" {...p}/><path d="M4 12 H14 A 5 5 0 0 1 14 22" {...p}/></>,
    save:     <><path d="M5 5 H17 L19 7 V19 H5 Z" {...p}/><path d="M8 5 V10 H15 V5" {...p}/></>,
    user:     <><circle cx="12" cy="9" r="3.5" {...p}/><path d="M5 20 C 6 15 18 15 19 20" {...p}/></>,
    globe:    <><circle cx="12" cy="12" r="8" {...p}/><path d="M4 12 H20 M12 4 C 16 8 16 16 12 20 C 8 16 8 8 12 4" {...p}/></>,
    cloud:    <path d="M7 18 A 4 4 0 0 1 7 11 A 5 5 0 0 1 17 11 A 4 4 0 0 1 17 18 Z" {...p}/>,
    play:     <path d="M7 5 V19 L19 12 Z" fill={color} stroke={color} strokeWidth="0" />,
    pause:    <><rect x="6" y="5" width="4" height="14" fill={color}/><rect x="14" y="5" width="4" height="14" fill={color}/></>,
    repeat:   <><polyline points="6,4 4,7 6,10" {...p}/><path d="M4 7 H16 A 4 4 0 0 1 20 11 V14" {...p}/><polyline points="18,20 20,17 18,14" {...p}/><path d="M20 17 H8 A 4 4 0 0 1 4 13 V10" {...p}/></>,
    grid:     <><rect x="4" y="4" width="7" height="7" rx="1" {...p}/><rect x="13" y="4" width="7" height="7" rx="1" {...p}/><rect x="4" y="13" width="7" height="7" rx="1" {...p}/><rect x="13" y="13" width="7" height="7" rx="1" {...p}/></>,
    grip:     <><circle cx="9" cy="7" r="1.2" fill={color}/><circle cx="15" cy="7" r="1.2" fill={color}/><circle cx="9" cy="12" r="1.2" fill={color}/><circle cx="15" cy="12" r="1.2" fill={color}/><circle cx="9" cy="17" r="1.2" fill={color}/><circle cx="15" cy="17" r="1.2" fill={color}/></>,
    sparkle:  <><path d="M12 4 L13.5 10.5 L20 12 L13.5 13.5 L12 20 L10.5 13.5 L4 12 L10.5 10.5 Z" {...p}/></>,
    settings: <><circle cx="12" cy="12" r="3" {...p}/><path d="M12 4 V6 M12 18 V20 M4 12 H6 M18 12 H20 M6 6 L7.5 7.5 M16.5 16.5 L18 18 M6 18 L7.5 16.5 M16.5 7.5 L18 6" {...p}/></>,
    library:  <><line x1="6" y1="4" x2="6" y2="20" {...p}/><line x1="10" y1="4" x2="10" y2="20" {...p}/><path d="M14 4 L18 20" {...p}/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" style={M}>{paths[name] || paths.plus}</svg>;
}

// ─── Buttons ─────────────────────────────────────────────────
function Btn({ children, onClick, variant = 'primary', dark = false, size = 'md', icon, full, style = {} }) {
  const t = pickT(dark);
  const sizes = {
    sm: { h: 36, px: 14, fs: 14 },
    md: { h: 48, px: 20, fs: 15 },
    lg: { h: 58, px: 24, fs: 17 },
  };
  const sz = sizes[size];
  const variants = {
    primary: { background: t.brick, color: '#FBF6EC' },
    mustard: { background: t.mustard, color: t.ink },
    ghost:   { background: 'transparent', color: t.ink, border: `1.5px solid ${t.rule}` },
    soft:    { background: t.card, color: t.ink, border: `1px solid ${t.rule}` },
    chip:    { background: t.cream2, color: t.ink },
  };
  return (
    <button onClick={onClick} style={{
      ...variants[variant],
      height: sz.h, padding: `0 ${sz.px}px`, fontSize: sz.fs, fontFamily: FontBody, fontWeight: 600,
      borderRadius: 14, border: variants[variant].border || 'none',
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      cursor: 'pointer', width: full ? '100%' : 'auto', letterSpacing: '-0.005em',
      ...style,
    }}>
      {icon && <Icon name={icon} size={18}/>}
      {children}
    </button>
  );
}

// ─── Tab bar ─────────────────────────────────────────────────
function TabBar({ active, onChange, dark = false }) {
  const t = pickT(dark);
  const tabs = [
    { id: 'home',     label: 'Projects', icon: 'home' },
    { id: 'library',  label: 'Library',  icon: 'library' },
    { id: 'settings', label: 'Settings', icon: 'settings' },
  ];
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      paddingBottom: 28, paddingTop: 10, paddingLeft: 16, paddingRight: 16,
      background: dark ? 'rgba(18,8,5,0.92)' : 'rgba(242,235,221,0.92)',
      backdropFilter: 'blur(20px)',
      WebkitBackdropFilter: 'blur(20px)',
      borderTop: `1px solid ${t.rule}`,
      display: 'flex', justifyContent: 'space-around',
    }}>
      {tabs.map(tab => {
        const isActive = active === tab.id;
        return (
          <div key={tab.id} onClick={() => onChange && onChange(tab.id)} style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
            color: isActive ? t.brick : t.inkMute, padding: '4px 16px', cursor: 'pointer',
          }}>
            <Icon name={tab.icon} size={22} color={isActive ? t.brick : t.inkMute}/>
            <div style={{ fontSize: 10, fontWeight: 600, letterSpacing: '0.02em' }}>{tab.label}</div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Round icon button ───────────────────────────────────────
function IconBtn({ name, onClick, dark = false, size = 36, color }) {
  const t = pickT(dark);
  return (
    <button onClick={onClick} style={{
      width: size, height: size, borderRadius: size / 2,
      background: t.card, border: `1px solid ${t.rule}`,
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
      color: color || t.ink,
    }}>
      <Icon name={name} size={18} color={color || t.ink}/>
    </button>
  );
}

// ─── Hold-to-confirm pill button with ring ───────────────────
// Press and hold for `holdMs`; ring fills clockwise. Fires onComplete.
function HoldButton({
  label, sub, dark = false,
  holdMs = 3000, color, ringColor, textColor = '#FBF6EC',
  height = 88, width, onComplete,
}) {
  const t = pickT(dark);
  color = color || t.brick;
  ringColor = ringColor || '#FFD986';
  const [progress, setProgress] = React.useState(0);
  const [active, setActive] = React.useState(false);
  const [autoW, setAutoW] = React.useState(width || 320);
  const wrapRef = React.useRef(null);
  const rafRef = React.useRef(null);
  const startedRef = React.useRef(0);

  // If no explicit width is given, measure the wrapper and fill it.
  React.useEffect(() => {
    if (width || !wrapRef.current || typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver((entries) => {
      for (const e of entries) {
        const w = Math.round(e.contentRect.width);
        if (w > 0) setAutoW(w);
      }
    });
    ro.observe(wrapRef.current);
    return () => ro.disconnect();
  }, [width]);

  const start = (e) => {
    e && e.preventDefault();
    setActive(true);
    startedRef.current = performance.now();
    const tick = () => {
      const elapsed = performance.now() - startedRef.current;
      const p = Math.min(1, elapsed / holdMs);
      setProgress(p);
      if (p >= 1) {
        setActive(false);
        setProgress(0);
        onComplete && onComplete();
        return;
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
  };
  const stop = () => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    setActive(false);
    setProgress(0);
  };
  React.useEffect(() => () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); }, []);

  // SVG rounded-rect progress ring around the pill.
  const w = width || autoW, h = height, r = h / 2, sw = 6;
  const perim = 2 * Math.max(0, w - h) + 2 * Math.PI * (r - sw/2);

  return (
    <div ref={wrapRef} style={{ width: '100%', display: 'flex', justifyContent: 'center' }}>
    <div style={{
      position: 'relative', width: w, height: h, userSelect: 'none', touchAction: 'none',
    }}
      onPointerDown={start}
      onPointerUp={stop}
      onPointerLeave={stop}
      onPointerCancel={stop}
    >
      {/* the button */}
      <div style={{
        position: 'absolute', inset: 0, borderRadius: r, background: color,
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        color: textColor, cursor: 'pointer',
        boxShadow: dark ? `0 0 0 1px rgba(255,255,255,0.06), 0 14px 30px ${t.skinShadow}`
          : `0 1px 0 rgba(0,0,0,0.04) inset, 0 16px 40px -8px ${color}66, 0 4px 14px ${color}33`,
        transform: active ? 'scale(0.985)' : 'scale(1)',
        transition: 'transform 120ms ease',
      }}>
        <div style={{ fontFamily: FontDisplay, fontSize: 28, letterSpacing: '-0.01em' }}>{label}</div>
        {sub && <div style={{ fontFamily: FontBody, fontSize: 12, opacity: 0.85, marginTop: 2, letterSpacing: '0.04em', textTransform: 'uppercase' }}>{sub}</div>}
      </div>
      {/* ring on top */}
      <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        transform: 'rotate(-90deg)', transformOrigin: 'center',
      }}>
        <rect x={sw/2} y={sw/2} width={w - sw} height={h - sw} rx={r - sw/2}
              fill="none" stroke={ringColor} strokeWidth={sw}
              strokeDasharray={perim} strokeDashoffset={perim * (1 - progress)}
              strokeLinecap="round"
              opacity={active ? 1 : 0}/>
      </svg>
    </div>
    </div>
  );
}

Object.assign(window, { FontDisplay, FontBody, FontMono, Phone, AppBar, Icon, Btn, TabBar, IconBtn, HoldButton });
