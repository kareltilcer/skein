// Main app — composes all screens onto the design canvas, each in 3 modes.

function App() {
  const W = 430, H = 880;
  // Helper that returns Light + Dark mode-variants of a screen as a fragment of artboards.
  // We call this as a function (not as <Duo/>) so DCSection's flatten helper
  // can see the DCArtboard children directly — it only unwraps Fragments, not custom components.
  const duo = (id, label, S, props = {}) => (
    <>
      <DCArtboard id={`${id}-light`} label={`${label} · Light`} width={W} height={H}>
        <S {...props}/>
      </DCArtboard>
      <DCArtboard id={`${id}-dark`}  label={`${label} · Dark`}  width={W} height={H}>
        <S {...props} dark/>
      </DCArtboard>
    </>
  );

  return (
    <DesignCanvas>
      <DCSection id="brand" title="Skein" subtitle="A pocket pattern keeper for knitters & crocheters · brand v1.0">
        <DCArtboard id="brand-card" label="Brand identity" width={1140} height={780}>
          <BrandCard/>
        </DCArtboard>
      </DCSection>

      <DCSection id="welcome" title="Welcome" subtitle="First-time experience · Light + Dark">
        {duo('empty', '01 · Empty state · first launch', EmptyScreen)}
      </DCSection>

      <DCSection id="home" title="Home" subtitle="Returning user · project list · Light + Dark">
        {duo('home', '02 · Home · returning user', HomeScreen)}
      </DCSection>

      <DCSection id="home-synced" title="Home · with cloud sync" subtitle="When the user has signed in · synced chip in the header · Light + Dark">
        {duo('home-synced', '02b · Home · synced', HomeScreen, { synced: true })}
      </DCSection>

      <DCSection id="setup-1" title="Setup · Step 1 — Basics" subtitle="Name, yarn, tool · Light + Dark">
        {duo('setup-1', '03 · Step 1 · Basics', SetupStep1)}
      </DCSection>

      <DCSection id="setup-1-required" title="Setup · Step 1 — Required field error" subtitle="User tapped Next with the project name blank · Light + Dark">
        {duo('setup-1-required', '03b · Step 1 · Required-field error', SetupStep1, { requiredError: true })}
      </DCSection>

      <DCSection id="setup-2" title="Setup · Step 2 — Parts" subtitle="Name and order the parts · Light + Dark">
        {duo('setup-2', '04 · Step 2 · Parts', SetupStep2)}
      </DCSection>

      <DCSection id="setup-2-empty" title="Setup · Step 2 — Empty state" subtitle="No extra parts added · single-piece project · Light + Dark">
        {duo('setup-2-empty', '04b · Step 2 · Empty state', SetupStep2, { empty: true })}
      </DCSection>

      <DCSection id="setup-2-add" title="Setup · Step 2 — Add a part" subtitle="Bottom-sheet shown after tapping ‘Add another part’ · Light + Dark">
        {duo('setup-2-add', '04c · Step 2 · Add a part', SetupStep2PartSheet, { mode: 'add' })}
      </DCSection>

      <DCSection id="setup-2-edit" title="Setup · Step 2 — Edit a part" subtitle="Same sheet, pre-filled · destructive remove pinned · Light + Dark">
        {duo('setup-2-edit', '04d · Step 2 · Edit a part', SetupStep2PartSheet, { mode: 'edit' })}
      </DCSection>

      <DCSection id="setup-3" title="Setup · Step 3 — Build a sequence" subtitle="Rows + stitches inline · Light + Dark">
        {duo('setup-3', '05 · Step 3 · Build a sequence', SetupStep3)}
      </DCSection>

      <DCSection id="setup-3-remove" title="Setup · Step 3 — Confirm remove row" subtitle="Destructive dialog before nuking a row · Light + Dark">
        {duo('setup-3-remove', '05b · Step 3 · Confirm remove row', SetupStep3, { confirmRemove: true })}
      </DCSection>

      <DCSection id="setup-4" title="Setup · Step 4 — Arrange" subtitle="Order + repeats + loop · Light + Dark">
        {duo('setup-4', '06 · Step 4 · Arrange', SetupStep4)}
      </DCSection>

      <DCSection id="library" title="Library" subtitle="Browse reusable patterns, sequences, rows · Light + Dark">
        {duo('library', '07 · Library · Sequences tab', LibraryScreen)}
      </DCSection>

      <DCSection id="library-empty" title="Library · empty state" subtitle="First-time user with nothing saved yet · Light + Dark">
        {duo('library-empty', '07b · Library · empty state', LibraryScreen, { empty: true })}
      </DCSection>

      <DCSection id="picker" title="Stitch picker" subtitle="Modal sheet · all 30 stitches + custom · Light + Dark">
        {duo('picker', '08 · Stitch picker', StitchPickerScreen)}
      </DCSection>

      <DCSection id="custom-stitch" title="Define a custom stitch" subtitle="Full-screen form reached from the picker's ‘Define a custom stitch’ CTA · Light + Dark">
        {duo('custom-stitch-empty',  '08c · Custom stitch · empty form', CustomStitchScreen)}
        {duo('custom-stitch-filled', '08d · Custom stitch · filled (Fisherman’s rib)', CustomStitchScreen, { filled: true })}
      </DCSection>

      <DCSection id="seq-picker" title="Sequence / Pattern picker" subtitle="Modal sheet · pulled from the library when adding to a project · Light + Dark">
        {duo('seq-picker', '08b · Sequence / Pattern picker', SequencePickerScreen)}
      </DCSection>

      <DCSection id="knit" title="Knitting screen" subtitle="The heart of the app · Light + Dark · INTERACTIVE (press & hold)">
        {duo('knit', '09 · Knitting screen', KnittingScreen)}
      </DCSection>

      <DCSection id="settings" title="Settings" subtitle="Theme, language, optional account · Light + Dark">
        {duo('settings', '10 · Settings', SettingsScreen)}
      </DCSection>

      <DCPostIt top={120} left={120} rotate={-3} width={240}>
        <b>Two themes, every screen:</b><br/><br/>
        <b style={{ color: '#9C3D2E' }}>Light</b> — warm cream daytime.<br/>
        <b style={{ color: '#FF7A4D' }}>Dark</b> — deep red-shifted for evening &amp; late-night knit-alongs. Preserves low-light vision, no glare.
      </DCPostIt>
    </DesignCanvas>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);
