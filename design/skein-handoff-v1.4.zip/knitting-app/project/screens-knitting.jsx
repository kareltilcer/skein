// Knitting screen — the hero. Light mode + dark/low-light variants.

// Stitch for current row chart — single chip variant.
// Sized large; abbreviation + symbol stacked.
function BigStitchChip({ stitch, dark, size = 'lg', color }) {
  const t = pickT(dark);
  const w = size === 'lg' ? 76 : 52;
  const h = size === 'lg' ? 96 : 64;
  const glyphSize = size === 'lg' ? 38 : 26;
  const fontSize = size === 'lg' ? 18 : 13;
  return (
    <div style={{
      width: w, height: h, borderRadius: 18, background: color,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4,
      color: '#FBF6EC', flexShrink: 0,
      boxShadow: dark ? 'none' : `0 1px 0 rgba(255,255,255,0.15) inset, 0 4px 10px ${color}44`,
    }}>
      <StitchGlyph symbol={stitch.symbol} color="#FBF6EC" size={glyphSize} stroke={2.6}/>
      <div style={{ fontFamily: FontMono, fontWeight: 700, fontSize, letterSpacing: '0.02em' }}>{stitch.abbr}</div>
    </div>
  );
}

// Group consecutive same stitches into runs for readable notation.
function groupRuns(stitchIds) {
  const out = [];
  for (const id of stitchIds) {
    const last = out[out.length - 1];
    if (last && last.id === id) last.count += 1;
    else out.push({ id, count: 1 });
  }
  return out;
}

function KnittingScreen({ dark = false }) {
  const t = pickT(dark);

  // Current row data
  const rowIds = ['k','k','p','p','k','k','yo','k2tog','k','k','p','p'];
  const runs = groupRuns(rowIds);
  const currentRow = 12, totalRows = 40, repeatNum = 3, repeatTotal = 6;

  // Color per run
  const colorFor = (id) => {
    if (['k','sl','kfb','m1','c4f','c4b'].includes(id)) return t.brick;
    if (['p','p2tog','dash','mb'].includes(id)) return t.mustard;
    return t.forest;
  };

  const notation = runs.map(r => `${r.id}${r.count > 1 ? r.count : ''}`).join(', ');

  return (
    <Phone dark={dark}>
      <div style={{
        height: '100%', display: 'flex', flexDirection: 'column',
        position: 'relative', overflow: 'hidden',
      }}>
        {/* top compact bar */}
        <div style={{ padding: '8px 20px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <IconBtn name="back" dark={dark}/>
          <div style={{ textAlign: 'center', flex: 1 }}>
            <div style={{ fontFamily: FontMono, fontSize: 10, letterSpacing: '0.18em', color: t.inkMute, textTransform: 'uppercase' }}>Granny Cardigan · Body</div>
          </div>
          <IconBtn name="more" dark={dark}/>
        </div>

        {/* sequence + repeat indicator row */}
        <div style={{
          margin: '14px 20px 0', padding: '12px 14px', borderRadius: 16,
          background: dark ? 'rgba(255,234,200,0.06)' : t.card,
          border: `1px solid ${t.rule}`,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
        }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: FontMono, fontSize: 10, letterSpacing: '0.16em', color: t.inkMute, textTransform: 'uppercase' }}>Sequence 2 of 3</div>
            <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 15, color: t.ink, marginTop: 2 }}>Stockinette body</div>
          </div>
          <div style={{
            background: t.mustard, color: dark ? '#1A0F08' : '#2B1810', padding: '6px 12px',
            borderRadius: 999, display: 'flex', alignItems: 'center', gap: 6,
          }}>
            <Icon name="repeat" size={14} color={dark ? '#1A0F08' : '#2B1810'}/>
            <span style={{ fontFamily: FontMono, fontWeight: 700, fontSize: 12, letterSpacing: '0.04em' }}>{repeatNum}/{repeatTotal}</span>
          </div>
        </div>

        {/* row counter strip */}
        <div style={{
          margin: '14px 20px 8px', display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
        }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
            <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, letterSpacing: '0.16em', textTransform: 'uppercase' }}>Row</div>
            <div style={{ fontFamily: FontDisplay, fontSize: 56, color: t.brick, lineHeight: 1, letterSpacing: '-0.03em' }}>{currentRow}</div>
            <div style={{ fontFamily: FontDisplay, fontSize: 22, color: t.inkSoft, lineHeight: 1 }}>/ {totalRows}</div>
          </div>
          {/* mini progress */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6 }}>
            <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.12em', textTransform: 'uppercase' }}>{Math.round(currentRow/totalRows*100)}%</div>
            <div style={{ width: 100, height: 6, background: dark ? 'rgba(255,234,200,0.12)' : t.cream2, borderRadius: 3, overflow: 'hidden' }}>
              <div style={{ width: `${currentRow/totalRows*100}%`, height: '100%', background: t.brick, borderRadius: 3 }}/>
            </div>
          </div>
        </div>

        {/* HERO — current row stitches */}
        <div style={{
          flex: 1, margin: '4px 16px 0', padding: '18px 14px 16px',
          background: dark ? 'rgba(255,234,200,0.04)' : t.card,
          border: `1.5px solid ${dark ? 'rgba(255,234,200,0.1)' : t.rule}`,
          borderRadius: 22,
          display: 'flex', flexDirection: 'column', overflow: 'hidden',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.16em', textTransform: 'uppercase' }}>This row · {rowIds.length} sts</div>
            <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.04em' }}>read →</div>
          </div>

          {/* big stitch flow */}
          <div style={{
            display: 'flex', flexWrap: 'wrap', gap: 8, alignContent: 'flex-start',
            justifyContent: 'center', flex: 1,
          }}>
            {rowIds.map((id, i) => {
              const s = Stitches.find(s => s.id === id);
              return <BigStitchChip key={i} stitch={s} dark={dark} size="lg" color={colorFor(id)}/>;
            })}
          </div>

          {/* notation footer */}
          <div style={{
            marginTop: 12, padding: '10px 12px', background: dark ? 'rgba(255,234,200,0.06)' : t.cream2,
            borderRadius: 12, fontFamily: FontMono, fontSize: 13, color: t.inkSoft, textAlign: 'center',
            letterSpacing: '0.02em',
          }}>
            {notation}
          </div>
        </div>

        {/* bottom controls: back + hold button */}
        <div style={{
          padding: '14px 16px 36px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, width: '100%' }}>
            {/* tiny back hold */}
            <SmallHoldBack dark={dark}/>
            {/* HOLD button */}
            <div style={{ flex: 1, minWidth: 0 }}>
              <HoldButton
                label="Row done"
                sub="hold 3 sec"
                color={t.brick}
                ringColor={t.mustard}
                holdMs={3000}
                height={84}
              />
            </div>
          </div>
          <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.12em' }}>
            press & hold so your cat can't ruin everything
          </div>
        </div>
      </div>
    </Phone>
  );
}

function SmallHoldBack({ dark }) {
  const t = pickT(dark);
  const [progress, setProgress] = React.useState(0);
  const [active, setActive] = React.useState(false);
  const rafRef = React.useRef(null);
  const startRef = React.useRef(0);
  const holdMs = 3000;
  const start = (e) => {
    e.preventDefault();
    setActive(true);
    startRef.current = performance.now();
    const tick = () => {
      const p = Math.min(1, (performance.now() - startRef.current) / holdMs);
      setProgress(p);
      if (p >= 1) { setActive(false); setProgress(0); return; }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
  };
  const stop = () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); setActive(false); setProgress(0); };
  React.useEffect(() => () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); }, []);

  // A pill that visually pairs with the primary — same height, just narrower.
  // Subtle mustard-tinted ghost style; same rounded-rect hold ring.
  const w = 64, h = 84, r = h / 2, sw = 5;
  const perim = 2 * (w - h) + 2 * Math.PI * (r - sw / 2);
  const iconColor = dark ? t.mustard : t.brick;

  return (
    <div style={{
      width: w, height: h, position: 'relative', userSelect: 'none', touchAction: 'none', flexShrink: 0,
    }}
      onPointerDown={start}
      onPointerUp={stop}
      onPointerLeave={stop}
      onPointerCancel={stop}
    >
      {/* pill body */}
      <div style={{
        position: 'absolute', inset: 0, borderRadius: r,
        background: dark ? 'rgba(255,217,134,0.06)' : t.card,
        border: `1.5px solid ${dark ? 'rgba(255,217,134,0.28)' : t.brick + '33'}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer',
        transform: active ? 'scale(0.96)' : 'scale(1)',
        transition: 'transform 120ms ease',
        boxShadow: dark ? 'none' : '0 1px 2px rgba(43,24,16,0.04)',
      }}>
        <Icon name="chevL" size={28} color={iconColor} stroke={2.4}/>
      </div>
      {/* hold ring — same shape as primary pill, just smaller */}
      <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        transform: 'rotate(-90deg)', transformOrigin: 'center',
      }}>
        <rect x={sw/2} y={sw/2} width={w - sw} height={h - sw} rx={r - sw/2}
              fill="none" stroke={t.mustard} strokeWidth={sw}
              strokeDasharray={perim} strokeDashoffset={perim * (1 - progress)}
              strokeLinecap="round"
              opacity={active ? 1 : 0}/>
      </svg>
    </div>
  );
}

Object.assign(window, { KnittingScreen });
