// Brand identity card — logo, palette, type, sample.
// Designed to sit as its own artboard on the design canvas.

function BrandCard() {
  const t = SkeinTokens.light;
  const FontDisplay = 'Caprasimo, "Cooper Std", Georgia, serif';
  const FontBody = '"DM Sans", system-ui, sans-serif';
  const swatch = (name, hex, fg) => (
    <div key={hex} style={{
      flex: 1, minWidth: 0, borderRadius: 14, background: hex, color: fg,
      padding: '14px 14px 12px', display: 'flex', flexDirection: 'column',
      justifyContent: 'space-between', height: 96, fontFamily: FontBody,
    }}>
      <div style={{ fontWeight: 600, fontSize: 13, letterSpacing: '-0.01em' }}>{name}</div>
      <div style={{ fontFamily: '"DM Mono", ui-monospace, monospace', fontSize: 11, opacity: 0.85 }}>{hex}</div>
    </div>
  );

  return (
    <div style={{
      width: 1080, padding: 56, background: t.bg, color: t.ink,
      fontFamily: FontBody, borderRadius: 12, position: 'relative', overflow: 'hidden',
    }}>
      {/* tag */}
      <div style={{
        position: 'absolute', top: 24, right: 32, fontFamily: '"DM Mono", monospace',
        fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase',
        color: t.inkMute,
      }}>
        Brand · v1.0
      </div>

      {/* Wordmark */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 24, marginBottom: 36 }}>
        <SkeinLogo size={88} fg={t.brick} accent={t.mustard}/>
        <div>
          <div style={{ fontFamily: FontDisplay, fontSize: 108, lineHeight: 0.95, color: t.brick, letterSpacing: '-0.02em' }}>
            Skein
          </div>
          <div style={{
            fontFamily: FontDisplay, fontSize: 18, color: t.mustardDk, marginTop: 6,
            letterSpacing: '0.04em',
          }}>
            stitch happens.
          </div>
        </div>
      </div>

      {/* about */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32, marginBottom: 40 }}>
        <div>
          <div style={{ fontSize: 11, letterSpacing: '0.18em', color: t.inkMute, textTransform: 'uppercase', marginBottom: 8 }}>The pitch</div>
          <div style={{ fontSize: 17, lineHeight: 1.45, color: t.inkSoft, maxWidth: 440 }}>
            A cozy pocket companion for knitters and crocheters. Skein keeps your place row-by-row, remembers the repeats, and never loses count — even with both hands busy on the needles.
          </div>
        </div>
        <div>
          <div style={{ fontSize: 11, letterSpacing: '0.18em', color: t.inkMute, textTransform: 'uppercase', marginBottom: 8 }}>Tone of voice</div>
          <div style={{ fontSize: 17, lineHeight: 1.45, color: t.inkSoft, maxWidth: 440 }}>
            Warm. Playful. A little punny. We say "Cast on!" not "Begin." We say "Yarn on, friend." not "Continue." We trust people to figure out the rest.
          </div>
        </div>
      </div>

      {/* Palette */}
      <div style={{ marginBottom: 36 }}>
        <div style={{ fontSize: 11, letterSpacing: '0.18em', color: t.inkMute, textTransform: 'uppercase', marginBottom: 12 }}>Palette · warm folk-craft</div>
        <div style={{ display: 'flex', gap: 12 }}>
          {swatch('Cream',   t.bg,      t.ink)}
          {swatch('Brick',   t.brick,   '#FBF6EC')}
          {swatch('Mustard', t.mustard, '#2B1810')}
          {swatch('Forest',  t.forest,  '#FBF6EC')}
          {swatch('Espresso',t.ink,     t.bg)}
          {swatch('Card',    t.card,    t.ink)}
        </div>
      </div>

      {/* Type */}
      <div style={{ marginBottom: 36 }}>
        <div style={{ fontSize: 11, letterSpacing: '0.18em', color: t.inkMute, textTransform: 'uppercase', marginBottom: 14 }}>Typography</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          <div style={{ background: t.card, borderRadius: 14, padding: 24 }}>
            <div style={{ fontFamily: FontDisplay, fontSize: 56, lineHeight: 1, color: t.brick }}>Cast on.</div>
            <div style={{ marginTop: 14, fontFamily: '"DM Mono", monospace', fontSize: 11, color: t.inkMute, letterSpacing: '0.08em' }}>
              CAPRASIMO · Display · 24–120px
            </div>
            <div style={{ fontSize: 13, color: t.inkSoft, marginTop: 4 }}>For the logo, big numbers, hero headlines. Cooper-Black-warm, late-70s catalog energy.</div>
          </div>
          <div style={{ background: t.card, borderRadius: 14, padding: 24 }}>
            <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 28, color: t.ink, lineHeight: 1.15 }}>The Granny Cardigan</div>
            <div style={{ fontFamily: FontBody, fontSize: 15, color: t.inkSoft, marginTop: 8, lineHeight: 1.4 }}>
              Row 12 of 40 · Repeat 3 of 6. Knit two, purl two, breathe.
            </div>
            <div style={{ marginTop: 14, fontFamily: '"DM Mono", monospace', fontSize: 11, color: t.inkMute, letterSpacing: '0.08em' }}>
              DM SANS · Body · 12–28px
            </div>
          </div>
        </div>
      </div>

      {/* Icons */}
      <div>
        <div style={{ fontSize: 11, letterSpacing: '0.18em', color: t.inkMute, textTransform: 'uppercase', marginBottom: 14 }}>Stitch icons — friendly chips · chart-derived</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: 10 }}>
          {Stitches.slice(0, 16).map((s, i) => {
            const palette = [t.brick, t.mustard, t.forest, t.brickDk];
            const fill = palette[i % 4];
            return (
              <div key={s.id} style={{
                background: t.card, borderRadius: 14, padding: '10px 8px',
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
                border: `1px solid ${t.rule}`,
              }}>
                <div style={{
                  width: 40, height: 40, borderRadius: 10, background: fill,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', color: t.card,
                }}>
                  <StitchGlyph symbol={s.symbol} color="#FBF6EC" size={22}/>
                </div>
                <div style={{ fontSize: 11, fontFamily: '"DM Mono", monospace', color: t.inkSoft }}>{s.abbr}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

window.BrandCard = BrandCard;
