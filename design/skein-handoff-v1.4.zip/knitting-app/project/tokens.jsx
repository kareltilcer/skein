// Design tokens for Skein — warm folk-craft retro palette
// Two themes: light (cream + brick + mustard + forest) and dark/low-light (deep warm browns).

const SkeinTokens = {
  light: {
    bg:       '#F2EBDD',        // cream
    bgAlt:    '#E8DEC8',        // deeper cream
    card:     '#FBF6EC',        // off-cream
    ink:      '#2B1810',        // deep brown text
    inkSoft:  '#5A4434',        // softer brown
    inkMute:  '#8A7560',        // muted brown
    brick:    '#9C3D2E',        // brick accent
    brickDk:  '#7A2C1F',        // darker brick
    mustard:  '#D4923B',        // mustard accent
    mustardDk:'#A66B1F',
    forest:   '#3F6B4A',        // forest green accent
    forestDk: '#2A4D33',
    cream2:   '#EFE4CC',
    rule:     '#D8C9AE',        // hairline
    skinShadow: 'rgba(43,24,16,0.08)',
  },
  dark: {
    // Dark mode (formerly "low-light"): deep red-shifted ground for eye comfort
    // during evening / late-night knit-alongs. Brighter, warmer accents stand
    // out without glare and don't ruin low-light vision adaptation.
    bg:       '#120805',        // deepest warm red-black
    bgAlt:    '#1A0E08',
    card:     '#1E110A',
    ink:      '#F8D9B0',        // amber-warm cream
    inkSoft:  '#D4A878',
    inkMute:  '#8A6E50',
    brick:    '#FF7A4D',        // hot ember
    brickDk:  '#D6562E',
    mustard:  '#FFC25F',        // amber gold
    mustardDk:'#D89A38',
    forest:   '#88B98C',
    forestDk: '#5D8A63',
    cream2:   '#2A180E',
    rule:     'rgba(255,217,134,0.10)',
    skinShadow: 'rgba(0,0,0,0.55)',
  },
};

// Token picker. Pass `dark` boolean (or mode string for legacy) and get the right palette.
function pickT(dark) {
  if (typeof dark === 'string') return SkeinTokens[dark] || SkeinTokens.light;
  return dark ? SkeinTokens.dark : SkeinTokens.light;
}

// Predefined stitch library — ~30 common knit/crochet stitches.
// Each has: id, abbr (display abbreviation), name, type ('knit'|'crochet'),
// symbol (simple SVG path drawn at 24x24 viewport), color hint.
const Stitches = [
  // — Knit (15) —
  { id:'k',      abbr:'k',    name:'Knit',                 type:'knit',    symbol:'vline'  },
  { id:'p',      abbr:'p',    name:'Purl',                 type:'knit',    symbol:'dash'   },
  { id:'yo',     abbr:'yo',   name:'Yarn Over',            type:'knit',    symbol:'ring'   },
  { id:'k2tog',  abbr:'k2tog',name:'Knit 2 Together',      type:'knit',    symbol:'slashR' },
  { id:'ssk',    abbr:'ssk',  name:'Slip Slip Knit',       type:'knit',    symbol:'slashL' },
  { id:'k3tog',  abbr:'k3tog',name:'Knit 3 Together',      type:'knit',    symbol:'triUp'  },
  { id:'p2tog',  abbr:'p2tog',name:'Purl 2 Together',      type:'knit',    symbol:'slashRdot' },
  { id:'kfb',    abbr:'kfb',  name:'Knit Front & Back',    type:'knit',    symbol:'vee'    },
  { id:'m1',     abbr:'m1',   name:'Make 1',               type:'knit',    symbol:'plus'   },
  { id:'sl',     abbr:'sl',   name:'Slip Stitch',          type:'knit',    symbol:'vline2' },
  { id:'c4f',    abbr:'c4f',  name:'Cable 4 Front',        type:'knit',    symbol:'cableL' },
  { id:'c4b',    abbr:'c4b',  name:'Cable 4 Back',         type:'knit',    symbol:'cableR' },
  { id:'mb',     abbr:'mb',   name:'Make Bobble',          type:'knit',    symbol:'dot'    },
  { id:'tbl',    abbr:'tbl',  name:'Through Back Loop',    type:'knit',    symbol:'vlineX' },
  { id:'ns',     abbr:'—',    name:'No Stitch',            type:'knit',    symbol:'grey'   },

  // — Crochet (15) —
  { id:'ch',     abbr:'ch',   name:'Chain',                type:'crochet', symbol:'oval'   },
  { id:'slst',   abbr:'sl st',name:'Slip Stitch (cr.)',    type:'crochet', symbol:'dotSm'  },
  { id:'sc',     abbr:'sc',   name:'Single Crochet',       type:'crochet', symbol:'cross'  },
  { id:'hdc',    abbr:'hdc',  name:'Half Double Crochet',  type:'crochet', symbol:'tee'    },
  { id:'dc',     abbr:'dc',   name:'Double Crochet',       type:'crochet', symbol:'teeBar' },
  { id:'tr',     abbr:'tr',   name:'Treble Crochet',       type:'crochet', symbol:'teeBar2'},
  { id:'dtr',    abbr:'dtr',  name:'Double Treble',        type:'crochet', symbol:'teeBar3'},
  { id:'sc2tog', abbr:'sc2tog',name:'Sc 2 Together',       type:'crochet', symbol:'crossSlash'},
  { id:'dc2tog', abbr:'dc2tog',name:'Dc 2 Together',       type:'crochet', symbol:'teeSlash'},
  { id:'pic',    abbr:'pic',  name:'Picot',                type:'crochet', symbol:'flower' },
  { id:'fpdc',   abbr:'fpdc', name:'Front Post Dc',        type:'crochet', symbol:'teeFwd' },
  { id:'bpdc',   abbr:'bpdc', name:'Back Post Dc',         type:'crochet', symbol:'teeBwd' },
  { id:'mr',     abbr:'mr',   name:'Magic Ring',           type:'crochet', symbol:'ringBig'},
  { id:'shell',  abbr:'shell',name:'Shell',                type:'crochet', symbol:'fan'    },
  { id:'vst',    abbr:'v-st', name:'V-Stitch',             type:'crochet', symbol:'vee2'   },
];

// Stitch symbol renderer — draws a chart-style glyph in a 24x24 box.
function StitchGlyph({ symbol, color = 'currentColor', size = 24, stroke = 2.2 }) {
  const s = size, c = color, sw = stroke;
  const common = { stroke: c, strokeWidth: sw, strokeLinecap: 'round', strokeLinejoin: 'round', fill: 'none' };
  let g;
  switch (symbol) {
    case 'vline':    g = <line x1="12" y1="3" x2="12" y2="21" {...common}/>; break;
    case 'vline2':   g = <><line x1="9"  y1="3" x2="9"  y2="21" {...common}/><line x1="15" y1="3" x2="15" y2="21" {...common}/></>; break;
    case 'vlineX':   g = <><line x1="12" y1="3" x2="12" y2="21" {...common}/><line x1="7" y1="7" x2="17" y2="17" {...common}/></>; break;
    case 'dash':     g = <line x1="3"  y1="12" x2="21" y2="12" {...common}/>; break;
    case 'ring':     g = <circle cx="12" cy="12" r="6" {...common}/>; break;
    case 'ringBig':  g = <circle cx="12" cy="12" r="8" {...common}/>; break;
    case 'slashR':   g = <line x1="5"  y1="19" x2="19" y2="5"  {...common}/>; break;
    case 'slashL':   g = <line x1="5"  y1="5"  x2="19" y2="19" {...common}/>; break;
    case 'slashRdot':g = <><line x1="5" y1="19" x2="19" y2="5"  {...common}/><circle cx="12" cy="12" r="1.6" fill={c}/></>; break;
    case 'triUp':    g = <path d="M5 19 L12 5 L19 19 Z" {...common}/>; break;
    case 'vee':      g = <path d="M5 7 L12 17 L19 7" {...common}/>; break;
    case 'vee2':     g = <><path d="M5 7 L12 17 L19 7" {...common}/><line x1="12" y1="17" x2="12" y2="21" {...common}/></>; break;
    case 'plus':     g = <><line x1="12" y1="5" x2="12" y2="19" {...common}/><line x1="5" y1="12" x2="19" y2="12" {...common}/></>; break;
    case 'cableL':   g = <><path d="M6 5 C 10 9, 14 15, 18 19" {...common}/><path d="M18 5 C 14 9, 10 15, 6 19" {...common}/></>; break;
    case 'cableR':   g = <><path d="M18 5 C 14 9, 10 15, 6 19" {...common}/><path d="M6 5 C 10 9, 14 15, 18 19" {...common}/></>; break;
    case 'dot':      g = <circle cx="12" cy="12" r="4" fill={c}/>; break;
    case 'dotSm':    g = <circle cx="12" cy="12" r="2.5" fill={c}/>; break;
    case 'grey':     g = <rect x="4" y="4" width="16" height="16" rx="3" fill={c} fillOpacity="0.18"/>; break;
    case 'oval':     g = <ellipse cx="12" cy="12" rx="7" ry="4" {...common}/>; break;
    case 'cross':    g = <><line x1="6" y1="6" x2="18" y2="18" {...common}/><line x1="18" y1="6" x2="6" y2="18" {...common}/></>; break;
    case 'tee':      g = <><line x1="12" y1="4" x2="12" y2="20" {...common}/><line x1="6" y1="20" x2="18" y2="20" {...common}/></>; break;
    case 'teeBar':   g = <><line x1="12" y1="4" x2="12" y2="20" {...common}/><line x1="6" y1="20" x2="18" y2="20" {...common}/><line x1="6" y1="12" x2="18" y2="12" {...common}/></>; break;
    case 'teeBar2':  g = <><line x1="12" y1="4" x2="12" y2="20" {...common}/><line x1="6" y1="20" x2="18" y2="20" {...common}/><line x1="6" y1="10" x2="18" y2="10" {...common}/><line x1="6" y1="15" x2="18" y2="15" {...common}/></>; break;
    case 'teeBar3':  g = <><line x1="12" y1="4" x2="12" y2="20" {...common}/><line x1="6" y1="20" x2="18" y2="20" {...common}/><line x1="6" y1="9" x2="18" y2="9" {...common}/><line x1="6" y1="13" x2="18" y2="13" {...common}/><line x1="6" y1="17" x2="18" y2="17" {...common}/></>; break;
    case 'crossSlash': g = <><line x1="6" y1="6" x2="18" y2="18" {...common}/><line x1="18" y1="6" x2="6" y2="18" {...common}/><path d="M4 12 L20 12" {...common}/></>; break;
    case 'teeSlash':   g = <><line x1="12" y1="4" x2="12" y2="20" {...common}/><line x1="6" y1="20" x2="18" y2="20" {...common}/><line x1="6" y1="12" x2="18" y2="12" {...common}/><line x1="4" y1="6" x2="20" y2="18" {...common}/></>; break;
    case 'flower':   g = <><circle cx="12" cy="6" r="2.5" {...common}/><circle cx="7" cy="14" r="2.5" {...common}/><circle cx="17" cy="14" r="2.5" {...common}/></>; break;
    case 'teeFwd':   g = <><path d="M8 4 C 14 8, 14 16, 8 20" {...common}/><line x1="6" y1="20" x2="18" y2="20" {...common}/></>; break;
    case 'teeBwd':   g = <><path d="M16 4 C 10 8, 10 16, 16 20" {...common}/><line x1="6" y1="20" x2="18" y2="20" {...common}/></>; break;
    case 'fan':      g = <path d="M5 19 Q 8 8 12 8 Q 16 8 19 19" {...common}/>; break;
    default:         g = <circle cx="12" cy="12" r="6" {...common}/>;
  }
  return <svg width={s} height={s} viewBox="0 0 24 24" style={{ display: 'block' }}>{g}</svg>;
}

// Skein logo — chunky retro mark: stylized yarn ball with trailing thread spelling intent.
function SkeinLogo({ size = 56, fg = '#9C3D2E', accent = '#D4923B', bg = null }) {
  return (
    <svg width={size} height={size} viewBox="0 0 56 56" style={{ display: 'block' }}>
      {bg && <rect width="56" height="56" rx="14" fill={bg}/>}
      {/* yarn ball */}
      <circle cx="28" cy="30" r="18" fill={fg}/>
      {/* yarn wrap lines */}
      <path d="M14 24 Q 28 18 42 24" stroke={accent} strokeWidth="2.4" fill="none" strokeLinecap="round"/>
      <path d="M12 32 Q 28 26 44 32" stroke={accent} strokeWidth="2.4" fill="none" strokeLinecap="round"/>
      <path d="M14 40 Q 28 34 42 40" stroke={accent} strokeWidth="2.4" fill="none" strokeLinecap="round"/>
      <path d="M20 16 Q 28 22 36 16" stroke={accent} strokeWidth="2.4" fill="none" strokeLinecap="round"/>
      {/* trailing thread */}
      <path d="M44 24 Q 52 18 50 10" stroke={fg} strokeWidth="2.6" fill="none" strokeLinecap="round"/>
      <circle cx="50" cy="9" r="2" fill={fg}/>
    </svg>
  );
}

Object.assign(window, { SkeinTokens, pickT, Stitches, StitchGlyph, SkeinLogo });
