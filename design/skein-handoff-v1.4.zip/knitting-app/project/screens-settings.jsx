// Settings screen — theme, language, optional account.

function SettingsScreen({ dark = false }) {
  const t = pickT(dark);
  return (
    <Phone dark={dark}>
      <AppBar big title="Settings" sub="The cozy customization corner."
        dark={dark}
        leading={<IconBtn name="back" dark={dark}/>}
      />
      <div style={{ flex: 1, overflow: 'auto', padding: '8px 20px 110px', display: 'flex', flexDirection: 'column', gap: 18 }}>

        {/* Theme card — main feature */}
        <div>
          <Label dark={dark}>Appearance</Label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8, marginTop: 8 }}>
            <ThemeChoice label="Light" active={!dark} swatch={SkeinTokens.light.bg} accent={SkeinTokens.light.brick} dark={dark}/>
            <ThemeChoice label="Dark"  active={dark}  swatch={SkeinTokens.dark.bg}  accent={SkeinTokens.dark.brick}  dark={dark} sparkle/>
          </div>
          <div style={{
            marginTop: 10, padding: '10px 12px', background: t.card, borderRadius: 12,
            display: 'flex', gap: 10, alignItems: 'flex-start', border: `1px solid ${t.rule}`,
          }}>
            <Icon name="bulb" size={16} color={t.mustardDk}/>
            <div style={{ fontSize: 12.5, color: t.inkSoft, lineHeight: 1.45 }}>
              <b style={{ color: t.ink }}>Dark mode</b> shifts everything to a deep warm red so your eyes stay relaxed during late-night knit-alongs and your low-light vision stays sharp.
            </div>
          </div>
        </div>

        {/* Language */}
        <SettingsRow icon="globe" iconColor={t.forest} title="Language" value="English (US)" dark={dark}/>
        <SettingsRow icon="needle" iconColor={t.brick} title="Default craft" value="Knit · Metric mm" dark={dark}/>
        <SettingsRow icon="bulb" iconColor={t.mustardDk} title="Hold time to advance" value="3.0 seconds" dark={dark}/>

        {/* Account section */}
        <div style={{
          background: `linear-gradient(180deg, ${t.cream2} 0%, ${t.card} 100%)`,
          borderRadius: 22, padding: 20, border: `1px solid ${t.rule}`,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
            <div style={{
              width: 42, height: 42, borderRadius: 12, background: t.brick, color: '#FBF6EC',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Icon name="cloud" size={22} color="#FBF6EC"/>
            </div>
            <div>
              <div style={{ fontFamily: FontDisplay, fontSize: 20, color: t.brick }}>Cloud backup</div>
              <div style={{ fontSize: 12, color: t.inkMute, fontFamily: FontMono, letterSpacing: '0.04em' }}>Totally optional. Always.</div>
            </div>
          </div>
          <div style={{ fontSize: 13, color: t.inkSoft, lineHeight: 1.45, marginBottom: 14 }}>
            Add an account to sync projects across devices and back up your pattern library. We won't pester you.
          </div>
          <Btn variant="mustard" size="md" full dark={dark}>Create account</Btn>
          <div style={{ textAlign: 'center', marginTop: 10, fontSize: 12, color: t.inkSoft }}>
            already have one? <span style={{ color: t.brick, fontWeight: 700 }}>Sign in</span>
          </div>
        </div>

        {/* Extras */}
        <Label dark={dark}>More</Label>
        <div style={{ background: t.card, borderRadius: 16, border: `1px solid ${t.rule}`, overflow: 'hidden' }}>
          <MiniRow icon="save"    label="Export pattern as PDF"          dark={dark}/>
          <MiniRow icon="sparkle" label="Skein Pro · ad-free forever"    dark={dark} accent={t.mustardDk}/>
          <MiniRow icon="user"    label="Tell a friend (please?)"        dark={dark}/>
          <MiniRow icon="book"    label="The little knitting glossary"   dark={dark} last/>
        </div>

        {/* Footer */}
        <div style={{ textAlign: 'center', fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.14em', textTransform: 'uppercase', marginTop: 6 }}>
          Skein 1.0 · made with yarn & code
        </div>
      </div>
      <TabBar active="settings" dark={dark}/>
    </Phone>
  );
}

function Label({ dark, children }) {
  const t = pickT(dark);
  return (
    <div style={{
      fontFamily: FontMono, fontSize: 10.5, letterSpacing: '0.18em', color: t.inkMute,
      textTransform: 'uppercase', marginBottom: 4,
    }}>{children}</div>
  );
}

function ThemeChoice({ label, swatch, accent, active = false, sparkle = false, dark = false }) {
  const t = pickT(dark);
  return (
    <div style={{
      background: t.card, borderRadius: 16, padding: 10, border: active ? `2px solid ${t.brick}` : `1px solid ${t.rule}`,
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, cursor: 'pointer',
    }}>
      <div style={{
        width: '100%', height: 56, borderRadius: 10, background: swatch, position: 'relative',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <div style={{
          width: 28, height: 28, borderRadius: 14, background: accent,
        }}/>
        {sparkle && (
          <div style={{ position: 'absolute', top: 6, right: 8, color: accent, opacity: 0.9 }}>
            <Icon name="moon" size={12} color={accent}/>
          </div>
        )}
      </div>
      <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 12, color: active ? t.brick : t.ink }}>{label}</div>
    </div>
  );
}

function SettingsRow({ icon, iconColor, title, value, dark }) {
  const t = pickT(dark);
  return (
    <div style={{
      background: t.card, border: `1px solid ${t.rule}`, borderRadius: 14, padding: 14,
      display: 'flex', alignItems: 'center', gap: 12,
    }}>
      <div style={{
        width: 38, height: 38, borderRadius: 10, background: t.cream2,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon name={icon} size={20} color={iconColor}/>
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 14.5, color: t.ink }}>{title}</div>
        <div style={{ fontSize: 12, color: t.inkMute, fontFamily: FontMono, marginTop: 2 }}>{value}</div>
      </div>
      <Icon name="chevR" size={16} color={t.inkMute}/>
    </div>
  );
}

function MiniRow({ icon, label, dark, accent, last = false }) {
  const t = pickT(dark);
  return (
    <div style={{
      padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12,
      borderBottom: last ? 'none' : `1px solid ${t.rule}`,
    }}>
      <Icon name={icon} size={18} color={accent || t.inkSoft}/>
      <div style={{ flex: 1, fontFamily: FontBody, fontSize: 14, color: t.ink, fontWeight: accent ? 700 : 500 }}>{label}</div>
      <Icon name="chevR" size={14} color={t.inkMute}/>
    </div>
  );
}

Object.assign(window, { SettingsScreen });
