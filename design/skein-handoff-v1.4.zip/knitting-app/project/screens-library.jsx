// Library + Stitch picker

function LibraryScreen({ dark = false, empty = false }) {
  const t = pickT(dark);
  const [tab, setTab] = React.useState('seq');
  const [craft, setCraft] = React.useState('all');
  const tabs = [
    { id: 'pat', label: 'Patterns',  count: 4 },
    { id: 'seq', label: 'Sequences', count: 12 },
    { id: 'row', label: 'Rows',      count: 28 },
  ];
  const tabSingular = { pat: 'pattern', seq: 'sequence', row: 'row' }[tab];

  // Filter library items by craft (knit / crochet / all)
  const filterByCraft = (items) => {
    if (craft === 'all') return items;
    return items.filter(i => i.craft === craft);
  };

  const sequences = [
    { title:'Stockinette body',  meta:'4 rows · used in 6 projects', color: t.brick,   pattern:['vline','vline','vline','vline'], craft: 'knit' },
    { title:'2x2 Rib',           meta:'2 rows · used in 11 projects', color: t.mustard, pattern:['vline','vline','dash','dash'],   craft: 'knit' },
    { title:'Seed stitch',       meta:'2 rows · used in 4 projects',  color: t.forest,  pattern:['vline','dash','vline','dash'],   craft: 'knit' },
    { title:'Garter',            meta:'2 rows · used in 9 projects',  color: t.brick,   pattern:['vline','vline'],                 craft: 'knit' },
    { title:'Cable panel · 6st', meta:'8 rows · used in 2 projects',  color: t.mustard, pattern:['cableL','cableL','vline','vline'], craft: 'knit' },
    { title:'Bobble row',        meta:'1 row · used in 3 projects',   color: t.forest,  pattern:['vline','dot','vline','dot'],     craft: 'knit' },
    { title:'Granny square ring',meta:'6 rows · used in 7 projects',  color: t.brick,   pattern:['cross','teeBar','teeBar','cross'], craft: 'crochet' },
    { title:'Shell border',      meta:'2 rows · used in 5 projects',  color: t.mustard, pattern:['fan','ch','fan','ch'],           craft: 'crochet' },
  ];
  const patterns = [
    { title:'Granny Cardigan v3',         meta:'3 parts · 12 sequences', color: t.brick,   pattern:['vline','vline','dash','dash'],   craft:'knit' },
    { title:'Sock recipe — short row heel',meta:'2 parts · 8 sequences',  color: t.mustard, pattern:['vline','vline','vline','vline'], craft:'knit' },
    { title:'Magic ring beanie',          meta:'1 part · 5 sequences',   color: t.forest,  pattern:['cross','teeBar','teeBar','cross'],craft:'crochet' },
    { title:'Hexagon throw',              meta:'1 part · 4 sequences',   color: t.brick,   pattern:['cross','teeBar','triUp','cross'], craft:'crochet' },
  ];
  const rows = [
    { name:'k1, *p2, k1*, rep', notation:'k1, *p2, k1*, rep', stitches:['k','p','p','k','p','p','k'],     craft:'knit' },
    { name:'All knit',          notation:'k all',             stitches:['k','k','k','k','k','k','k'],     craft:'knit' },
    { name:'All purl',          notation:'p all',             stitches:['p','p','p','p','p','p','p'],     craft:'knit' },
    { name:'Decrease right',    notation:'k2tog, k to end',   stitches:['k2tog','k','k','k','k'],         craft:'knit' },
    { name:'YO eyelet row',     notation:'k1, yo, k2tog *',   stitches:['k','yo','k2tog','k','yo','k2tog'],craft:'knit' },
    { name:'Granny shell',      notation:'3dc, ch1 *',        stitches:['dc','dc','dc','ch','dc','dc','dc'],craft:'crochet' },
  ];

  const visiblePats = filterByCraft(patterns);
  const visibleSeqs = filterByCraft(sequences);
  const visibleRows = filterByCraft(rows);
  const visibleCount = { pat: visiblePats.length, seq: visibleSeqs.length, row: visibleRows.length }[tab];

  return (
    <Phone dark={dark}>
      <AppBar big title="Library" sub="Reuse what you've already built." dark={dark}
        leading={<IconBtn name="back" dark={dark}/>}
      />
      <div style={{ padding: '0 20px 8px' }}>
        {/* Search */}
        <div style={{
          background: t.card, border: `1px solid ${t.rule}`, borderRadius: 14,
          padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <Icon name="search" size={18} color={t.inkMute}/>
          <span style={{ fontSize: 14, color: t.inkMute }}>Search by name, stitch, vibe…</span>
        </div>

        {/* Full-width Create CTA */}
        <button style={{
          marginTop: 10, width: '100%',
          background: `linear-gradient(180deg, ${t.brick} 0%, ${t.brickDk} 100%)`,
          color: '#FBF6EC', border: 'none', borderRadius: 14, padding: '12px 14px',
          fontFamily: FontBody, fontSize: 14, fontWeight: 700, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          boxShadow: `0 6px 16px -8px ${t.brick}`,
        }}>
          <Icon name="plus" size={16} color="#FBF6EC"/>
          <span>New {tabSingular}</span>
        </button>

        {/* Craft filter (Knit / Crochet / All) */}
        <div style={{ display: 'flex', gap: 6, marginTop: 12 }}>
          {[
            { id: 'all', label: 'All', icon: null },
            { id: 'knit', label: 'Knit', icon: 'needle' },
            { id: 'crochet', label: 'Crochet', icon: 'loop' },
          ].map(c => {
            const active = craft === c.id;
            return (
              <button key={c.id} onClick={() => setCraft(c.id)} style={{
                flex: 1, padding: '7px 10px', borderRadius: 999, cursor: 'pointer',
                background: active ? t.ink : 'transparent',
                color: active ? t.bg : t.inkSoft,
                border: active ? 'none' : `1px solid ${t.rule}`,
                fontFamily: FontBody, fontSize: 12.5, fontWeight: 600,
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              }}>
                {c.icon && <Icon name={c.icon} size={13} color={active ? t.bg : t.inkSoft}/>}
                {c.label}
              </button>
            );
          })}
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 6, marginTop: 10, background: t.cream2, padding: 4, borderRadius: 12 }}>
          {tabs.map(tb => {
            const active = tab === tb.id;
            return (
              <button key={tb.id} onClick={() => setTab(tb.id)} style={{
                flex: 1, padding: '8px 6px', background: active ? t.card : 'transparent',
                border: 'none', borderRadius: 9, fontFamily: FontBody, fontWeight: 600,
                fontSize: 13, color: active ? t.brick : t.inkSoft, cursor: 'pointer',
                boxShadow: active ? '0 1px 3px rgba(0,0,0,0.06)' : 'none',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              }}>
                {tb.label}
                <span style={{
                  fontSize: 10, fontFamily: FontMono, color: active ? t.brick : t.inkMute,
                  background: active ? t.cream2 : 'transparent', padding: '1px 6px', borderRadius: 6,
                }}>{tb.count}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '12px 20px 110px' }}>
        {empty ? <LibraryEmptyState tab={tab} dark={dark}/> : (
          <>
            {tab === 'seq' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {visibleSeqs.length === 0 ? <NoMatches craft={craft} kind="sequences" dark={dark}/> :
                  visibleSeqs.map((s, i) => <LibItem key={i} {...s} dark={dark}/>)}
              </div>
            )}
            {tab === 'pat' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {visiblePats.length === 0 ? <NoMatches craft={craft} kind="patterns" dark={dark}/> :
                  visiblePats.map((p, i) => <LibItem key={i} {...p} dark={dark} big/>)}
              </div>
            )}
            {tab === 'row' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {visibleRows.length === 0 ? <NoMatches craft={craft} kind="rows" dark={dark}/> :
                  visibleRows.map((r, i) => <RowLibItem key={i} {...r} dark={dark}/>)}
              </div>
            )}
          </>
        )}
      </div>
      <TabBar active="library" dark={dark}/>
    </Phone>
  );
}

// Empty state inside the library when no items exist yet.
function LibraryEmptyState({ tab, dark }) {
  const t = pickT(dark);
  const kind = { pat: 'patterns', seq: 'sequences', row: 'rows' }[tab];
  const verb = { pat: 'pattern', seq: 'sequence', row: 'row' }[tab];
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center',
      padding: '40px 20px', gap: 14,
    }}>
      {/* Decorative stitch motif */}
      <div style={{
        width: 96, height: 96, borderRadius: 28, background: t.cream2,
        display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative',
        border: `1px solid ${t.rule}`,
      }}>
        <div style={{ display: 'flex', gap: 6 }}>
          <div style={{ width: 26, height: 32, borderRadius: 7, background: t.brick, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: 0.4 }}>
            <StitchGlyph symbol="vline" color="#FBF6EC" size={18}/>
          </div>
          <div style={{ width: 26, height: 32, borderRadius: 7, background: t.mustard, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <StitchGlyph symbol="dash" color="#FBF6EC" size={18}/>
          </div>
          <div style={{ width: 26, height: 32, borderRadius: 7, background: t.forest, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: 0.4 }}>
            <StitchGlyph symbol="ring" color="#FBF6EC" size={18}/>
          </div>
        </div>
      </div>
      <div style={{ fontFamily: FontDisplay, fontSize: 26, color: t.brick, letterSpacing: '-0.01em', lineHeight: 1 }}>
        No {kind} yet.
      </div>
      <div style={{ fontSize: 14, color: t.inkSoft, lineHeight: 1.45, maxWidth: 280 }}>
        Save a {verb} from any project, or roll a new one from scratch. Skein remembers — so you don't have to retype `k1, p1` ever again.
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 8, width: '100%' }}>
        <Btn variant="primary" size="md" full icon="plus" dark={dark}>New {verb}</Btn>
        <Btn variant="ghost"   size="sm" full dark={dark}>Browse starter library</Btn>
      </div>
      <div style={{
        marginTop: 14, fontFamily: FontMono, fontSize: 10, color: t.inkMute,
        letterSpacing: '0.12em', textTransform: 'uppercase',
      }}>
        ✻ a blank skein, ready to wind ✻
      </div>
    </div>
  );
}

// Shown when craft filter excludes everything.
function NoMatches({ craft, kind, dark }) {
  const t = pickT(dark);
  return (
    <div style={{
      padding: 24, textAlign: 'center', color: t.inkSoft, fontSize: 13.5,
      background: t.card, border: `1.5px dashed ${t.rule}`, borderRadius: 16,
    }}>
      No <b style={{ color: t.brick, textTransform: 'lowercase' }}>{craft}</b> {kind} match this filter.
      <div style={{ marginTop: 6, fontFamily: FontMono, fontSize: 11, color: t.inkMute }}>Try "All" or roll a new one.</div>
    </div>
  );
}

function LibItem({ title, meta, color, pattern, dark, big = false }) {
  const t = pickT(dark);
  return (
    <div style={{
      background: t.card, border: `1px solid ${t.rule}`, borderRadius: 16,
      padding: 14, display: 'flex', gap: 12, alignItems: 'center',
    }}>
      <div style={{
        width: big ? 56 : 48, height: big ? 56 : 48, borderRadius: 12, background: color,
        display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 2, padding: 6,
      }}>
        {pattern.slice(0, 4).map((sym, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <StitchGlyph symbol={sym} color="#FBF6EC" size={big ? 16 : 14} stroke={1.8}/>
          </div>
        ))}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 15.5, color: t.ink, letterSpacing: '-0.005em' }}>{title}</div>
        <div style={{ fontSize: 12, color: t.inkMute, marginTop: 3, fontFamily: FontMono }}>{meta}</div>
      </div>
      <Icon name="more" size={18} color={t.inkMute}/>
    </div>
  );
}

function RowLibItem({ name, notation, stitches, dark }) {
  const t = pickT(dark);
  return (
    <div style={{
      background: t.card, border: `1px solid ${t.rule}`, borderRadius: 14, padding: 12,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 14.5, color: t.ink }}>{name}</div>
        <Icon name="more" size={16} color={t.inkMute}/>
      </div>
      <div style={{ display: 'flex', gap: 3, marginTop: 8, flexWrap: 'wrap' }}>
        {stitches.map((id, i) => {
          const s = Stitches.find(s => s.id === id);
          if (!s) return null;
          const c = i % 3 === 0 ? t.brick : i % 3 === 1 ? t.mustard : t.forest;
          return (
            <div key={i} style={{
              width: 22, height: 26, borderRadius: 6, background: t.cream2,
              border: `1.2px solid ${c}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <StitchGlyph symbol={s.symbol} color={c} size={12} stroke={1.8}/>
            </div>
          );
        })}
      </div>
      <div style={{ marginTop: 8, fontFamily: FontMono, fontSize: 11, color: t.inkMute }}>{notation}</div>
    </div>
  );
}

// ─── Stitch picker sheet (modal) — categorised ──────────────
const STITCH_GROUPS = [
  { id: 'basic_k',  label: 'Knit · basics',     ids: ['k','p','yo','sl','ns','tbl'] },
  { id: 'inc_k',    label: 'Knit · increases',  ids: ['kfb','m1'] },
  { id: 'dec_k',    label: 'Knit · decreases',  ids: ['k2tog','ssk','k3tog','p2tog'] },
  { id: 'cab_k',    label: 'Knit · texture & cables', ids: ['mb','c4f','c4b'] },
  { id: 'basic_c',  label: 'Crochet · basics',  ids: ['ch','slst','sc','hdc','dc','tr','dtr'] },
  { id: 'dec_c',    label: 'Crochet · decreases', ids: ['sc2tog','dc2tog'] },
  { id: 'post_c',   label: 'Crochet · post stitches', ids: ['fpdc','bpdc'] },
  { id: 'tex_c',    label: 'Crochet · texture', ids: ['pic','mr','shell','vst'] },
];

function StitchPickerScreen({ dark = false }) {
  const t = pickT(dark);
  const [filter, setFilter] = React.useState('all');
  // No pre-selection — users tap a stitch directly to add it. Keeping a piece
  // of state only so the grid can still highlight the last tap during a session.
  const [selected, setSelected] = React.useState(null);
  const filterChips = [
    { id: 'all',      label: 'All' },
    { id: 'knit',     label: 'Knit' },
    { id: 'crochet',  label: 'Crochet' },
    { id: 'inc',      label: 'Increases' },
    { id: 'dec',      label: 'Decreases' },
    { id: 'cable',    label: 'Cables' },
    { id: 'custom',   label: 'Custom' },
  ];
  // Which group ids match the current filter
  const groupVisible = (g) => {
    if (filter === 'all') return true;
    if (filter === 'knit')    return g.id.endsWith('_k');
    if (filter === 'crochet') return g.id.endsWith('_c');
    if (filter === 'inc')     return g.id.startsWith('inc_');
    if (filter === 'dec')     return g.id.startsWith('dec_');
    if (filter === 'cable')   return g.id === 'cab_k';
    if (filter === 'custom')  return false;
    return true;
  };
  const visibleGroups = STITCH_GROUPS.filter(groupVisible);

  return (
    <Phone dark={dark}>
      <div style={{
        position: 'absolute', inset: 0, background: dark ? 'rgba(0,0,0,0.55)' : 'rgba(43,24,16,0.35)',
        backdropFilter: 'blur(4px)',
      }}/>
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        background: t.bg, borderTopLeftRadius: 28, borderTopRightRadius: 28,
        padding: '12px 0 32px', maxHeight: '88%', overflow: 'hidden',
        boxShadow: '0 -10px 30px rgba(0,0,0,0.15)',
        display: 'flex', flexDirection: 'column',
      }}>
        <div style={{ width: 44, height: 5, background: t.rule, borderRadius: 3, margin: '0 auto 8px' }}/>

        {/* Header */}
        <div style={{ padding: '0 20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
            <div>
              <div style={{ fontFamily: FontDisplay, fontSize: 24, color: t.brick, letterSpacing: '-0.01em' }}>Pick a stitch</div>
              <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: 2 }}>
                Tap to add · {Stitches.length} predefined + custom
              </div>
            </div>
            <Icon name="x" size={22} color={t.inkSoft}/>
          </div>

          {/* Filter chips */}
          <div style={{ display: 'flex', gap: 6, overflow: 'auto', paddingBottom: 2 }}>
            {filterChips.map(f => {
              const active = filter === f.id;
              return (
                <button key={f.id} onClick={() => setFilter(f.id)} style={{
                  padding: '6px 12px', borderRadius: 999, fontSize: 12, fontWeight: 600, whiteSpace: 'nowrap',
                  background: active ? t.brick : t.cream2,
                  color: active ? '#FBF6EC' : t.inkSoft,
                  border: 'none', cursor: 'pointer',
                  flexShrink: 0,
                }}>{f.label}</button>
              );
            })}
          </div>
        </div>

        {/* Scrollable grouped grid */}
        <div style={{ flex: 1, overflow: 'auto', padding: '12px 20px 0' }}>
          {filter === 'custom' ? (
            <CustomStitchPanel dark={dark}/>
          ) : (
            visibleGroups.map(group => (
              <StitchGroup
                key={group.id}
                group={group}
                selected={selected}
                onSelect={setSelected}
                dark={dark}
              />
            ))
          )}
          {/* Always-available custom CTA at end */}
          {filter !== 'custom' && (
            <button style={{
              marginTop: 6, marginBottom: 16, width: '100%',
              background: 'transparent', border: `1.5px dashed ${t.brick}`, color: t.brick, padding: '12px',
              borderRadius: 12, fontFamily: FontBody, fontSize: 13, fontWeight: 600, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            }}>
              <Icon name="plus" size={14} color={t.brick}/> Define a custom stitch
            </button>
          )}
        </div>
      </div>
    </Phone>
  );
}

function StitchGroup({ group, selected, onSelect, dark }) {
  const t = pickT(dark);
  const items = group.ids.map(id => Stitches.find(s => s.id === id)).filter(Boolean);
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{
        fontFamily: FontMono, fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase',
        color: t.inkMute, marginBottom: 8, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <span>{group.label}</span>
        <span>{items.length}</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 8 }}>
        {items.map((s, i) => {
          const palette = [t.brick, t.mustard, t.forest, t.brickDk];
          const c = palette[i % 4];
          const isSelected = selected === s.id;
          return (
            <button key={s.id} onClick={() => onSelect(s.id)} style={{
              background: isSelected ? c : t.card,
              border: isSelected ? `1.5px solid ${c}` : `1px solid ${t.rule}`,
              borderRadius: 12, padding: '10px 4px 8px',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
              cursor: 'pointer', transition: 'background 120ms ease',
            }}>
              <div style={{
                width: 36, height: 36, borderRadius: 10,
                background: isSelected ? 'rgba(255,255,255,0.18)' : c,
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              }}>
                <StitchGlyph symbol={s.symbol} color="#FBF6EC" size={20}/>
              </div>
              <div style={{ fontSize: 11, fontFamily: FontMono, color: isSelected ? '#FBF6EC' : t.inkSoft, fontWeight: 700 }}>{s.abbr}</div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─── Custom stitch — full screen definer ───────────────────────────────────
// Reached from the stitch picker via "Define a custom stitch". A focused
// detail form, not a sheet — defining a stitch is enough work to warrant
// the whole canvas. `filled` shows the screen pre-populated with a sample
// (Fisherman's rib) so you can see the live preview drive everything.
function CustomStitchScreen({ dark = false, filled = false }) {
  const t = pickT(dark);

  // Two snapshots — empty vs. filled — for hand-off variants.
  const initial = filled
    ? { abbr: 'fr',  name: "Fisherman's rib",   craft: 'knit',    symbol: 'vlineX', tile: 'brick',   counts: 'one', notation: "k1 below — insert needle into the stitch one row below, knit it & let the live stitch drop." }
    : { abbr: '',    name: '',                   craft: 'knit',    symbol: 'vline',  tile: 'brick',   counts: 'one', notation: '' };

  const [abbr,     setAbbr]     = React.useState(initial.abbr);
  const [name,     setName]     = React.useState(initial.name);
  const [craft,    setCraft]    = React.useState(initial.craft);
  const [symbol,   setSymbol]   = React.useState(initial.symbol);
  const [tile,     setTile]     = React.useState(initial.tile);
  const [counts,   setCounts]   = React.useState(initial.counts);
  const [notation, setNotation] = React.useState(initial.notation);

  const colorMap = { brick: t.brick, mustard: t.mustard, forest: t.forest, brickDk: t.brickDk, mustardDk: t.mustardDk, forestDk: t.forestDk };
  const tileC = colorMap[tile];

  // Pulled from the StitchGlyph switch — give the user a varied palette
  // of chart marks to assign to their stitch without overwhelming the grid.
  const symbols = [
    'vline','vline2','vlineX','dash','vee','vee2','triUp',
    'plus','dot','ring','ringBig','oval','cross','slashR','slashL',
    'cableL','cableR','tee','teeBar','teeBar2','fan','flower',
  ];

  // Form gate: need both an abbr and a name to save.
  const ready = abbr.trim().length > 0 && name.trim().length > 0;

  // Small, inline helpers so we don't tangle with the wizard's Section.
  const Lbl = ({ children, hint }) => (
    <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 8 }}>
      <div style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute, letterSpacing: '0.18em', textTransform: 'uppercase' }}>{children}</div>
      {hint && <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.04em' }}>{hint}</div>}
    </div>
  );

  const fieldStyle = {
    width: '100%', background: t.card, border: `1px solid ${t.rule}`, borderRadius: 12,
    padding: '12px 14px', fontFamily: FontBody, fontSize: 15, color: t.ink, outline: 'none',
    letterSpacing: '-0.005em', boxSizing: 'border-box',
  };

  return (
    <Phone dark={dark}>
      {/* Top bar */}
      <div style={{ padding: '8px 20px 4px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', minHeight: 36 }}>
          <IconBtn name="x" dark={dark}/>
          <div style={{
            fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.2em',
            textTransform: 'uppercase', padding: '4px 10px', borderRadius: 999,
            background: t.cream2, border: `1px solid ${t.rule}`,
          }}>Custom · draft</div>
          <button style={{
            background: 'transparent', border: 'none', cursor: ready ? 'pointer' : 'not-allowed',
            color: ready ? t.brick : t.inkMute, fontFamily: FontBody, fontWeight: 700, fontSize: 14,
            padding: '6px 4px', letterSpacing: '-0.005em',
          }}>Save</button>
        </div>
        <div style={{ marginTop: 8 }}>
          <div style={{ fontFamily: FontDisplay, fontSize: 32, color: t.brick, letterSpacing: '-0.01em', lineHeight: 1 }}>
            Define a stitch
          </div>
          <div style={{ fontSize: 13.5, color: t.inkSoft, marginTop: 6, lineHeight: 1.4 }}>
            For anything not in the standard set — grandma's secret rib, your favorite bobble variation.
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '14px 20px 120px' }}>

        {/* ─── LIVE PREVIEW — the tile that will appear in the picker ─── */}
        <div style={{
          display: 'flex', gap: 14, alignItems: 'stretch',
          background: t.card, borderRadius: 18, padding: 14,
          border: `1.5px solid ${t.brick}`,
          boxShadow: `0 8px 22px -16px ${t.brick}`,
        }}>
          {/* tile preview — same proportions as the chart cell */}
          <div style={{
            width: 96, height: 110, borderRadius: 16, background: tileC, flexShrink: 0,
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            position: 'relative', gap: 6,
            boxShadow: `inset 0 -3px 0 rgba(0,0,0,0.12)`,
          }}>
            <StitchGlyph symbol={symbol} color="#FBF6EC" size={48} stroke={2.4}/>
            <div style={{
              fontFamily: FontMono, fontSize: 11, color: '#FBF6EC', fontWeight: 700, opacity: 0.95,
              letterSpacing: '0.04em',
            }}>{abbr || '—'}</div>
            {/* tiny corner ribbon */}
            <div style={{
              position: 'absolute', top: -7, right: -7,
              background: t.mustard, color: t.ink, fontFamily: FontMono, fontWeight: 700,
              fontSize: 9, padding: '3px 6px', borderRadius: 5, letterSpacing: '0.08em',
              border: `1px solid ${t.card}`,
            }}>NEW</div>
          </div>
          <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 6 }}>
            <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.18em', textTransform: 'uppercase' }}>
              Live preview
            </div>
            <div style={{
              fontFamily: FontDisplay, fontSize: 24, color: name ? t.ink : t.inkMute,
              lineHeight: 1.05, letterSpacing: '-0.01em',
              fontStyle: name ? 'normal' : 'italic',
            }}>
              {name || 'Untitled stitch'}
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 2 }}>
              <PreviewChip dark={dark} accent={t.brick}>{abbr || '— '}</PreviewChip>
              <PreviewChip dark={dark}>{craft}</PreviewChip>
              <PreviewChip dark={dark}>
                {counts === 'inc' ? '+1 st' : counts === 'dec' ? '−1 st' : '1 → 1'}
              </PreviewChip>
            </div>
          </div>
        </div>

        {/* ─── IDENTITY: abbreviation + full name ─── */}
        <div style={{ marginTop: 22 }}>
          <Lbl hint="shown in charts">Abbreviation &amp; name</Lbl>
          <div style={{ display: 'flex', gap: 10 }}>
            <div style={{ width: 110 }}>
              <input
                value={abbr}
                onChange={(e) => setAbbr(e.target.value.slice(0, 8))}
                placeholder="fr"
                style={{
                  ...fieldStyle, fontFamily: FontMono, fontWeight: 700, fontSize: 16,
                  letterSpacing: '0.04em', textAlign: 'center',
                  borderColor: abbr ? t.brick : t.rule,
                  borderWidth: abbr ? 1.5 : 1, color: t.brick,
                }}
              />
              <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, marginTop: 4, textAlign: 'center', letterSpacing: '0.06em' }}>
                {abbr.length}/8
              </div>
            </div>
            <div style={{ flex: 1 }}>
              <input
                value={name}
                onChange={(e) => setName(e.target.value.slice(0, 36))}
                placeholder="Fisherman's rib"
                style={fieldStyle}
              />
              <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, marginTop: 4, letterSpacing: '0.06em' }}>
                {name.length}/36 · keep it short, it has to fit on a tile
              </div>
            </div>
          </div>
        </div>

        {/* ─── CRAFT ─── */}
        <div style={{ marginTop: 22 }}>
          <Lbl>Craft</Lbl>
          <div style={{ display: 'flex', gap: 8 }}>
            {[
              { id: 'knit',    label: 'Knit',    icon: 'needle' },
              { id: 'crochet', label: 'Crochet', icon: 'loop' },
            ].map(c => {
              const active = craft === c.id;
              return (
                <button key={c.id} onClick={() => setCraft(c.id)} style={{
                  flex: 1, padding: '12px 14px', borderRadius: 12, cursor: 'pointer',
                  background: active ? t.brick : t.card,
                  color: active ? '#FBF6EC' : t.ink,
                  border: active ? 'none' : `1px solid ${t.rule}`,
                  fontFamily: FontBody, fontSize: 14.5, fontWeight: 700,
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                  letterSpacing: '-0.005em',
                }}>
                  <Icon name={c.icon} size={16} color={active ? '#FBF6EC' : t.brick}/>
                  {c.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* ─── SYMBOL PICKER — assigned to the tile ─── */}
        <div style={{ marginTop: 22 }}>
          <Lbl hint={`${symbols.length} marks`}>Chart symbol</Lbl>
          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 6,
            background: t.cream2, padding: 8, borderRadius: 14,
            border: `1px solid ${t.rule}`,
          }}>
            {symbols.map((sym) => {
              const active = symbol === sym;
              return (
                <button key={sym} onClick={() => setSymbol(sym)} style={{
                  aspectRatio: '1 / 1', borderRadius: 10, cursor: 'pointer',
                  background: active ? tileC : t.card,
                  border: active ? 'none' : `1px solid ${t.rule}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  transition: 'background 120ms ease',
                  boxShadow: active ? `0 4px 10px -6px ${tileC}` : 'none',
                }}>
                  <StitchGlyph symbol={sym} color={active ? '#FBF6EC' : t.inkSoft} size={20} stroke={2.2}/>
                </button>
              );
            })}
          </div>
        </div>

        {/* ─── TILE COLOR — which accent it owns on charts ─── */}
        <div style={{ marginTop: 22 }}>
          <Lbl hint="how it sits next to its neighbors">Tile color</Lbl>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            {[
              { id: 'brick',     color: t.brick,     name: 'Brick' },
              { id: 'mustard',   color: t.mustard,   name: 'Mustard' },
              { id: 'forest',    color: t.forest,    name: 'Forest' },
              { id: 'brickDk',   color: t.brickDk,   name: 'Maroon' },
              { id: 'mustardDk', color: t.mustardDk, name: 'Ochre' },
              { id: 'forestDk',  color: t.forestDk,  name: 'Moss' },
            ].map(s => {
              const active = tile === s.id;
              return (
                <button key={s.id} onClick={() => setTile(s.id)} style={{
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
                  background: 'transparent', border: 'none', cursor: 'pointer', padding: 0,
                }}>
                  <div style={{
                    width: 44, height: 44, borderRadius: 12, background: s.color,
                    boxShadow: active ? `0 0 0 3px ${t.bg}, 0 0 0 5px ${t.ink}` : `inset 0 -2px 0 rgba(0,0,0,0.10)`,
                    transition: 'box-shadow 140ms ease',
                  }}/>
                  <div style={{
                    fontFamily: FontMono, fontSize: 9.5, color: active ? t.ink : t.inkMute,
                    fontWeight: active ? 700 : 500, letterSpacing: '0.06em', textTransform: 'lowercase',
                  }}>{s.name}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* ─── COUNTS AS — stitch math (for row-totals) ─── */}
        <div style={{ marginTop: 22 }}>
          <Lbl hint="affects row totals">Counts as</Lbl>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6, background: t.cream2, padding: 4, borderRadius: 12 }}>
            {[
              { id: 'inc', label: 'Increase', math: '+1 st' },
              { id: 'one', label: 'One-to-one', math: '1 → 1' },
              { id: 'dec', label: 'Decrease', math: '−1 st' },
            ].map(o => {
              const active = counts === o.id;
              return (
                <button key={o.id} onClick={() => setCounts(o.id)} style={{
                  padding: '10px 6px', borderRadius: 9, cursor: 'pointer',
                  background: active ? t.card : 'transparent',
                  border: 'none',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
                  boxShadow: active ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
                }}>
                  <span style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 13, color: active ? t.brick : t.inkSoft, letterSpacing: '-0.005em' }}>{o.label}</span>
                  <span style={{ fontFamily: FontMono, fontSize: 10, color: active ? t.inkSoft : t.inkMute, letterSpacing: '0.04em' }}>{o.math}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* ─── NOTATION — free-text how-to ─── */}
        <div style={{ marginTop: 22 }}>
          <Lbl hint="optional · for your memory">How to work it</Lbl>
          <textarea
            value={notation}
            onChange={(e) => setNotation(e.target.value.slice(0, 240))}
            placeholder="A line or two on how to make this stitch — needle position, yarn-over direction, anything that'll save Future-You a Google."
            style={{
              ...fieldStyle, minHeight: 84, resize: 'none', lineHeight: 1.5, fontSize: 13.5,
            }}
          />
          <div style={{
            display: 'flex', justifyContent: 'space-between', marginTop: 6,
            fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.04em',
          }}>
            <span>Markdown is fine.</span>
            <span>{notation.length}/240</span>
          </div>
        </div>

        {/* ─── ADD TO GROUP — optional bucket in the picker ─── */}
        <div style={{ marginTop: 22 }}>
          <Lbl hint="optional">File under</Lbl>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {['Basics','Increases','Decreases','Cables & texture','My customs ★'].map((label, i) => {
              const active = i === 4;
              return (
                <div key={label} style={{
                  padding: '7px 12px', borderRadius: 999, fontSize: 12.5, fontWeight: 600,
                  background: active ? t.mustard : t.card,
                  color: active ? t.ink : t.inkSoft,
                  border: active ? 'none' : `1px solid ${t.rule}`,
                  cursor: 'pointer', fontFamily: FontBody,
                }}>{label}</div>
              );
            })}
          </div>
        </div>

        {/* hand-letter sign-off — keeps the folk vibe */}
        <div style={{
          marginTop: 26, textAlign: 'center',
          fontFamily: FontMono, fontSize: 10, color: t.inkMute,
          letterSpacing: '0.18em', textTransform: 'uppercase',
        }}>
          ✻ one of one, just yours ✻
        </div>
      </div>

      {/* Footer — pinned save bar */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        padding: '14px 20px 28px', background: t.bg, borderTop: `1px solid ${t.rule}`,
      }}>
        <div style={{ display: 'flex', gap: 10 }}>
          <Btn variant="ghost" size="lg" dark={dark}>Cancel</Btn>
          {ready ? (
            <Btn variant="primary" size="lg" full icon="save" dark={dark}>
              Save stitch
            </Btn>
          ) : (
            <button aria-disabled="true" style={{
              flex: 1, height: 58, borderRadius: 14,
              background: dark ? 'rgba(255,122,77,0.14)' : '#E8D6CF',
              border: `1.5px dashed ${t.brick}`, color: t.brick,
              fontFamily: FontBody, fontSize: 16, fontWeight: 700, letterSpacing: '-0.005em',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              cursor: 'not-allowed',
            }}>
              <Icon name="save" size={18} color={t.brick}/>
              Name &amp; abbreviation first
            </button>
          )}
        </div>
      </div>
    </Phone>
  );
}

// Small chip used inside the custom-stitch live preview.
function PreviewChip({ children, dark, accent }) {
  const t = pickT(dark);
  return (
    <div style={{
      padding: '3px 8px', borderRadius: 6, background: t.cream2,
      fontFamily: FontMono, fontSize: 10.5, color: accent || t.inkSoft,
      fontWeight: 700, letterSpacing: '0.04em', textTransform: 'lowercase',
    }}>{children}</div>
  );
}

function CustomStitchPanel({ dark }) {
  const t = pickT(dark);
  return (
    <div style={{
      padding: 16, borderRadius: 16, background: t.card, border: `1.5px dashed ${t.brick}`,
      display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 14,
    }}>
      <div style={{ fontFamily: FontDisplay, fontSize: 20, color: t.brick, letterSpacing: '-0.01em' }}>Roll your own.</div>
      <div style={{ fontSize: 13, color: t.inkSoft, lineHeight: 1.45 }}>
        Got a stitch that's not in the list — bobble pattern, fisherman's rib variation, your grandma's secret? Define it here.
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <div style={{
          flex: 1, background: t.bg, border: `1px solid ${t.rule}`, borderRadius: 10,
          padding: '10px 12px', fontSize: 13, color: t.inkMute, fontFamily: FontMono,
        }}>Abbreviation (e.g. "fr")</div>
        <div style={{
          flex: 2, background: t.bg, border: `1px solid ${t.rule}`, borderRadius: 10,
          padding: '10px 12px', fontSize: 13, color: t.inkMute, fontFamily: FontMono,
        }}>Name (e.g. "Fisherman's rib")</div>
      </div>
      <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.1em', textTransform: 'uppercase' }}>Symbol</div>
      <div style={{ display: 'flex', gap: 6 }}>
        {['vline','dash','ring','vee','triUp','plus','dot','cross'].map((sym, i) => (
          <div key={sym} style={{
            width: 38, height: 38, borderRadius: 10,
            background: i === 0 ? t.brick : t.bg, border: i === 0 ? 'none' : `1px solid ${t.rule}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <StitchGlyph symbol={sym} color={i === 0 ? '#FBF6EC' : t.inkSoft} size={18}/>
          </div>
        ))}
      </div>
      <Btn variant="primary" size="md" full icon="plus" dark={dark}>Save custom stitch</Btn>
    </div>
  );
}

// ─── Sequence / Pattern picker (modal sheet) ──────────────────
// Same shape as the stitch picker, but for the two larger reusable building blocks.
// Mode toggle at top switches between picking one sequence OR a whole pattern
// (a pattern = several sequences in one bulk drop).
const SAMPLE_SEQUENCES = [
  { id:'stk',  title:'Stockinette body',  meta:'4 rows · used in 6 projects',  color:'brick',   pattern:['vline','vline','vline','vline'],            craft:'knit',    rows:4 },
  { id:'rib',  title:'2x2 Rib',           meta:'2 rows · used in 11 projects', color:'mustard', pattern:['vline','vline','dash','dash'],              craft:'knit',    rows:2 },
  { id:'seed', title:'Seed stitch',       meta:'2 rows · used in 4 projects',  color:'forest',  pattern:['vline','dash','vline','dash'],              craft:'knit',    rows:2 },
  { id:'gar',  title:'Garter',            meta:'2 rows · used in 9 projects',  color:'brick',   pattern:['vline','vline'],                            craft:'knit',    rows:2 },
  { id:'cab',  title:'Cable panel · 6st', meta:'8 rows · used in 2 projects',  color:'mustard', pattern:['cableL','cableL','vline','vline'],          craft:'knit',    rows:8 },
  { id:'bob',  title:'Bobble row',        meta:'1 row · used in 3 projects',   color:'forest',  pattern:['vline','dot','vline','dot'],                craft:'knit',    rows:1 },
  { id:'gs',   title:'Granny square ring',meta:'6 rows · used in 7 projects',  color:'brick',   pattern:['cross','teeBar','teeBar','cross'],          craft:'crochet', rows:6 },
  { id:'sh',   title:'Shell border',      meta:'2 rows · used in 5 projects',  color:'mustard', pattern:['fan','ch','fan','ch'],                      craft:'crochet', rows:2 },
];

const SAMPLE_PATTERNS = [
  { id:'gc',  title:'Granny Cardigan v3',          meta:'3 parts · 12 sequences', color:'brick',   craft:'knit',
    sequences:['Ribbed hem','Stockinette body','Decrease shaping','Sleeve rib','Sleeve body','Sleeve cap'] },
  { id:'sk',  title:'Sock recipe — short row heel', meta:'2 parts · 8 sequences',  color:'mustard', craft:'knit',
    sequences:['Cuff rib','Leg stockinette','Heel turn','Foot','Toe decreases'] },
  { id:'mb',  title:'Magic ring beanie',           meta:'1 part · 5 sequences',   color:'forest',  craft:'crochet',
    sequences:['Magic ring','Increase rounds','Body','Crown decreases','Edge'] },
  { id:'hx',  title:'Hexagon throw',               meta:'1 part · 4 sequences',   color:'brick',   craft:'crochet',
    sequences:['Foundation hex','Outer rounds','Joining row','Border'] },
];

function SequencePickerScreen({ dark = false }) {
  const t = pickT(dark);
  const [mode, setMode] = React.useState('sequence'); // 'sequence' | 'pattern'
  const [craft, setCraft] = React.useState('all');
  const [selectedId, setSelectedId] = React.useState('stk');
  const [selectedPatId, setSelectedPatId] = React.useState('gc');

  const colorMap = { brick: t.brick, mustard: t.mustard, forest: t.forest };
  const filterByCraft = (items) => craft === 'all' ? items : items.filter(i => i.craft === craft);

  const visibleSeqs = filterByCraft(SAMPLE_SEQUENCES);
  const visiblePats = filterByCraft(SAMPLE_PATTERNS);

  const selectedSeq = SAMPLE_SEQUENCES.find(s => s.id === selectedId) || SAMPLE_SEQUENCES[0];
  const selectedPat = SAMPLE_PATTERNS.find(p => p.id === selectedPatId) || SAMPLE_PATTERNS[0];

  const isPattern = mode === 'pattern';

  return (
    <Phone dark={dark}>
      <div style={{
        position: 'absolute', inset: 0, background: dark ? 'rgba(0,0,0,0.55)' : 'rgba(43,24,16,0.35)',
        backdropFilter: 'blur(4px)',
      }}/>
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        background: t.bg, borderTopLeftRadius: 28, borderTopRightRadius: 28,
        padding: '12px 0 32px', maxHeight: '92%', overflow: 'hidden',
        boxShadow: '0 -10px 30px rgba(0,0,0,0.15)',
        display: 'flex', flexDirection: 'column',
      }}>
        <div style={{ width: 44, height: 5, background: t.rule, borderRadius: 3, margin: '0 auto 8px' }}/>

        <div style={{ padding: '0 20px' }}>
          {/* Header */}
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 14 }}>
            <div>
              <div style={{ fontFamily: FontDisplay, fontSize: 24, color: t.brick, letterSpacing: '-0.01em', lineHeight: 1 }}>Add from library</div>
              <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: 6 }}>
                Skip the rebuild · {isPattern ? `${SAMPLE_PATTERNS.length} patterns saved` : `${SAMPLE_SEQUENCES.length} sequences saved`}
              </div>
            </div>
            <Icon name="x" size={22} color={t.inkSoft}/>
          </div>

          {/* Mode toggle — sequence vs pattern */}
          <div style={{ display: 'flex', gap: 6, background: t.cream2, padding: 4, borderRadius: 12 }}>
            {[
              { id: 'sequence', label: 'Sequence', sub: 'one block',         count: SAMPLE_SEQUENCES.length },
              { id: 'pattern',  label: 'Pattern',  sub: 'several at once',   count: SAMPLE_PATTERNS.length },
            ].map(m => {
              const active = mode === m.id;
              return (
                <button key={m.id} onClick={() => setMode(m.id)} style={{
                  flex: 1, padding: '10px 8px', background: active ? t.card : 'transparent',
                  border: 'none', borderRadius: 9, cursor: 'pointer',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
                  boxShadow: active ? '0 1px 3px rgba(0,0,0,0.06)' : 'none',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 13.5, color: active ? t.brick : t.inkSoft }}>{m.label}</span>
                    <span style={{
                      fontSize: 9.5, fontFamily: FontMono, fontWeight: 700, color: active ? t.brick : t.inkMute,
                      background: active ? t.cream2 : 'transparent', padding: '1px 6px', borderRadius: 6,
                    }}>{m.count}</span>
                  </div>
                  <span style={{ fontFamily: FontMono, fontSize: 9.5, color: t.inkMute, letterSpacing: '0.04em' }}>{m.sub}</span>
                </button>
              );
            })}
          </div>

          {/* Selected preview header */}
          <div style={{
            marginTop: 12, background: t.card, border: `1.5px solid ${t.brick}`, borderRadius: 14,
            padding: 12, display: 'flex', flexDirection: 'column', gap: 10,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              {!isPattern ? (
                <div style={{
                  width: 48, height: 48, borderRadius: 12, background: colorMap[selectedSeq.color],
                  display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 2, padding: 6, flexShrink: 0,
                }}>
                  {selectedSeq.pattern.slice(0, 4).map((sym, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <StitchGlyph symbol={sym} color="#FBF6EC" size={14} stroke={1.8}/>
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{
                  width: 48, height: 48, borderRadius: 12, background: colorMap[selectedPat.color],
                  display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                  color: '#FBF6EC', fontFamily: FontDisplay, fontSize: 22,
                }}>
                  {selectedPat.sequences.length}
                </div>
              )}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: FontDisplay, fontSize: 20, color: t.ink, letterSpacing: '-0.01em', lineHeight: 1.1 }}>
                  {isPattern ? selectedPat.title : selectedSeq.title}
                </div>
                <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, marginTop: 3, letterSpacing: '0.04em' }}>
                  {isPattern ? selectedPat.meta : selectedSeq.meta}
                </div>
              </div>
              <Btn variant="primary" size="sm" icon="plus" dark={dark}>Add</Btn>
            </div>

            {/* Pattern: list its child sequences as chips */}
            {isPattern && (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, paddingTop: 4, borderTop: `1px solid ${t.rule}` }}>
                {selectedPat.sequences.map((seqName, i) => (
                  <div key={i} style={{
                    padding: '4px 8px', borderRadius: 8, background: t.cream2,
                    fontFamily: FontMono, fontSize: 10, color: t.inkSoft, fontWeight: 600,
                    letterSpacing: '0.02em',
                  }}>{seqName}</div>
                ))}
              </div>
            )}
          </div>

          {/* Craft filter */}
          <div style={{ display: 'flex', gap: 6, marginTop: 12 }}>
            {[
              { id: 'all', label: 'All', icon: null },
              { id: 'knit', label: 'Knit', icon: 'needle' },
              { id: 'crochet', label: 'Crochet', icon: 'loop' },
            ].map(c => {
              const active = craft === c.id;
              return (
                <button key={c.id} onClick={() => setCraft(c.id)} style={{
                  flex: 1, padding: '6px 10px', borderRadius: 999, cursor: 'pointer',
                  background: active ? t.ink : 'transparent',
                  color: active ? t.bg : t.inkSoft,
                  border: active ? 'none' : `1px solid ${t.rule}`,
                  fontFamily: FontBody, fontSize: 12, fontWeight: 600,
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                }}>
                  {c.icon && <Icon name={c.icon} size={12} color={active ? t.bg : t.inkSoft}/>}
                  {c.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Scrollable list */}
        <div style={{ flex: 1, overflow: 'auto', padding: '10px 20px 0' }}>
          {!isPattern ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {visibleSeqs.length === 0 ? <NoMatches craft={craft} kind="sequences" dark={dark}/> :
                visibleSeqs.map(s => (
                  <button key={s.id} onClick={() => setSelectedId(s.id)} style={{
                    background: t.card,
                    border: selectedId === s.id ? `1.5px solid ${t.brick}` : `1px solid ${t.rule}`,
                    borderRadius: 14, padding: 12, display: 'flex', gap: 12, alignItems: 'center',
                    cursor: 'pointer', textAlign: 'left', width: '100%',
                  }}>
                    <div style={{
                      width: 42, height: 42, borderRadius: 10, background: colorMap[s.color],
                      display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 2, padding: 5, flexShrink: 0,
                    }}>
                      {s.pattern.slice(0, 4).map((sym, i) => (
                        <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <StitchGlyph symbol={sym} color="#FBF6EC" size={12} stroke={1.8}/>
                        </div>
                      ))}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 14.5, color: t.ink }}>{s.title}</div>
                      <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, marginTop: 2 }}>{s.meta}</div>
                    </div>
                    {selectedId === s.id && <Icon name="check" size={18} color={t.brick} stroke={2.6}/>}
                  </button>
                ))}
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {visiblePats.length === 0 ? <NoMatches craft={craft} kind="patterns" dark={dark}/> :
                visiblePats.map(p => (
                  <button key={p.id} onClick={() => setSelectedPatId(p.id)} style={{
                    background: t.card,
                    border: selectedPatId === p.id ? `1.5px solid ${t.brick}` : `1px solid ${t.rule}`,
                    borderRadius: 14, padding: 12, display: 'flex', flexDirection: 'column', gap: 8,
                    cursor: 'pointer', textAlign: 'left', width: '100%',
                  }}>
                    <div style={{ display: 'flex', gap: 12, alignItems: 'center', width: '100%' }}>
                      <div style={{
                        width: 42, height: 42, borderRadius: 10, background: colorMap[p.color],
                        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                        color: '#FBF6EC', fontFamily: FontDisplay, fontSize: 18,
                      }}>{p.sequences.length}</div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 14.5, color: t.ink }}>{p.title}</div>
                        <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, marginTop: 2 }}>{p.meta}</div>
                      </div>
                      {selectedPatId === p.id && <Icon name="check" size={18} color={t.brick} stroke={2.6}/>}
                    </div>
                    {/* sequence chips preview */}
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3, paddingLeft: 54 }}>
                      {p.sequences.slice(0, 4).map((s, i) => (
                        <div key={i} style={{
                          padding: '2px 7px', borderRadius: 6, background: t.cream2,
                          fontFamily: FontMono, fontSize: 9.5, color: t.inkSoft, fontWeight: 600,
                        }}>{s}</div>
                      ))}
                      {p.sequences.length > 4 && (
                        <div style={{
                          padding: '2px 7px', borderRadius: 6,
                          fontFamily: FontMono, fontSize: 9.5, color: t.inkMute, fontWeight: 600,
                        }}>+ {p.sequences.length - 4} more</div>
                      )}
                    </div>
                  </button>
                ))}
            </div>
          )}

          {/* Build new CTA at the end */}
          <button style={{
            marginTop: 10, marginBottom: 16, width: '100%',
            background: 'transparent', border: `1.5px dashed ${t.brick}`, color: t.brick, padding: '12px',
            borderRadius: 12, fontFamily: FontBody, fontSize: 13, fontWeight: 700, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          }}>
            <Icon name="plus" size={14} color={t.brick}/> Build a new {isPattern ? 'pattern' : 'sequence'} from scratch
          </button>
        </div>
      </div>
    </Phone>
  );
}

Object.assign(window, { LibraryScreen, StitchPickerScreen, SequencePickerScreen, CustomStitchScreen });
