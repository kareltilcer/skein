// Setup wizard — multi-step. Each step is a self-contained screen.

// Step indicator across the top.
function WizardSteps({ step, total = 4, dark = false }) {
  const t = pickT(dark);
  return (
    <div style={{ display: 'flex', gap: 6, padding: '0 20px 12px' }}>
      {Array.from({ length: total }).map((_, i) => (
        <div key={i} style={{
          flex: 1, height: 6, borderRadius: 4,
          background: i < step ? t.brick : (i === step ? t.mustard : t.cream2),
        }}/>
      ))}
    </div>
  );
}

function WizardHeader({ step, total, label, title, sub, dark = false, onBack }) {
  const t = pickT(dark);
  return (
    <div>
      <AppBar
        title="Cast on"
        dark={dark}
        leading={<IconBtn name="x" dark={dark} onClick={onBack}/>}
        trailing={<div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute }}>{step + 1}/{total}</div>}
      />
      <WizardSteps step={step} total={total} dark={dark}/>
      <div style={{ padding: '6px 24px 18px' }}>
        <div style={{ fontFamily: FontMono, fontSize: 11, letterSpacing: '0.16em', color: t.mustardDk, textTransform: 'uppercase' }}>{label}</div>
        <div style={{ fontFamily: FontDisplay, fontSize: 30, color: t.brick, lineHeight: 1.05, marginTop: 6, letterSpacing: '-0.01em' }}>{title}</div>
        {sub && <div style={{ fontSize: 13.5, color: t.inkSoft, marginTop: 8, lineHeight: 1.45 }}>{sub}</div>}
      </div>
    </div>
  );
}

function WizardFooter({ primary = 'Next', onPrimary, secondary = 'Back', onSecondary, dark = false, blocked = false, blockedMsg }) {
  const t = pickT(dark);
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      padding: blocked ? '10px 20px 28px' : '14px 20px 28px', background: t.bg,
      borderTop: `1px solid ${t.rule}`,
    }}>
      {blocked && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: dark ? 'rgba(255,122,77,0.10)' : '#FBEFEA',
          border: `1px solid ${dark ? 'rgba(255,122,77,0.35)' : 'rgba(156,61,46,0.25)'}`,
          borderRadius: 12, padding: '8px 12px', marginBottom: 10,
        }}>
          <span style={{
            width: 18, height: 18, borderRadius: 999, background: t.brick, color: '#FBF6EC',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: FontDisplay, fontSize: 13, lineHeight: 1, flexShrink: 0,
          }}>!</span>
          <div style={{
            flex: 1, fontFamily: FontBody, fontSize: 13, fontWeight: 600,
            color: t.brick, letterSpacing: '-0.005em',
          }}>{blockedMsg || 'Fill the required fields to continue.'}</div>
          <Icon name="chevDown" size={14} color={t.brick}/>
        </div>
      )}
      <div style={{ display: 'flex', gap: 10 }}>
        <Btn variant="ghost" size="lg" onClick={onSecondary} dark={dark}>{secondary}</Btn>
        {blocked ? (
          <button
            onClick={onPrimary}
            aria-disabled="true"
            style={{
              flex: 1, height: 52, borderRadius: 14,
              background: dark ? 'rgba(255,122,77,0.18)' : '#E8D6CF',
              border: `1.5px dashed ${t.brick}`,
              color: t.brick,
              fontFamily: FontBody, fontSize: 15, fontWeight: 700,
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              cursor: 'not-allowed', letterSpacing: '-0.005em',
            }}
          >
            <span style={{
              width: 18, height: 18, borderRadius: 999, background: t.brick, color: '#FBF6EC',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: FontDisplay, fontSize: 12, lineHeight: 1,
            }}>!</span>
            {primary}
          </button>
        ) : (
          <Btn variant="primary" size="lg" style={{ flex: 1 }} icon="chevR" onClick={onPrimary} dark={dark}>{primary}</Btn>
        )}
      </div>
    </div>
  );
}

// ── Reuse chooser — split CTA: create new vs pick from Library ─
// Used in both Step 3 (rows) and Step 4 (sequences) to give the user
// a clear choice between rolling a new building block or pulling
// from the saved library so they don't rebuild what they've already saved.
function ReuseChooser({ kind, libraryCount, dark }) {
  const t = pickT(dark);
  const label = kind === 'row' ? 'row' : 'sequence';
  const libLabel = kind === 'row' ? 'Row from lib' : 'Seq. from lib';
  return (
    <div style={{ display: 'flex', gap: 8 }}>
      <button style={{
        flex: 1.1,
        background: 'transparent', border: `1.5px dashed ${t.brick}`, color: t.brick,
        padding: '12px', borderRadius: 14,
        fontFamily: FontBody, fontSize: 13, fontWeight: 700, cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      }}>
        <Icon name="plus" size={14} color={t.brick}/> New {label}
      </button>
      <button style={{
        flex: 1,
        background: t.card, border: `1px solid ${t.rule}`, color: t.ink,
        padding: '12px', borderRadius: 14,
        fontFamily: FontBody, fontSize: 13, fontWeight: 600, cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      }}>
        <Icon name="library" size={14} color={t.mustardDk}/>
        {libLabel}
        <span style={{
          fontFamily: FontMono, fontSize: 10, color: t.inkMute, fontWeight: 700,
          background: t.cream2, padding: '1px 6px', borderRadius: 6, letterSpacing: '0.04em',
        }}>{libraryCount}</span>
      </button>
    </div>
  );
}

// ── STEP 1 — Name project (keyboard up) ─────────────────────
// `requiredError` — render the "user tapped Next on an empty name field" state.
function SetupStep1({ dark = false, requiredError = false }) {
  const t = pickT(dark);
  const weights = ['Lace', 'Fingering', 'Sport', 'DK', 'Worsted', 'Aran', 'Bulky', 'Chunky', 'Jumbo'];
  const MAX = 60;
  const [name, setName] = React.useState(requiredError ? '' : 'The Granny Cardigan');
  const len = name.length;
  const ratio = Math.min(1, len / MAX);
  // Validation state — required-error takes precedence over the neutral 'empty' helper
  const state =
    requiredError && len === 0 ? 'required' :
    len === 0 ? 'empty' :
    len > MAX ? 'over' :
    len >= MAX - 5 ? 'near' :
    len >= 35 ? 'mid' : 'ok';
  const stateColor =
    state === 'required' || state === 'over' ? t.brick :
    state === 'near' ? t.brickDk :
    state === 'mid' ? t.mustardDk : t.forest;
  const stateMsg = {
    empty:    "Give it a name — anything will do.",
    ok:       "Looks good. Future-you will thank you.",
    mid:      "Plenty of room.",
    near:     "Getting close to the limit.",
    over:     "Whoops — too long. Trim a few.",
    required: "This one's required — give your project a name to cast on.",
  }[state];
  const isErr = state === 'required';
  return (
    <Phone dark={dark}>
      <WizardHeader step={0} total={4} label="Step 1 of 4" title="What are we making?" sub="Name it, pick your yarn and your tool — we'll remember." dark={dark}/>
      <div style={{
        flex: 1, overflow: 'auto', padding: '0 24px 160px',
      }}>
        {/* NAME */}
        <Section
          label="Name your project"
          dark={dark}
          required={isErr}
        >
          <div style={{
            background: isErr ? (dark ? 'rgba(255,122,77,0.07)' : '#FBEFEA') : t.card,
            border: `${isErr ? 2.5 : 2}px solid ${t.brick}`,
            borderRadius: 18, padding: '20px 18px',
            position: 'relative',
            boxShadow: isErr
              ? `0 0 0 4px ${dark ? 'rgba(255,122,77,0.18)' : 'rgba(156,61,46,0.12)'}`
              : 'none',
            transition: 'box-shadow 200ms ease',
          }}>
            <input
              value={name}
              onChange={(e) => setName(e.target.value.slice(0, MAX + 8))}
              maxLength={MAX + 8}
              placeholder={isErr ? 'e.g. The Granny Cardigan' : ''}
              autoFocus={isErr}
              style={{
                width: '100%', background: 'transparent', border: 'none', outline: 'none',
                fontFamily: FontDisplay, fontSize: 28, color: t.ink,
                letterSpacing: '-0.01em', padding: 0,
              }}
            />
            {isErr && (
              <div style={{
                position: 'absolute', top: 18, right: 16,
                width: 26, height: 26, borderRadius: 999,
                background: t.brick, color: '#FBF6EC',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: FontDisplay, fontSize: 17, lineHeight: 1,
                boxShadow: `0 2px 6px ${dark ? 'rgba(0,0,0,0.4)' : 'rgba(156,61,46,0.35)'}`,
              }}>!</div>
            )}
          </div>
          {/* count meter */}
          <div style={{
            marginTop: 10, display: 'flex', alignItems: 'center', gap: 10,
          }}>
            <div style={{
              flex: 1, height: 4, background: t.cream2, borderRadius: 4, overflow: 'hidden',
              position: 'relative',
            }}>
              <div style={{
                position: 'absolute', inset: 0, width: `${Math.min(100, ratio * 100)}%`,
                background: stateColor, borderRadius: 4,
                transition: 'width 200ms ease, background 200ms ease',
              }}/>
            </div>
            <div style={{
              fontFamily: FontMono, fontSize: 11, fontWeight: 700, color: stateColor,
              letterSpacing: '0.04em', minWidth: 60, textAlign: 'right',
            }}>
              {len} / {MAX}
            </div>
          </div>
          <div style={{
            marginTop: 6, fontFamily: FontMono, fontSize: 10.5,
            color: (state === 'over' || state === 'near' || state === 'required') ? stateColor : t.inkMute,
            fontWeight: state === 'required' ? 700 : 400,
            letterSpacing: '0.04em', display: 'flex', alignItems: 'center', gap: 6,
          }}>
            {(state === 'over' || state === 'near') && <Icon name="bulb" size={12} color={stateColor}/>}
            {state === 'required' && (
              <span style={{
                width: 13, height: 13, borderRadius: 999, background: t.brick, color: '#FBF6EC',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 10, fontWeight: 700, flexShrink: 0,
              }}>!</span>
            )}
            {stateMsg}
          </div>
        </Section>

        {/* TYPE */}
        <Section label="What kind?" dark={dark}>
          <div style={{ display: 'flex', gap: 10 }}>
            <Pill active label="Knit"    icon="needle" dark={dark}/>
            <Pill        label="Crochet" icon="loop"   dark={dark}/>
            <Pill        label="Both"    icon="yarn"   dark={dark}/>
          </div>
        </Section>

        {/* YARN WEIGHT */}
        <Section label="Yarn weight" dark={dark} hint="Whatever's on the label.">
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {weights.map((w, i) => {
              const active = w === 'Bulky';
              return (
                <div key={w} style={{
                  padding: '8px 12px', borderRadius: 999, fontSize: 13, fontWeight: 600,
                  background: active ? t.brick : t.card,
                  color: active ? '#FBF6EC' : t.ink,
                  border: active ? 'none' : `1px solid ${t.rule}`,
                  cursor: 'pointer',
                }}>{w}</div>
              );
            })}
          </div>
          <div style={{
            marginTop: 10, display: 'flex', alignItems: 'center', gap: 8,
            fontFamily: FontMono, fontSize: 11, color: t.inkMute,
          }}>
            <span>Fiber</span>
            <div style={{
              background: t.card, border: `1px solid ${t.rule}`, borderRadius: 10,
              padding: '6px 10px', fontFamily: FontBody, fontSize: 13, color: t.ink, fontWeight: 600,
              display: 'inline-flex', alignItems: 'center', gap: 6, cursor: 'pointer',
            }}>
              Merino wool <Icon name="chevDown" size={12} color={t.inkMute}/>
            </div>
            <span style={{ color: t.inkMute }}>· optional</span>
          </div>
        </Section>

        {/* NEEDLE / HOOK SIZE */}
        <Section label="Needle size" dark={dark} hint="Knit picked, so we're showing needles.">
          <div style={{
            background: t.card, border: `1px solid ${t.rule}`, borderRadius: 16,
            padding: 14, display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <div style={{
              width: 38, height: 38, borderRadius: 10, background: t.cream2,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Icon name="needle" size={20} color={t.brick}/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
                <div style={{ fontFamily: FontDisplay, fontSize: 28, color: t.ink, lineHeight: 1 }}>4.5</div>
                <div style={{ fontFamily: FontMono, fontSize: 12, color: t.inkSoft, fontWeight: 600 }}>mm</div>
                <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, marginLeft: 6, letterSpacing: '0.06em' }}>· US 7</div>
              </div>
              <div style={{ fontSize: 11.5, color: t.inkMute, marginTop: 2, fontFamily: FontMono }}>typical for Bulky weight</div>
            </div>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 4, background: t.bg, borderRadius: 10, padding: '4px 6px',
            }}>
              <button style={{ background: 'transparent', border: 'none', color: t.ink, fontSize: 20, cursor: 'pointer', padding: '0 8px', fontFamily: FontDisplay }}>−</button>
              <button style={{ background: 'transparent', border: 'none', color: t.ink, fontSize: 20, cursor: 'pointer', padding: '0 8px', fontFamily: FontDisplay }}>+</button>
            </div>
          </div>
          {/* needle type chips */}
          <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
            {['Straight', 'Circular', 'DPN'].map((nt, i) => {
              const active = i === 0;
              return (
                <div key={nt} style={{
                  padding: '6px 12px', borderRadius: 999, fontSize: 12, fontWeight: 600,
                  background: active ? t.mustard : t.card,
                  color: active ? '#2B1810' : t.inkSoft,
                  border: active ? 'none' : `1px solid ${t.rule}`,
                  cursor: 'pointer',
                }}>{nt}</div>
              );
            })}
          </div>
        </Section>

        {/* COLOR */}
        <Section label="Yarn color (just for vibes)" dark={dark}>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            {[t.brick, t.mustard, t.forest, '#7A5A8C', '#3B5B7A', '#C2547B', t.ink].map((c, i) => (
              <div key={c} style={{
                width: 38, height: 38, borderRadius: 12, background: c, cursor: 'pointer',
                boxShadow: i === 0 ? `0 0 0 3px ${t.bg}, 0 0 0 5px ${t.ink}` : 'none',
              }}/>
            ))}
            <div style={{
              width: 38, height: 38, borderRadius: 12, border: `1.5px dashed ${t.rule}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center', color: t.brick, cursor: 'pointer',
            }}>
              <Icon name="plus" size={16} color={t.brick}/>
            </div>
          </div>
        </Section>
      </div>
      <WizardFooter primary="Next: Parts" dark={dark} blocked={isErr} blockedMsg="Add a project name first."/>
    </Phone>
  );
}

function Section({ label, hint, dark, required, children }) {
  const t = pickT(dark);
  return (
    <div style={{ marginTop: 22 }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10, gap: 8 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
          <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, letterSpacing: '0.16em', textTransform: 'uppercase' }}>{label}</div>
          {required && (
            <div style={{
              fontFamily: FontMono, fontSize: 9.5, fontWeight: 700,
              color: '#FBF6EC', background: t.brick,
              padding: '2px 7px 2px 6px', borderRadius: 6, letterSpacing: '0.14em',
              display: 'inline-flex', alignItems: 'center', gap: 4,
            }}>
              <span style={{ fontSize: 11, lineHeight: 0.6 }}>✱</span> REQUIRED
            </div>
          )}
        </div>
        {hint && <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.04em' }}>{hint}</div>}
      </div>
      {children}
    </div>
  );
}

function Pill({ label, icon, active, dark }) {
  const t = pickT(dark);
  return (
    <div style={{
      padding: '10px 16px', borderRadius: 999,
      background: active ? t.brick : t.card,
      color: active ? '#FBF6EC' : t.ink,
      border: active ? 'none' : `1px solid ${t.rule}`,
      display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 14, fontWeight: 600, cursor: 'pointer',
    }}>
      <Icon name={icon} size={16} color={active ? '#FBF6EC' : t.brick}/>{label}
    </div>
  );
}

// ── STEP 2 — Parts ──────────────────────────────────────────
// `empty` — render the "single-piece project, no extra parts added" state.
function SetupStep2({ dark = false, empty = false }) {
  const t = pickT(dark);
  if (empty) return <SetupStep2Empty dark={dark}/>;
  const parts = [
    { name:'Body',      seq:3, rows:96, color: t.brick   },
    { name:'Sleeve 1',  seq:2, rows:64, color: t.mustard },
    { name:'Sleeve 2',  seq:2, rows:64, color: t.forest  },
  ];
  return (
    <Phone dark={dark}>
      <WizardHeader step={1} total={4} label="Step 2 of 4" title="Break it into parts." sub="A cardigan has a body and two sleeves. A scarf has one part. You decide." dark={dark}/>
      <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {parts.map((p, i) => (
          <div key={p.name} style={{
            background: t.card, border: `1px solid ${t.rule}`, borderRadius: 18,
            padding: 14, display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <div style={{ color: t.inkMute, cursor: 'grab' }}><Icon name="grip" size={20} color={t.inkMute}/></div>
            <div style={{
              width: 36, height: 36, borderRadius: 10, background: p.color, color: '#FBF6EC',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: FontDisplay, fontSize: 16,
            }}>{i + 1}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 16, color: t.ink }}>{p.name}</div>
              <div style={{ fontSize: 12, color: t.inkMute, fontFamily: FontMono, marginTop: 2 }}>{p.seq} sequences · ~{p.rows} rows</div>
            </div>
            <Icon name="edit" size={18} color={t.inkSoft}/>
          </div>
        ))}
        <button style={{
          background: 'transparent', border: `1.5px dashed ${t.rule}`, color: t.brick, padding: '14px',
          borderRadius: 18, fontFamily: FontBody, fontSize: 14, fontWeight: 600, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        }}>
          <Icon name="plus" size={16} color={t.brick}/> Add another part
        </button>

        <div style={{
          marginTop: 14, padding: '12px 14px', background: t.cream2, borderRadius: 14,
          fontSize: 12.5, color: t.inkSoft, display: 'flex', gap: 10, alignItems: 'flex-start',
        }}>
          <Icon name="bulb" size={16} color={t.mustardDk}/>
          <span><b style={{ color: t.ink }}>Tip:</b> Drag to reorder. Knit them in whatever order makes sense — YarnLog only tracks one part at a time.</span>
        </div>
      </div>
      <WizardFooter primary="Next: Sequences" dark={dark}/>
    </Phone>
  );
}

// ── STEP 2 (empty variant) — single-piece project ───────────
// Shown when the user hasn't added any extra parts. The project itself
// counts as one piece — a scarf, a dishcloth, a simple hat. We reassure
// them that one part is a perfectly valid project, and offer the add CTA.
function SetupStep2Empty({ dark = false }) {
  const t = pickT(dark);
  return (
    <Phone dark={dark}>
      <WizardHeader step={1} total={4} label="Step 2 of 4" title="Break it into parts." sub="A cardigan has a body and two sleeves. A scarf has one part. You decide." dark={dark}/>
      <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {/* Empty-state body — a hero card that explains "one part is fine". */}
        <div style={{
          background: t.cream2, border: `1.5px dashed ${t.rule}`, borderRadius: 20,
          padding: '22px 20px 20px', textAlign: 'center',
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12,
        }}>
          {/* Decorative motif: one filled tile + two ghosted tiles, suggesting "you could add more". */}
          <div style={{
            display: 'flex', gap: 8, alignItems: 'flex-end',
            padding: '4px 0 6px',
          }}>
            <div style={{
              width: 28, height: 36, borderRadius: 8, background: t.brick,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: `0 4px 10px -4px ${t.brick}`,
            }}>
              <StitchGlyph symbol="vline" color="#FBF6EC" size={16}/>
            </div>
            <div style={{
              width: 28, height: 36, borderRadius: 8,
              background: 'transparent', border: `1.5px dashed ${t.rule}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Icon name="plus" size={12} color={t.inkMute}/>
            </div>
            <div style={{
              width: 28, height: 36, borderRadius: 8,
              background: 'transparent', border: `1.5px dashed ${t.rule}`,
              opacity: 0.55,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Icon name="plus" size={12} color={t.inkMute}/>
            </div>
          </div>

          <div style={{ fontFamily: FontDisplay, fontSize: 24, color: t.brick, letterSpacing: '-0.01em', lineHeight: 1.05 }}>
            Just the one piece?
          </div>
          <div style={{ fontSize: 13.5, color: t.inkSoft, lineHeight: 1.5, maxWidth: 300 }}>
            Scarves, dishcloths, blankets, simple hats — they're a single piece, and YarnLog's happy with that. Add more parts only if your project splits into separate pieces, like sleeves, panels, or a pocket.
          </div>

          <button style={{
            marginTop: 4,
            background: 'transparent', border: `1.5px dashed ${t.brick}`, color: t.brick,
            padding: '12px 18px', borderRadius: 14,
            fontFamily: FontBody, fontSize: 14, fontWeight: 700, cursor: 'pointer',
            display: 'inline-flex', alignItems: 'center', gap: 8,
          }}>
            <Icon name="plus" size={14} color={t.brick}/> Add a part
          </button>

          <div style={{
            marginTop: 6, fontFamily: FontMono, fontSize: 10, color: t.inkMute,
            letterSpacing: '0.14em', textTransform: 'uppercase',
          }}>
            ✻ one part is a whole project ✻
          </div>
        </div>

        {/* Tip card — same vocabulary as the populated state. */}
        <div style={{
          marginTop: 4, padding: '12px 14px', background: t.card, border: `1px solid ${t.rule}`, borderRadius: 14,
          fontSize: 12.5, color: t.inkSoft, display: 'flex', gap: 10, alignItems: 'flex-start',
        }}>
          <Icon name="bulb" size={16} color={t.mustardDk}/>
          <span><b style={{ color: t.ink }}>Not sure?</b> Knit a sample first, then come back and split it if you need to. You can add parts at any time.</span>
        </div>
      </div>
      <WizardFooter primary="Next: Sequences" dark={dark}/>
    </Phone>
  );
}

// ── STEP 3 — Plan every sequence in every part on one screen ─
// Part tabs at the top swap context. Beneath them, every sequence in the
// active part is stacked vertically — each shows its own name, rows, and
// stitches. The currently-edited row (one row across all sequences) is
// what the stitch dock at the bottom targets.
function SetupStep3({ dark = false, confirmRemove = false, confirmRemoveSeq = false, marking = null }) {
  const t = pickT(dark);

  // Parts in this project. Body is the active context.
  const parts = [
    { name: 'Body',     seqCount: 3, active: true },
    { name: 'Sleeve 1', seqCount: 2 },
    { name: 'Sleeve 2', seqCount: 2 },
  ];

  // Every sequence in the active part, with its own rows.
  // The middle sequence has the currently-focused row.
  const sequences = [
    {
      num: 1, name: 'Ribbed hem', color: t.mustard,
      rows: [
        // 2×2 rib expressed as a repeat: p2, (k2, p2) to last 2 sts, p2
        { num: 1, label: 'Row 1', segments: [
          { type: 'fixed',  stitches: ['p','p'] },
          { type: 'repeat', stitches: ['k','k','p','p'], rule: { kind: 'toLast', n: 2 } },
          { type: 'fixed',  stitches: ['p','p'] },
        ] },
        { num: 2, label: 'Row 2', stitches: ['p','k','p','k','p','k','p','k','p','k'] },
      ],
    },
    {
      num: 2, name: 'Stockinette body', color: t.brick, editing: true,
      rows: [
        { num: 1, label: 'Row 1', stitches: ['k','k','k','k','k','k','k','k','k','k'] },
        { num: 2, label: 'Row 2', stitches: ['p','p','p','p','p','p','p','p','p','p'], active: true },
        { num: 3, label: 'Row 3', stitches: ['k','yo','k2tog','k','k','k','k','yo','k2tog','k'] },
        { num: 4, label: 'Row 4', stitches: [] },
      ],
    },
    {
      num: 3, name: 'Decrease shaping', color: t.forest,
      rows: [
        { num: 1, label: 'Row 1', stitches: ['k','k','k2tog','k','k','k','ssk','k','k','k'] },
        { num: 2, label: 'Row 2', stitches: ['p','p','p','p','p','p','p','p'] },
      ],
    },
  ];

  // While marking a repeat, Ribbed hem · Row 1 reverts to the one typed cycle
  // (p2 + k2 p2 + p2) and enters tap-first / tap-last mode in place. Step 'end'
  // shows the first stitch already anchored.
  if (marking) {
    sequences[0].editing = false;
    sequences[1].editing = false;
    sequences[0].rows = [
      { num: 1, label: 'Row 1', stitches: ['p','p','k','k','p','p','p','p'], mark: { step: marking, start: marking === 'end' ? 2 : null } },
    ];
  }

  const quickStitches = ['k','p','yo','k2tog','ssk','sl'];

  return (
    <Phone dark={dark}>
      <WizardHeader step={2} total={4} label="Step 3 of 4" title="Plan every sequence." sub="Pick a part, then fill each sequence's rows. Scroll through them all." dark={dark}/>
      <div style={{ flex: 1, overflow: 'auto', padding: '0 20px 220px' }}>

        {/* — Part switcher — segmented control (matches Step 4) — */}
        <div style={{
          display: 'flex', gap: 4, marginBottom: 16,
          background: t.cream2, padding: 4, borderRadius: 12,
        }}>
          {parts.map(p => {
            const active = p.active;
            return (
              <button key={p.name} style={{
                flex: 1, padding: '8px 4px', background: active ? t.card : 'transparent',
                border: 'none', borderRadius: 9, fontFamily: FontBody, fontWeight: 600,
                fontSize: 12, color: active ? t.brick : t.inkSoft, cursor: 'pointer',
                boxShadow: active ? '0 1px 3px rgba(0,0,0,0.06)' : 'none',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 5,
              }}>
                {p.name}
                <span style={{
                  fontFamily: FontMono, fontSize: 9.5, fontWeight: 700, color: t.inkMute,
                  background: active ? t.cream2 : 'transparent',
                  padding: active ? '1px 5px' : '1px 0',
                  borderRadius: 5, letterSpacing: '0.04em',
                }}>{p.seqCount}</span>
              </button>
            );
          })}
        </div>

        {/* — Stacked sequences — */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          {sequences.map(s => (
            <div key={s.num} style={{
              opacity: marking && s.num !== 1 ? 0.3 : 1,
              pointerEvents: marking && s.num !== 1 ? 'none' : 'auto',
              transition: 'opacity 160ms ease',
            }}>
              <SequenceBlock seq={s} dark={dark}/>
            </div>
          ))}
        </div>

        {/* — Add another sequence (manual or from library) — */}
        <div style={{ marginTop: 16, opacity: marking ? 0.3 : 1, pointerEvents: marking ? 'none' : 'auto' }}>
          <ReuseChooser kind="sequence" libraryCount={12} dark={dark}/>
        </div>

        <div style={{
          marginTop: 14, padding: '10px 12px', background: t.cream2, borderRadius: 12,
          fontSize: 12, color: t.inkSoft, display: 'flex', gap: 8, alignItems: 'flex-start',
          opacity: marking ? 0.3 : 1,
        }}>
          <Icon name="bulb" size={14} color={t.mustardDk}/>
          <span><b style={{ color: t.ink }}>Tip:</b> Tap any row to focus it — the stitch dock fills that row.</span>
        </div>
      </div>

      {/* Bottom zone — stitch dock normally; while marking, a step instruction */}
      {marking ? (
        <MarkInstructionBar dark={dark} step={marking}/>
      ) : (
      <div style={{
        position: 'absolute', bottom: 96, left: 0, right: 0,
        background: t.bg, borderTop: `1px solid ${t.rule}`,
        padding: '10px 20px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
          <div style={{ fontFamily: FontMono, fontSize: 10, color: t.brick, fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase' }}>Tap to add to Stockinette · Row 2 ✱</div>
          <div style={{ color: t.brick, fontSize: 11, fontFamily: FontMono, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 4 }}>
            All 30 stitches <Icon name="chevR" size={12} color={t.brick}/>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          {quickStitches.map((id, i) => {
            const s = Stitches.find(s => s.id === id);
            const c = [t.brick, t.mustard, t.forest][i % 3];
            return (
              <div key={id} style={{
                flex: 1, background: t.card, border: `1px solid ${t.rule}`, borderRadius: 10,
                padding: '6px 0', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
              }}>
                <div style={{
                  width: 28, height: 28, borderRadius: 8, background: c,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <StitchGlyph symbol={s.symbol} color="#FBF6EC" size={16}/>
                </div>
                <div style={{ fontSize: 9.5, fontFamily: FontMono, color: t.inkSoft, fontWeight: 700 }}>{s.abbr}</div>
              </div>
            );
          })}
        </div>
      </div>
      )}

      <WizardFooter primary="Next: Arrange" secondary="Back" dark={dark}/>

      {confirmRemove && <RemoveRowDialog dark={dark}/>}
      {confirmRemoveSeq && <RemoveSequenceDialog dark={dark} seq={sequences.find(s => s.editing) || sequences[1]}/>}
    </Phone>
  );
}

// Confirm dialog for removing a row from a sequence. Destructive — but the
// preview means the user always sees exactly what they're about to lose.
function RemoveRowDialog({ dark }) {
  const t = pickT(dark);
  // Sample row — matches the active "Row 2" of the Stockinette body sequence
  // on Step 3, so the dialog feels rooted in the screen behind it.
  const row = { label: 'Row 2', sequence: 'Stockinette body', stitches: ['p','p','p','p','p','p','p','p','p','p'] };

  return (
    <>
      {/* scrim — dims & blurs the underlying screen */}
      <div style={{
        position: 'absolute', inset: 0,
        background: dark ? 'rgba(0,0,0,0.62)' : 'rgba(43,24,16,0.42)',
        backdropFilter: 'blur(4px)',
        WebkitBackdropFilter: 'blur(4px)',
      }}/>

      {/* dialog — centered, with a small upward bias for thumb reach */}
      <div style={{
        position: 'absolute', left: '50%', top: '46%',
        transform: 'translate(-50%, -50%)',
        width: 320, maxWidth: 'calc(100% - 32px)',
        background: t.bg, borderRadius: 22,
        border: `1px solid ${t.rule}`,
        boxShadow: dark
          ? '0 30px 60px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,217,134,0.06)'
          : '0 30px 60px rgba(43,24,16,0.35)',
        overflow: 'hidden',
      }}>
        {/* icon header — trash on a brick disc, set against a warm tint band */}
        <div style={{
          padding: '22px 22px 14px',
          background: dark ? 'rgba(255,122,77,0.08)' : '#FBEFEA',
          borderBottom: `1px solid ${dark ? 'rgba(255,122,77,0.18)' : 'rgba(156,61,46,0.15)'}`,
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12,
        }}>
          <div style={{
            width: 56, height: 56, borderRadius: 16, background: t.brick,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: `0 10px 24px -10px ${t.brick}`,
            transform: 'rotate(-4deg)',
          }}>
            <Icon name="trash" size={26} color="#FBF6EC" stroke={2.2}/>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{
              fontFamily: FontDisplay, fontSize: 24, color: t.brick,
              letterSpacing: '-0.01em', lineHeight: 1.05,
            }}>
              Remove this row?
            </div>
            <div style={{
              fontFamily: FontMono, fontSize: 10.5, color: t.inkMute,
              letterSpacing: '0.14em', textTransform: 'uppercase', marginTop: 6,
            }}>
              No undo · 10 stitches lost
            </div>
          </div>
        </div>

        {/* row preview — exactly what's being deleted */}
        <div style={{ padding: '14px 20px 4px' }}>
          <div style={{
            background: t.card, border: `1px solid ${t.rule}`, borderRadius: 12,
            padding: '10px 12px',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <span style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 13, color: t.ink }}>{row.label}</span>
              <span style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute }}>· {row.stitches.length} sts</span>
              <span style={{ flex: 1 }}/>
              <span style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.06em' }}>{row.sequence}</span>
            </div>
            <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
              {row.stitches.map((id, i) => {
                const s = Stitches.find(s => s.id === id);
                const c = ['k','sl','kfb','m1'].includes(id) ? t.brick : ['p','p2tog','mb'].includes(id) ? t.mustard : t.forest;
                return (
                  <div key={i} style={{
                    width: 22, height: 26, borderRadius: 6, background: t.cream2,
                    border: `1.2px solid ${c}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
                    opacity: 0.7,
                  }}>
                    <StitchGlyph symbol={s.symbol} color={c} size={12} stroke={1.8}/>
                  </div>
                );
              })}
            </div>
          </div>
          <div style={{
            marginTop: 10, fontSize: 13, color: t.inkSoft, lineHeight: 1.45,
            textAlign: 'center', padding: '0 4px',
          }}>
            The row above and below will shift up — neighboring rows aren't affected.
          </div>
        </div>

        {/* buttons — destructive primary on the right, ghost cancel on the left.
            Stacked vertical to give the destructive action its own line and
            keep tap targets ≥44px. */}
        <div style={{ padding: '16px 20px 20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <button style={{
            height: 48, borderRadius: 14, border: 'none', cursor: 'pointer',
            background: t.brick, color: '#FBF6EC',
            fontFamily: FontBody, fontWeight: 700, fontSize: 15, letterSpacing: '-0.005em',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            boxShadow: `0 8px 18px -10px ${t.brick}`,
          }}>
            <Icon name="trash" size={16} color="#FBF6EC"/>
            Yes, remove row
          </button>
          <button style={{
            height: 44, borderRadius: 12, cursor: 'pointer',
            background: 'transparent', color: t.ink,
            border: `1.5px solid ${t.rule}`,
            fontFamily: FontBody, fontWeight: 600, fontSize: 14.5, letterSpacing: '-0.005em',
          }}>
            Keep it
          </button>
        </div>
      </div>
    </>
  );
}

// Confirm dialog for removing an ENTIRE sequence (and every row inside it).
// Mirrors RemoveRowDialog's structure & vocabulary, but scaled up: the header
// counts how much is lost (rows + total stitches), and the preview stacks a
// mini view of every row so the user sees the whole block they're nuking.
function RemoveSequenceDialog({ dark, seq }) {
  const t = pickT(dark);
  const s = seq || {
    num: 2, name: 'Stockinette body', color: '#9C3D2E',
    rows: [
      { num: 1, label: 'Row 1', stitches: ['k','k','k','k','k','k','k','k','k','k'] },
      { num: 2, label: 'Row 2', stitches: ['p','p','p','p','p','p','p','p','p','p'] },
      { num: 3, label: 'Row 3', stitches: ['k','yo','k2tog','k','k','k','k','yo','k2tog','k'] },
      { num: 4, label: 'Row 4', stitches: [] },
    ],
  };
  const rowCount = s.rows.length;
  const totalSts = s.rows.reduce((a, r) => a + r.stitches.length, 0);

  return (
    <>
      {/* scrim — dims & blurs the underlying screen */}
      <div style={{
        position: 'absolute', inset: 0,
        background: dark ? 'rgba(0,0,0,0.62)' : 'rgba(43,24,16,0.42)',
        backdropFilter: 'blur(4px)',
        WebkitBackdropFilter: 'blur(4px)',
      }}/>

      {/* dialog — centered, with a small upward bias for thumb reach */}
      <div style={{
        position: 'absolute', left: '50%', top: '46%',
        transform: 'translate(-50%, -50%)',
        width: 320, maxWidth: 'calc(100% - 32px)',
        background: t.bg, borderRadius: 22,
        border: `1px solid ${t.rule}`,
        boxShadow: dark
          ? '0 30px 60px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,217,134,0.06)'
          : '0 30px 60px rgba(43,24,16,0.35)',
        overflow: 'hidden',
      }}>
        {/* icon header — trash on a brick disc, set against a warm tint band */}
        <div style={{
          padding: '22px 22px 14px',
          background: dark ? 'rgba(255,122,77,0.08)' : '#FBEFEA',
          borderBottom: `1px solid ${dark ? 'rgba(255,122,77,0.18)' : 'rgba(156,61,46,0.15)'}`,
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12,
        }}>
          <div style={{
            width: 56, height: 56, borderRadius: 16, background: t.brick,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: `0 10px 24px -10px ${t.brick}`,
            transform: 'rotate(-4deg)',
          }}>
            <Icon name="trash" size={26} color="#FBF6EC" stroke={2.2}/>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{
              fontFamily: FontDisplay, fontSize: 24, color: t.brick,
              letterSpacing: '-0.01em', lineHeight: 1.05,
            }}>
              Delete this whole sequence?
            </div>
            <div style={{
              fontFamily: FontMono, fontSize: 10.5, color: t.inkMute,
              letterSpacing: '0.14em', textTransform: 'uppercase', marginTop: 6,
            }}>
              No undo · {rowCount} rows · {totalSts} stitches lost
            </div>
          </div>
        </div>

        {/* sequence preview — the named block + a mini view of every row */}
        <div style={{ padding: '14px 20px 4px' }}>
          <div style={{
            background: t.card, border: `1px solid ${t.rule}`, borderRadius: 12,
            padding: '10px 12px',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
              <div style={{
                width: 24, height: 24, borderRadius: 7, background: s.color, color: '#FBF6EC',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: FontDisplay, fontSize: 13, flexShrink: 0,
              }}>{s.num}</div>
              <span style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 13.5, color: t.ink, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.name}</span>
              <span style={{ flex: 1 }}/>
              <span style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, letterSpacing: '0.04em', flexShrink: 0 }}>{rowCount} rows</span>
            </div>
            {/* every row, stacked & dimmed — the full block being lost */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
              {s.rows.map((row, ri) => (
                <div key={ri} style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                  <span style={{ fontFamily: FontMono, fontSize: 9, color: t.inkMute, fontWeight: 700, width: 30, flexShrink: 0 }}>{row.label.replace('Row ', 'R')}</span>
                  {row.stitches.length ? (
                    <div style={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                      {row.stitches.map((id, i) => {
                        const st = Stitches.find(x => x.id === id);
                        const c = ['k','sl','kfb','m1'].includes(id) ? t.brick : ['p','p2tog','mb'].includes(id) ? t.mustard : t.forest;
                        return (
                          <div key={i} style={{
                            width: 14, height: 17, borderRadius: 4, background: t.cream2,
                            border: `1px solid ${c}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
                            opacity: 0.7,
                          }}>
                            <StitchGlyph symbol={st.symbol} color={c} size={8} stroke={1.6}/>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <span style={{ fontFamily: FontMono, fontSize: 9.5, color: t.inkMute, fontStyle: 'italic' }}>empty</span>
                  )}
                </div>
              ))}
            </div>
          </div>
          <div style={{
            marginTop: 10, fontSize: 13, color: t.inkSoft, lineHeight: 1.45,
            textAlign: 'center', padding: '0 4px',
          }}>
            Every row inside moves with it. Other sequences in this part shift up — they aren't affected.
          </div>
        </div>

        {/* buttons — destructive primary, ghost cancel below it */}
        <div style={{ padding: '16px 20px 20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <button style={{
            height: 48, borderRadius: 14, border: 'none', cursor: 'pointer',
            background: t.brick, color: '#FBF6EC',
            fontFamily: FontBody, fontWeight: 700, fontSize: 15, letterSpacing: '-0.005em',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            boxShadow: `0 8px 18px -10px ${t.brick}`,
          }}>
            <Icon name="trash" size={16} color="#FBF6EC"/>
            Yes, delete sequence
          </button>
          <button style={{
            height: 44, borderRadius: 12, cursor: 'pointer',
            background: 'transparent', color: t.ink,
            border: `1.5px solid ${t.rule}`,
            fontFamily: FontBody, fontWeight: 600, fontSize: 14.5, letterSpacing: '-0.005em',
          }}>
            Keep it
          </button>
        </div>
      </div>
    </>
  );
}

// One full sequence block — header (number tile + name) and its rows.
// The `editing` flag thickens the border and renders the name with a
// caret to telegraph that this is the sequence currently being edited.
function SequenceBlock({ seq, dark }) {
  const t = pickT(dark);
  const editing = !!seq.editing;
  const totalSts = seq.rows.reduce((a, r) => a + (r.stitches ? r.stitches.length : 0), 0);
  const hasRepeat = seq.rows.some(r => r.segments);
  return (
    <div>
      {/* — Sequence header — */}
      <div style={{
        background: t.card,
        border: editing ? `2px solid ${t.brick}` : `1px solid ${t.rule}`,
        borderRadius: 16, padding: '12px 14px',
        display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8,
        boxShadow: editing ? `0 0 0 4px ${dark ? 'rgba(255,122,77,0.10)' : 'rgba(156,61,46,0.07)'}` : 'none',
      }}>
        <div style={{
          width: 32, height: 32, borderRadius: 9, background: seq.color, color: '#FBF6EC',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: FontDisplay, fontSize: 16, flexShrink: 0,
          boxShadow: `0 4px 10px -4px ${seq.color}`,
        }}>{seq.num}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontFamily: FontDisplay, fontSize: 20, color: editing ? t.ink : t.ink,
            letterSpacing: '-0.01em', lineHeight: 1.1,
            display: 'inline-flex', alignItems: 'center',
          }}>
            {seq.name}
            {editing && <span style={{ display: 'inline-block', width: 2, height: 18, background: t.brick, marginLeft: 3, transform: 'translateY(1px)' }}/>}
          </div>
          <div style={{ fontFamily: FontMono, fontSize: 10.5, color: t.inkMute, marginTop: 3, letterSpacing: '0.04em' }}>
            {seq.rows.length} rows · {totalSts}{hasRepeat ? '+' : ''} sts{hasRepeat ? ' · has repeat' : ''}
            {editing && <span style={{ color: t.brick, fontWeight: 700, marginLeft: 6 }}>· editing ✱</span>}
          </div>
        </div>
        {/* Editing → title is being edited inline (caret in name); show a
            destructive "delete whole sequence" control instead of the pencil,
            so the user can nuke the entire block while they're in it.
            Non-editing → show pencil (to start editing) + chevron. */}
        {editing ? (
          <button style={{
            flexShrink: 0, display: 'inline-flex', alignItems: 'center', gap: 5,
            background: dark ? 'rgba(255,122,77,0.12)' : '#FBEFEA',
            border: `1px solid ${dark ? 'rgba(255,122,77,0.32)' : 'rgba(156,61,46,0.22)'}`,
            color: t.brick, borderRadius: 9, padding: '6px 9px', cursor: 'pointer',
            fontFamily: FontMono, fontSize: 9.5, fontWeight: 700,
            letterSpacing: '0.08em', textTransform: 'uppercase',
          }}>
            <Icon name="trash" size={13} color={t.brick} stroke={2}/>
            Delete
          </button>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 }}>
            <Icon name="edit"     size={16} color={t.inkSoft}/>
            <Icon name="chevDown" size={16} color={t.inkSoft}/>
          </div>
        )}
      </div>

      {/* — Rows in this sequence — */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingLeft: 10, borderLeft: `2px solid ${t.cream2}`, marginLeft: 6 }}>
        {seq.rows.map(row => <RowEditCard key={row.num} row={row} dark={dark}/>)}

        {/* Row can be added manually or pulled from the saved library —
            uses the same ReuseChooser as the sequence-level pair below,
            for a consistent visual language. */}
        <div style={{ marginTop: 2 }}>
          <ReuseChooser kind="row" libraryCount={28} dark={dark}/>
        </div>
      </div>
    </div>
  );
}

function RowEditCard({ row, dark }) {
  const t = pickT(dark);
  // Rows that carry `segments` are repeating rows — defer to the repeat
  // renderer (brackets + rule badge + written notation). See screens-repeat.jsx.
  if (row.segments) return <RepeatRowCard row={row} dark={dark}/>;
  // Rows with a `mark` flag are mid-marking — tap first stitch, then last.
  if (row.mark) return <MarkRowCard row={row} dark={dark}/>;
  const empty = row.stitches.length === 0;
  return (
    <div style={{
      background: t.card,
      border: row.active ? `2px solid ${t.brick}` : `1px solid ${t.rule}`,
      borderRadius: 14, padding: '10px 12px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: empty ? 0 : 10, gap: 8 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
          <Icon name="grip" size={14} color={t.inkMute}/>
          <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 13, color: row.active ? t.brick : t.ink, whiteSpace: 'nowrap' }}>{row.label}{row.active && ' ✱'}</div>
          <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, whiteSpace: 'nowrap' }}>· {row.stitches.length} sts</div>
        </div>
        <RowToolbar dark={dark}/>
      </div>
      {!empty ? (
        <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
          {row.stitches.map((id, i) => {
            const s = Stitches.find(s => s.id === id);
            const c = ['k','sl','kfb','m1'].includes(id) ? t.brick : ['p','p2tog','mb'].includes(id) ? t.mustard : t.forest;
            return (
              <div key={i} style={{
                width: 26, height: 36, borderRadius: 6, background: t.cream2,
                border: `1.2px solid ${c}`,
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                gap: 1, paddingTop: 2, paddingBottom: 2,
              }}>
                <StitchGlyph symbol={s.symbol} color={c} size={13} stroke={1.8}/>
                <div style={{
                  fontFamily: FontMono, fontSize: 7.5, color: c, fontWeight: 700,
                  lineHeight: 1, letterSpacing: '-0.02em', maxWidth: '100%',
                  overflow: 'hidden', textOverflow: 'clip',
                }}>{s.abbr}</div>
              </div>
            );
          })}
        </div>
      ) : (
        <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, fontStyle: 'italic', padding: '6px 0 2px' }}>
          empty · tap a stitch below to start filling
        </div>
      )}
    </div>
  );
}

function Toggle({ on, dark }) {
  const t = pickT(dark);
  return (
    <div style={{
      width: 46, height: 28, borderRadius: 14, background: on ? t.forest : t.cream2,
      position: 'relative', transition: 'background 200ms ease', cursor: 'pointer',
    }}>
      <div style={{
        position: 'absolute', top: 2, left: on ? 20 : 2, width: 24, height: 24,
        borderRadius: 12, background: '#FBF6EC',
        boxShadow: '0 1px 3px rgba(0,0,0,0.15)', transition: 'left 200ms ease',
      }}/>
    </div>
  );
}

// ── STEP 4 — Arrange sequences (order + repeats + loop) ────
function SetupStep4({ dark = false }) {
  const t = pickT(dark);
  const sequences = [
    { num: 1, name: 'Ribbed hem',       rows: 8,  repeat: 1, color: t.mustard, preview: ['k','p','k','p','k','p'] },
    { num: 2, name: 'Stockinette body', rows: 4,  repeat: 6, color: t.brick,   preview: ['k','k','k','p','p','p'] },
    { num: 3, name: 'Decrease shaping', rows: 12, repeat: 1, color: t.forest,  preview: ['k2tog','k','k','ssk','k','yo'] },
  ];
  const totalRows = sequences.reduce((s, x) => s + x.rows * x.repeat, 0);
  return (
    <Phone dark={dark}>
      <WizardHeader step={3} total={4} label="Step 4 of 4" title="Arrange the part." sub="Drag to order. Set repeats. Loop if it tubes." dark={dark}/>
      <div style={{ flex: 1, overflow: 'auto', padding: '0 20px 130px' }}>
        {/* Part switcher */}
        <div style={{
          display: 'flex', gap: 4, marginBottom: 14, background: t.cream2, padding: 4, borderRadius: 12,
        }}>
          {['Body','Sleeve 1','Sleeve 2'].map((p, i) => {
            const active = i === 0;
            return (
              <button key={p} style={{
                flex: 1, padding: '8px 4px', background: active ? t.card : 'transparent',
                border: 'none', borderRadius: 9, fontFamily: FontBody, fontWeight: 600,
                fontSize: 12, color: active ? t.brick : t.inkSoft, cursor: 'pointer',
                boxShadow: active ? '0 1px 3px rgba(0,0,0,0.06)' : 'none',
              }}>{p}</button>
            );
          })}
        </div>

        <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, letterSpacing: '0.16em', textTransform: 'uppercase', marginBottom: 8 }}>Body · sequences in order</div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {sequences.map(s => <ArrangeSeqCard key={s.num} seq={s} dark={dark}/>)}
        </div>

        <div style={{ marginTop: 10 }}>
          <ReuseChooser kind="sequence" libraryCount={12} dark={dark}/>
        </div>

        {/* Loop toggle */}
        <div style={{
          marginTop: 14, background: t.card, border: `1px solid ${t.rule}`, borderRadius: 16,
          padding: 14, display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10, background: t.cream2,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Icon name="repeat" size={18} color={t.brick}/>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 14.5, color: t.ink }}>Loop the whole part?</div>
            <div style={{ fontSize: 12, color: t.inkMute, marginTop: 2 }}>After the last sequence, cycle back to #1. Great for tubes & socks.</div>
          </div>
          <Toggle on={false} dark={dark}/>
        </div>

        {/* Summary tally */}
        <div style={{
          marginTop: 14, padding: 16, borderRadius: 18,
          background: `linear-gradient(180deg, ${t.brick} 0%, ${t.brickDk} 100%)`,
          color: '#FBF6EC', boxShadow: `0 10px 24px -10px ${t.brick}`,
        }}>
          <div style={{ fontFamily: FontMono, fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase', opacity: 0.7 }}>Body · final tally</div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 4 }}>
            <div style={{ fontFamily: FontDisplay, fontSize: 40, lineHeight: 1 }}>{totalRows}</div>
            <div style={{ fontSize: 13, opacity: 0.9 }}>rows total</div>
          </div>
          <div style={{ fontSize: 12, marginTop: 6, opacity: 0.85, fontFamily: FontMono }}>8 hem · 4×6 body · 12 decreases</div>
        </div>
      </div>
      <WizardFooter primary="Cast on!" secondary="Back" dark={dark}/>
    </Phone>
  );
}

function ArrangeSeqCard({ seq, dark }) {
  const t = pickT(dark);
  return (
    <div style={{
      background: t.card, border: `1px solid ${t.rule}`, borderRadius: 16, padding: 12,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ color: t.inkMute, cursor: 'grab' }}><Icon name="grip" size={18} color={t.inkMute}/></div>
        <div style={{
          width: 30, height: 30, borderRadius: 8, background: seq.color, color: '#FBF6EC',
          display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: FontDisplay, fontSize: 14,
        }}>{seq.num}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 14.5, color: t.ink, letterSpacing: '-0.005em' }}>{seq.name}</div>
          <div style={{ fontSize: 11.5, color: t.inkMute, fontFamily: FontMono, marginTop: 1 }}>{seq.rows} rows × {seq.repeat} = {seq.rows * seq.repeat} total</div>
        </div>
        <Icon name="edit" size={16} color={t.inkSoft}/>
      </div>

      {/* stitch preview row */}
      <div style={{ display: 'flex', gap: 3, marginTop: 10, flexWrap: 'wrap' }}>
        {seq.preview.map((id, i) => {
          const s = Stitches.find(s => s.id === id);
          if (!s) return null;
          return (
            <div key={i} style={{
              width: 18, height: 22, borderRadius: 5, background: t.cream2,
              border: `1.1px solid ${seq.color}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <StitchGlyph symbol={s.symbol} color={seq.color} size={10} stroke={1.6}/>
            </div>
          );
        })}
        <div style={{
          height: 22, padding: '0 6px', display: 'flex', alignItems: 'center',
          color: t.inkMute, fontFamily: FontMono, fontSize: 10, whiteSpace: 'nowrap',
        }}>+ {seq.rows - 1} more rows</div>
      </div>

      {/* repeat stepper */}
      <div style={{
        marginTop: 10, padding: '6px 10px', background: t.cream2, borderRadius: 10,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: t.inkSoft, fontSize: 12 }}>
          <Icon name="repeat" size={13} color={t.mustardDk}/> Repeat ×
        </div>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 6, background: t.bg, borderRadius: 8, padding: '3px 4px',
        }}>
          <button style={{ background: 'transparent', border: 'none', color: t.ink, fontSize: 18, cursor: 'pointer', padding: '0 8px', fontFamily: FontDisplay }}>−</button>
          <div style={{ fontFamily: FontMono, fontWeight: 700, fontSize: 13, color: t.ink, minWidth: 26, textAlign: 'center' }}>{seq.repeat}</div>
          <button style={{ background: 'transparent', border: 'none', color: t.ink, fontSize: 18, cursor: 'pointer', padding: '0 8px', fontFamily: FontDisplay }}>+</button>
        </div>
      </div>
    </div>
  );
}

// ── STEP 2 (add/edit part sheet) ────────────────────────────
// Modal bottom-sheet that appears when the user taps "Add a part" or the
// edit pencil on an existing part. The Step 2 list sits dimmed behind it so
// the user keeps context for where the new/edited part will land.
//
// `mode` = 'add' | 'edit'
//   add  → empty name input (autofocus indicator + placeholder), next free
//          color/number slot, no destructive action
//   edit → pre-filled "Body" data, destructive "Remove part" option pinned
//          to the bottom of the sheet
function SetupStep2PartSheet({ dark = false, mode = 'add' }) {
  const t = pickT(dark);
  const isEdit = mode === 'edit';

  // Color swatches the user can stamp onto the part. We surface the warm-folk
  // accents — same palette as the part rows on Step 2 — plus two neutrals.
  const colorOptions = [
    { id: 'brick',   c: t.brick   },
    { id: 'mustard', c: t.mustard },
    { id: 'forest',  c: t.forest  },
    { id: 'plum',    c: '#7A5A8C' },
    { id: 'slate',   c: '#3B5B7A' },
    { id: 'rose',    c: '#C2547B' },
  ];
  // For add → pick the next free slot (mustard, since Body=brick).
  // For edit → "Body" is brick.
  const activeColor = isEdit ? 'brick' : 'mustard';
  const slotNumber  = isEdit ? 1 : 4;
  const nameValue   = isEdit ? 'Body' : '';

  // We render the same Step 2 (populated) screen behind the sheet so the
  // user sees exactly where this part will land. Dimmed via overlay.
  return (
    <Phone dark={dark}>
      {/* — Backdrop: dimmed Step 2 list — */}
      <WizardHeader step={1} total={4} label="Step 2 of 4" title="Break it into parts." sub="A cardigan has a body and two sleeves. A scarf has one part. You decide." dark={dark}/>
      <div style={{ padding: '0 20px', display: 'flex', flexDirection: 'column', gap: 10, opacity: 0.45, pointerEvents: 'none' }}>
        {[
          { name:'Body',     seq:3, rows:96, color: t.brick   },
          { name:'Sleeve 1', seq:2, rows:64, color: t.mustard },
          { name:'Sleeve 2', seq:2, rows:64, color: t.forest  },
        ].map((p, i) => (
          <div key={p.name} style={{
            background: t.card, border: `1px solid ${t.rule}`, borderRadius: 18,
            padding: 14, display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <div style={{ color: t.inkMute }}><Icon name="grip" size={20} color={t.inkMute}/></div>
            <div style={{
              width: 36, height: 36, borderRadius: 10, background: p.color, color: '#FBF6EC',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: FontDisplay, fontSize: 16,
            }}>{i + 1}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 16, color: t.ink }}>{p.name}</div>
              <div style={{ fontSize: 12, color: t.inkMute, fontFamily: FontMono, marginTop: 2 }}>{p.seq} sequences · ~{p.rows} rows</div>
            </div>
          </div>
        ))}
      </div>

      {/* — Scrim — */}
      <div style={{
        position: 'absolute', inset: 0,
        background: dark ? 'rgba(0,0,0,0.55)' : 'rgba(43,24,16,0.32)',
        backdropFilter: 'blur(2px)', WebkitBackdropFilter: 'blur(2px)',
      }}/>

      {/* — Bottom sheet — */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        background: t.bg,
        borderTopLeftRadius: 24, borderTopRightRadius: 24,
        boxShadow: dark
          ? '0 -20px 60px rgba(0,0,0,0.6), 0 -2px 0 rgba(255,217,134,0.06) inset'
          : '0 -20px 60px -10px rgba(43,24,16,0.35), 0 -1px 0 rgba(43,24,16,0.06) inset',
        padding: '10px 0 24px',
        display: 'flex', flexDirection: 'column',
        maxHeight: '78%',
      }}>
        {/* Drag handle */}
        <div style={{
          width: 44, height: 5, borderRadius: 3, background: t.rule,
          margin: '0 auto 12px',
        }}/>

        {/* Sheet header */}
        <div style={{ padding: '0 22px', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div style={{
              fontFamily: FontMono, fontSize: 10.5, letterSpacing: '0.16em', textTransform: 'uppercase',
              color: t.mustardDk,
            }}>
              {isEdit ? 'Editing part 1 of 3' : 'New part · slot 4'}
            </div>
            <div style={{
              fontFamily: FontDisplay, fontSize: 26, color: t.brick, letterSpacing: '-0.01em',
              lineHeight: 1.05, marginTop: 4,
            }}>
              {isEdit ? 'Edit the Body' : 'Add a part'}
            </div>
          </div>
          <div style={{
            width: 34, height: 34, borderRadius: 17,
            background: t.card, border: `1px solid ${t.rule}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0, cursor: 'pointer',
          }}>
            <Icon name="x" size={16} color={t.ink}/>
          </div>
        </div>

        {/* Scrollable body */}
        <div style={{ flex: 1, overflow: 'auto', padding: '18px 22px 14px' }}>
          {/* — Identity row: numbered tile preview + name input — */}
          <div style={{
            display: 'flex', gap: 12, alignItems: 'stretch',
            marginBottom: 18,
          }}>
            {/* Number tile preview (mirrors how it appears in the list) */}
            <div style={{
              width: 64, flexShrink: 0,
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
            }}>
              <div style={{
                width: 56, height: 64, borderRadius: 14,
                background: colorOptions.find(co => co.id === activeColor).c,
                color: '#FBF6EC',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: FontDisplay, fontSize: 28,
                boxShadow: `0 6px 14px -4px ${colorOptions.find(co => co.id === activeColor).c}`,
              }}>
                {slotNumber}
              </div>
              <div style={{
                fontFamily: FontMono, fontSize: 9.5, letterSpacing: '0.12em',
                textTransform: 'uppercase', color: t.inkMute,
              }}>
                Preview
              </div>
            </div>

            {/* Name input */}
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{
                fontFamily: FontMono, fontSize: 10.5, letterSpacing: '0.16em',
                textTransform: 'uppercase', color: t.inkMute, marginBottom: 6,
              }}>
                Part name
              </div>
              <div style={{
                background: t.card, border: `2px solid ${t.brick}`, borderRadius: 14,
                padding: '12px 14px', display: 'flex', alignItems: 'center', minHeight: 44,
                boxShadow: !isEdit ? `0 0 0 4px ${dark ? 'rgba(255,122,77,0.10)' : 'rgba(156,61,46,0.08)'}` : 'none',
              }}>
                {isEdit ? (
                  <span style={{ fontFamily: FontDisplay, fontSize: 22, color: t.ink, letterSpacing: '-0.01em' }}>
                    {nameValue}
                    <span style={{ display: 'inline-block', width: 2, height: 20, background: t.brick, marginLeft: 3, transform: 'translateY(3px)' }}/>
                  </span>
                ) : (
                  <span style={{
                    fontFamily: FontDisplay, fontSize: 22, color: t.inkMute, fontStyle: 'italic',
                    letterSpacing: '-0.005em', display: 'inline-flex', alignItems: 'center', gap: 4,
                  }}>
                    <span style={{ display: 'inline-block', width: 2, height: 22, background: t.brick, transform: 'translateY(2px)' }}/>
                    e.g. Left sleeve
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* — Color swatches — */}
          <Section label="Tile color" dark={dark}>
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              {colorOptions.map(co => {
                const active = co.id === activeColor;
                return (
                  <div key={co.id} style={{
                    width: 42, height: 42, borderRadius: 12, background: co.c, cursor: 'pointer',
                    boxShadow: active ? `0 0 0 3px ${t.bg}, 0 0 0 5px ${t.ink}` : 'none',
                  }}/>
                );
              })}
            </div>
          </Section>

          {/* — Notes — */}
          <Section label="Notes" dark={dark} hint="optional · just for you">
            <div style={{
              background: t.card, border: `1px solid ${t.rule}`, borderRadius: 14,
              padding: '12px 14px', minHeight: 64,
              fontFamily: FontBody, fontSize: 13.5,
              color: isEdit ? t.inkSoft : t.inkMute, lineHeight: 1.45, fontStyle: isEdit ? 'normal' : 'italic',
            }}>
              {isEdit
                ? 'Bottom-up. Switch to circular needles at row 40 once the cast-on stretches.'
                : 'e.g. "knit in the round, switch to DPN at decreases"'}
            </div>
          </Section>

          {/* — Destructive remove (edit mode only) — */}
          {isEdit && (
            <div style={{ marginTop: 22, paddingTop: 18, borderTop: `1px dashed ${t.rule}` }}>
              <button style={{
                width: '100%',
                background: 'transparent', border: `1.5px solid ${t.brick}`,
                color: t.brick, padding: '12px 14px', borderRadius: 14,
                fontFamily: FontBody, fontSize: 14, fontWeight: 700, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              }}>
                <Icon name="trash" size={16} color={t.brick}/> Remove this part
              </button>
              <div style={{
                marginTop: 8, textAlign: 'center',
                fontFamily: FontMono, fontSize: 10, color: t.inkMute,
                letterSpacing: '0.04em',
              }}>
                Its 3 sequences will stay in your Library.
              </div>
            </div>
          )}
        </div>

        {/* Sticky action footer */}
        <div style={{
          padding: '12px 22px 0',
          borderTop: `1px solid ${t.rule}`,
          background: t.bg,
          display: 'flex', gap: 10,
        }}>
          <Btn variant="ghost" size="lg" dark={dark}>Cancel</Btn>
          <Btn
            variant="primary" size="lg" dark={dark}
            icon={isEdit ? 'check' : 'plus'}
            style={{ flex: 1 }}
          >
            {isEdit ? 'Save changes' : 'Add part'}
          </Btn>
        </div>
      </div>
    </Phone>
  );
}

Object.assign(window, { SetupStep1, SetupStep2, SetupStep2PartSheet, SetupStep3, SetupStep4 });
