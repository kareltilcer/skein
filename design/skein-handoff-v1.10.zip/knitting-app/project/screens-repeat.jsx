// ── REPEATS — one repeating group per row, marked in place ───
// Knitting patterns say things like "p2, (k2, p2) to last 2 sts, p2".
// A row can carry `segments` instead of a flat stitch list:
//
//   { type:'fixed',  stitches:['p','p'] }              ← worked once (setup edge)
//   { type:'repeat', stitches:['k','k','p','p'] }      ← THE repeat (only one per row)
//   { type:'fixed',  stitches:['p','p'] }              ← worked once (final edge)
//
// There is no separate "how many times" question: the user types one cycle
// plus whatever edge stitches frame it, then marks the first & last stitch of
// the cycle. The trailing fixed stitches ARE the "to last N sts" — so the rule
// is DERIVED, never chosen. rule is kept only for rendering the badge/notation:
//   { kind:'toLast', n }  → "to last N sts"   (there are N fixed sts after)
//   { kind:'toEnd' }      → "to end"          (nothing after the repeat)

// Stitch → accent colour (mirrors the rule used elsewhere in setup).
function stitchHue(t, id) {
  return ['k','sl','kfb','m1'].includes(id) ? t.brick
       : ['p','p2tog','mb'].includes(id) ? t.mustard
       : t.forest;
}

// ── A single stitch tile ─────────────────────────────────────
// state: 'normal' | 'dim' | 'inrepeat' | 'start' | 'end' | 'tap'
function StitchTile({ id, dark, state = 'normal', w = 28, h = 40 }) {
  const t = pickT(dark);
  const s = Stitches.find(x => x.id === id) || { symbol: 'dot', abbr: id };
  const c = stitchHue(t, id);
  const anchor = state === 'start' || state === 'end';
  const inRep = state === 'inrepeat' || anchor;
  return (
    <div style={{ position: 'relative', flexShrink: 0 }}>
      {anchor && (
        <div style={{
          position: 'absolute', top: -15, left: '50%', transform: 'translateX(-50%)',
          fontFamily: FontMono, fontSize: 7.5, fontWeight: 700, letterSpacing: '0.1em',
          color: '#FBF6EC', background: t.brick, padding: '1px 5px', borderRadius: 5,
          whiteSpace: 'nowrap', boxShadow: `0 3px 7px -3px ${t.brick}`, zIndex: 2,
        }}>{state === 'start' ? 'START' : 'END'}</div>
      )}
      <div style={{
        width: w, height: h, borderRadius: 7,
        background: inRep ? (dark ? 'rgba(255,122,77,0.16)' : 'rgba(156,61,46,0.09)') : t.cream2,
        border: anchor ? `2px solid ${t.brick}` : inRep ? `1.5px solid ${t.brick}` : `1.2px solid ${c}`,
        opacity: state === 'dim' ? 0.34 : 1,
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        gap: 1, paddingTop: 2, paddingBottom: 2, boxSizing: 'border-box',
        transition: 'all 140ms ease',
        boxShadow: state === 'tap' ? `0 0 0 3px ${dark ? 'rgba(255,194,95,0.22)' : 'rgba(212,146,59,0.22)'}` : 'none',
      }}>
        <StitchGlyph symbol={s.symbol} color={c} size={Math.round(h * 0.34)} stroke={1.9}/>
        <div style={{ fontFamily: FontMono, fontSize: 8, color: c, fontWeight: 700, lineHeight: 1, letterSpacing: '-0.02em' }}>{s.abbr}</div>
      </div>
    </div>
  );
}

// ── Repeat bracket — a tall square bracket framing the group ──
function RepeatBracket({ side, dark, h = 40 }) {
  const t = pickT(dark);
  const edge = `2.5px solid ${t.brick}`;
  return (
    <div style={{
      width: 8, height: h + 4, flexShrink: 0,
      borderTop: edge, borderBottom: edge,
      borderLeft:  side === 'open'  ? edge : 'none',
      borderRight: side === 'close' ? edge : 'none',
      borderTopLeftRadius:    side === 'open'  ? 5 : 0,
      borderBottomLeftRadius: side === 'open'  ? 5 : 0,
      borderTopRightRadius:    side === 'close' ? 5 : 0,
      borderBottomRightRadius: side === 'close' ? 5 : 0,
    }}/>
  );
}

// ── Repeat-rule → short badge text & long written text ───────
function ruleBadge(rule) {
  if (!rule || rule.kind === 'toEnd') return 'to end';
  return `to last ${rule.n}`;
}
function ruleLong(rule) {
  if (!rule || rule.kind === 'toEnd') return 'to end of row';
  return `to last ${rule.n} st${rule.n === 1 ? '' : 's'}`;
}

// Collapse a run of identical stitches → written shorthand ("k2", "p", …)
function collapseRun(ids) {
  const out = []; let i = 0;
  while (i < ids.length) {
    let j = i; while (j < ids.length && ids[j] === ids[i]) j++;
    const n = j - i;
    const ab = (Stitches.find(s => s.id === ids[i]) || {}).abbr || ids[i];
    out.push(n > 1 ? `${ab}${n}` : ab);
    i = j;
  }
  return out.join(', ');
}

// Written-pattern notation, with the parentheses + rule tinted (the cue for
// where the repeat starts & stops).
function RowNotation({ segments, dark }) {
  const t = pickT(dark);
  const parts = [];
  segments.forEach((seg, i) => {
    if (i > 0) parts.push(<span key={`s${i}`} style={{ color: t.inkMute }}>, </span>);
    if (seg.type === 'fixed') {
      parts.push(<span key={`f${i}`}>{collapseRun(seg.stitches)}</span>);
    } else {
      parts.push(
        <span key={`r${i}`}>
          <span style={{ color: t.brick, fontWeight: 700 }}>(</span>
          {collapseRun(seg.stitches)}
          <span style={{ color: t.brick, fontWeight: 700 }}>)</span>
          <span style={{ color: t.brick, fontWeight: 700 }}> {ruleLong(seg.rule)}</span>
        </span>
      );
    }
  });
  return <div style={{ fontFamily: FontMono, fontSize: 11.5, color: t.inkSoft, lineHeight: 1.5, letterSpacing: '-0.01em' }}>{parts}</div>;
}

// ── The repeat group (brackets + tiles + derived rule badge) ─
function RepeatGroup({ stitches, rule, dark }) {
  const t = pickT(dark);
  return (
    <div style={{ display: 'inline-flex', flexDirection: 'column', alignItems: 'center', gap: 5 }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 3,
        background: dark ? 'rgba(255,122,77,0.07)' : 'rgba(156,61,46,0.05)',
        borderRadius: 9, padding: '2px 4px',
      }}>
        <RepeatBracket side="open" dark={dark}/>
        <div style={{ display: 'flex', gap: 3 }}>
          {stitches.map((id, i) => <StitchTile key={i} id={id} dark={dark} state="inrepeat"/>)}
        </div>
        <RepeatBracket side="close" dark={dark}/>
      </div>
      <div style={{
        display: 'inline-flex', alignItems: 'center', gap: 4, padding: '2px 9px', borderRadius: 999,
        background: dark ? 'rgba(255,122,77,0.16)' : '#FBEFEA',
        border: `1px solid ${dark ? 'rgba(255,122,77,0.3)' : 'rgba(156,61,46,0.2)'}`,
      }}>
        <Icon name="repeat" size={11} color={t.brick} stroke={2}/>
        <span style={{ fontFamily: FontMono, fontSize: 9.5, fontWeight: 700, color: t.brick, letterSpacing: '0.02em' }}>{ruleBadge(rule)}</span>
      </div>
    </div>
  );
}

// ── Body of a segmented (repeating) row — chart tiles + notation ──
function RepeatRowBody({ segments, dark }) {
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8, flexWrap: 'wrap', paddingTop: 14 }}>
        {segments.map((seg, i) =>
          seg.type === 'fixed' ? (
            <div key={i} style={{ display: 'flex', gap: 3 }}>
              {seg.stitches.map((id, j) => <StitchTile key={j} id={id} dark={dark}/>)}
            </div>
          ) : (
            <RepeatGroup key={i} stitches={seg.stitches} rule={seg.rule} dark={dark}/>
          )
        )}
      </div>
      <div style={{ marginTop: 12, paddingTop: 10, borderTop: `1px dashed ${pickT(dark).rule}` }}>
        <RowNotation segments={segments} dark={dark}/>
      </div>
    </div>
  );
}

// ── Shared row toolbar — identical on EVERY row card ─────────
// One repeat icon (the only entry point to marking a repeat), one backspace
// (remove the last stitch), one trash (delete the row). No pencil anywhere.
// The repeat icon is filled when the row already has a repeat, or while the
// row is being marked.
function RowToolbar({ active, dark }) {
  const t = pickT(dark);
  return (
    <div style={{ display: 'flex', gap: 9, alignItems: 'center', flexShrink: 0 }}>
      <span style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        width: 26, height: 26, borderRadius: 8, cursor: 'pointer',
        background: active ? (dark ? 'rgba(255,122,77,0.16)' : '#FBEFEA') : 'transparent',
        border: active ? `1px solid ${dark ? 'rgba(255,122,77,0.34)' : 'rgba(156,61,46,0.24)'}` : '1px solid transparent',
      }} title="Mark a repeat">
        <Icon name="repeat" size={14} color={active ? t.brick : t.inkMute} stroke={2}/>
      </span>
      <Icon name="backspace" size={14} color={t.inkMute}/>
      <Icon name="trash" size={14} color={t.inkMute}/>
    </div>
  );
}

// ── A full row card for a segmented (repeating) row ──────────
function RepeatRowCard({ row, dark }) {
  const t = pickT(dark);
  return (
    <div style={{
      background: t.card,
      border: row.active ? `2px solid ${t.brick}` : `1px solid ${t.rule}`,
      borderRadius: 14, padding: '10px 12px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
          <Icon name="grip" size={14} color={t.inkMute}/>
          <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 13, color: row.active ? t.brick : t.ink, whiteSpace: 'nowrap' }}>{row.label}{row.active && ' ✱'}</div>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 3, flexShrink: 0,
            fontFamily: FontMono, fontSize: 9, fontWeight: 700, letterSpacing: '0.06em',
            color: t.brick, background: dark ? 'rgba(255,122,77,0.14)' : '#FBEFEA',
            border: `1px solid ${dark ? 'rgba(255,122,77,0.28)' : 'rgba(156,61,46,0.18)'}`,
            padding: '1px 6px', borderRadius: 6, textTransform: 'uppercase',
          }}>
            <Icon name="repeat" size={10} color={t.brick} stroke={2.2}/> repeat
          </div>
        </div>
        <RowToolbar active dark={dark}/>
      </div>
      <RepeatRowBody segments={row.segments} dark={dark}/>
    </div>
  );
}

// ── A row in MARKING mode — tap first stitch, then last ──────
// Lives inline in Step 3 (no separate screen). `row.mark` carries:
//   { step:'start'|'end', start:Number|null }
function MarkRowCard({ row, dark }) {
  const t = pickT(dark);
  const stitches = row.stitches || [];
  const { step, start } = row.mark;
  return (
    <div style={{ background: t.card, border: `2px solid ${t.brick}`, borderRadius: 14, padding: '10px 12px' }}>
      {/* header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, marginBottom: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
          <Icon name="grip" size={14} color={t.inkMute}/>
          <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 13, color: t.brick }}>{row.label}</div>
        </div>
        <RowToolbar active dark={dark}/>
      </div>

      {/* inline instruction */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 9, marginBottom: 16,
        background: dark ? 'rgba(255,122,77,0.1)' : '#FBEFEA',
        border: `1px solid ${dark ? 'rgba(255,122,77,0.3)' : 'rgba(156,61,46,0.2)'}`,
        borderRadius: 11, padding: '8px 11px',
      }}>
        <div style={{
          width: 22, height: 22, borderRadius: 999, background: t.brick, color: '#FBF6EC',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: FontDisplay, fontSize: 13, flexShrink: 0,
        }}>{step === 'start' ? '1' : '2'}</div>
        <div style={{ fontFamily: FontBody, fontWeight: 600, fontSize: 13, color: t.ink, letterSpacing: '-0.005em' }}>
          {step === 'start' ? 'Tap the first stitch that repeats' : 'Now tap the last stitch that repeats'}
        </div>
      </div>

      {/* tappable stitches */}
      <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
        {stitches.map((id, i) => {
          let st = 'tap';
          if (i === start) st = 'start';
          else if (step === 'end' && start != null && i < start) st = 'dim';
          return <StitchTile key={i} id={id} dark={dark} state={st}/>;
        })}
      </div>

      {/* hint about edges */}
      <div style={{ fontFamily: FontMono, fontSize: 10, color: t.inkMute, marginTop: 12, lineHeight: 1.5 }}>
        {step === 'start'
          ? 'Stitches before your tap stay as a fixed edge.'
          : 'Stitches after your tap become the “to last N” edge — set automatically.'}
      </div>
    </div>
  );
}

// ── Bottom bar shown in Step 3 while marking (replaces the dock) ──
function MarkInstructionBar({ dark, step }) {
  const t = pickT(dark);
  const text = step === 'start'
    ? 'Tap the first stitch of the repeat'
    : 'Tap the last stitch of the repeat';
  return (
    <div style={{
      position: 'absolute', bottom: 96, left: 0, right: 0,
      background: t.bg, borderTop: `1px solid ${t.rule}`, padding: '12px 20px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <Icon name="repeat" size={16} color={t.brick} stroke={2}/>
        <div style={{ flex: 1, fontFamily: FontBody, fontWeight: 600, fontSize: 13.5, color: t.ink }}>
          <span style={{ fontFamily: FontMono, color: t.brick, fontWeight: 700, marginRight: 6 }}>{step === 'start' ? '1/2' : '2/2'}</span>
          {text}
        </div>
        <button style={{
          background: 'transparent', border: `1px solid ${t.rule}`, color: t.inkSoft,
          borderRadius: 9, padding: '6px 12px', cursor: 'pointer',
          fontFamily: FontBody, fontWeight: 600, fontSize: 12.5,
        }}>Cancel</button>
      </div>
    </div>
  );
}

// Reference data used by the anatomy board.
const RESOLVED_ROW = {
  label: 'Row 1', active: true,
  segments: [
    { type: 'fixed',  stitches: ['p','p'] },
    { type: 'repeat', stitches: ['k','k','p','p'], rule: { kind: 'toLast', n: 2 } },
    { type: 'fixed',  stitches: ['p','p'] },
  ],
};

// ── Anatomy / examples board (non-phone, design-system reference) ──
function RepeatAnatomy({ dark = false }) {
  const t = pickT(dark);
  const examples = [
    { name: '2×2 ribbing', row: RESOLVED_ROW },
    { name: 'Seed border', row: { label: 'Row 5', segments: [{ type: 'fixed', stitches: ['k','k','k'] }, { type: 'repeat', stitches: ['p','k'], rule: { kind: 'toEnd' } }] } },
    { name: 'Lace panel',  row: { label: 'Row 3', segments: [{ type: 'fixed', stitches: ['k'] }, { type: 'repeat', stitches: ['yo','k2tog','k','k'] , rule: { kind: 'toLast', n: 1 } }, { type: 'fixed', stitches: ['k'] }] } },
  ];
  return (
    <div style={{ width: '100%', height: '100%', background: t.bg, padding: 40, boxSizing: 'border-box', fontFamily: FontBody, color: t.ink, overflow: 'auto' }}>
      <div style={{ fontFamily: FontDisplay, fontSize: 30, color: t.brick, letterSpacing: '-0.01em' }}>Repeat anatomy</div>
      <div style={{ fontSize: 14, color: t.inkSoft, marginTop: 6, maxWidth: 560 }}>
        A row reads left to right: <b>fixed edge → the one repeated group → fixed edge</b>. You only mark the first &amp; last stitch of the group; the trailing edge becomes the “to last N sts” automatically.
      </div>

      <div style={{ marginTop: 26, background: t.card, border: `1px solid ${t.rule}`, borderRadius: 18, padding: 26, maxWidth: 620 }}>
        <RepeatRowBody segments={RESOLVED_ROW.segments} dark={dark}/>
        <div style={{ display: 'flex', gap: 24, marginTop: 22, flexWrap: 'wrap' }}>
          <Annot color={t.mustard} title="Fixed edge" body="The p2 you typed first — worked once."/>
          <Annot color={t.brick} title="Repeat group" body="Marked first→last stitch; worked again & again."/>
          <Annot color={t.mustard} title="Last edge" body="The trailing p2 = “to last 2 sts”, set for you."/>
        </div>
      </div>

      <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute, letterSpacing: '0.14em', textTransform: 'uppercase', margin: '30px 0 12px' }}>More shapes</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, maxWidth: 620 }}>
        {examples.map(ex => (
          <div key={ex.name} style={{ background: t.card, border: `1px solid ${t.rule}`, borderRadius: 16, padding: '14px 18px' }}>
            <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 14, color: t.ink, marginBottom: 2 }}>{ex.name}</div>
            <RepeatRowBody segments={ex.row.segments} dark={dark}/>
          </div>
        ))}
      </div>
    </div>
  );
}

function Annot({ color, title, body }) {
  return (
    <div style={{ display: 'flex', gap: 9, maxWidth: 175 }}>
      <div style={{ width: 10, height: 10, borderRadius: 3, background: color, marginTop: 4, flexShrink: 0 }}/>
      <div>
        <div style={{ fontFamily: '"DM Sans", sans-serif', fontWeight: 700, fontSize: 13 }}>{title}</div>
        <div style={{ fontSize: 12, opacity: 0.7, marginTop: 1, lineHeight: 1.4 }}>{body}</div>
      </div>
    </div>
  );
}
