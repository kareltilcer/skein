// Home + empty state for YarnLog.

// Projects are made of PARTS (back, sleeves, etc.). Knitters move between them freely —
// there's no fixed order or "done" state, so we just list the parts, not progress.
const SAMPLE_PROJECTS = [
  { id:'cardigan', name:'Granny Cardigan', sub:'Bulky merino · 4.5mm', color:'brick',   tag:'In progress',
    parts:['Back', 'Left front', 'Right front', 'Sleeves', 'Button band'] },
  { id:'socks',    name:'Saturday Socks',  sub:'Sport · 2.25mm DPN',  color:'mustard', tag:'In progress',
    parts:['Cuff', 'Leg', 'Heel', 'Foot', 'Toe'] },
  { id:'blanket',  name:"Hank's Blanket",  sub:'Chunky · 8mm hook',    color:'forest',  tag:'Just started',
    parts:['Body', 'Border'] },
  { id:'beanie',   name:'Pumpkin Beanie',  sub:'Worsted · 5mm',        color:'ink',     tag:'Finished',
    parts:['Brim', 'Body', 'Crown'] },
];

// Small yarn-ball thumb for a card.
function YarnThumb({ color, size = 64 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" style={{ display: 'block' }}>
      <circle cx="32" cy="32" r="24" fill={color}/>
      <path d="M12 28 Q 32 22 52 28"  stroke="rgba(255,255,255,0.45)" strokeWidth="2.2" fill="none" strokeLinecap="round"/>
      <path d="M10 36 Q 32 30 54 36"  stroke="rgba(255,255,255,0.45)" strokeWidth="2.2" fill="none" strokeLinecap="round"/>
      <path d="M14 44 Q 32 38 50 44"  stroke="rgba(255,255,255,0.45)" strokeWidth="2.2" fill="none" strokeLinecap="round"/>
      <path d="M18 20 Q 32 26 46 20"  stroke="rgba(255,255,255,0.45)" strokeWidth="2.2" fill="none" strokeLinecap="round"/>
      <path d="M52 28 Q 60 26 58 18"  stroke={color} strokeWidth="2.4" fill="none" strokeLinecap="round"/>
      <circle cx="58" cy="17" r="1.8" fill={color}/>
    </svg>
  );
}

function ProjectCard({ p, dark = false }) {
  const t = pickT(dark);
  const map = { brick: t.brick, mustard: t.mustard, forest: t.forest, ink: t.ink };
  const c = map[p.color] || t.brick;
  const done = p.tag === 'Finished';
  const parts = p.parts || [];
  return (
    <div style={{
      background: t.card, borderRadius: 22, padding: 16,
      border: `1px solid ${t.rule}`, display: 'flex', gap: 14, alignItems: 'center',
      opacity: done ? 0.7 : 1,
    }}>
      <div style={{
        width: 64, height: 64, borderRadius: 16, background: t.cream2,
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}>
        <YarnThumb color={c} size={56}/>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
          <div style={{ fontFamily: FontBody, fontWeight: 700, fontSize: 17, color: t.ink, letterSpacing: '-0.01em', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</div>
          {done && <div style={{
            fontSize: 10, fontFamily: FontMono, fontWeight: 600, color: t.forest,
            border: `1px solid ${t.forest}`, padding: '2px 6px', borderRadius: 6, letterSpacing: '0.04em', textTransform: 'uppercase',
          }}>done</div>}
        </div>
        <div style={{ fontSize: 12.5, color: t.inkMute, marginTop: 2 }}>{p.sub}</div>
        {/* parts — just the pieces in this project; knitters move between them freely */}
        <div style={{ marginTop: 10, display: 'flex', flexWrap: 'wrap', gap: 5, alignItems: 'center' }}>
          <span style={{ fontFamily: FontMono, fontSize: 10.5, letterSpacing: '0.08em', textTransform: 'uppercase', color: t.inkMute, marginRight: 2 }}>
            {parts.length} {parts.length === 1 ? 'part' : 'parts'}
          </span>
          {parts.map((name, i) => (
            <span key={i} style={{
              fontFamily: FontBody, fontSize: 11.5, color: t.inkSoft,
              background: t.cream2, borderRadius: 7, padding: '3px 8px', whiteSpace: 'nowrap',
            }}>{name}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

// HOME — list of projects.
function HomeScreen({ dark = false, synced = false }) {
  const t = pickT(dark);
  const [finishedOpen, setFinishedOpen] = React.useState(false);
  const active = SAMPLE_PROJECTS.filter(p => p.tag !== 'Finished');
  const finished = SAMPLE_PROJECTS.filter(p => p.tag === 'Finished');
  return (
    <Phone dark={dark}>
      <div style={{ flex: 1, position: 'relative', display: 'flex', flexDirection: 'column' }}>
      <AppBar
        big
        title="Hey, Marigold"
        sub={`${active.length} on the needles${finished.length ? ` · ${finished.length} in the basket` : ''}.`}
        dark={dark}
        leading={<SkeinLogo size={32} fg={t.brick} accent={t.mustard}/>}
        trailing={
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            {synced && <SyncChip dark={dark}/>}
          </div>
        }
      />
      <div style={{ flex: 1, overflow: 'auto', padding: '18px 20px 110px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {/* big primary CTA */}
        <button style={{
          background: `linear-gradient(180deg, ${t.brick} 0%, ${t.brickDk} 100%)`,
          color: '#FBF6EC', borderRadius: 22, padding: '16px 18px',
          border: 'none', textAlign: 'left', cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 14,
          boxShadow: `0 10px 24px -10px ${t.brick}`,
        }}>
          <div style={{
            width: 48, height: 48, borderRadius: 14, background: 'rgba(255,255,255,0.16)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Icon name="plus" size={24} color="#FBF6EC"/>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: FontDisplay, fontSize: 22, letterSpacing: '-0.01em' }}>Cast on a project</div>
            <div style={{ fontSize: 12.5, opacity: 0.85, marginTop: 2 }}>Build your pattern step by step.</div>
          </div>
          <Icon name="chevR" size={20} color="#FBF6EC"/>
        </button>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginTop: 8 }}>
          <div style={{ fontFamily: FontMono, fontSize: 11, letterSpacing: '0.16em', textTransform: 'uppercase', color: t.inkMute }}>On the needles · {active.length}</div>
          <div style={{ fontFamily: FontMono, fontSize: 11, color: t.inkMute }}>Recent</div>
        </div>

        {active.map(p => <ProjectCard key={p.id} p={p} dark={dark}/>)}

        {/* Finished — collapsible */}
        {finished.length > 0 && (
          <>
            <button onClick={() => setFinishedOpen(o => !o)} style={{
              marginTop: 8, padding: '12px 14px', background: t.card, border: `1px solid ${t.rule}`,
              borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              cursor: 'pointer', color: t.ink, fontFamily: FontBody,
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{
                  width: 28, height: 28, borderRadius: 8, background: t.cream2,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <Icon name="check" size={16} color={t.forest} stroke={2.4}/>
                </div>
                <div style={{ fontFamily: FontMono, fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase', color: t.inkSoft }}>
                  Finished · {finished.length}
                </div>
              </div>
              <Icon name="chevDown" size={16} color={t.inkMute} stroke={2.4}/>
            </button>
            {finishedOpen && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 4 }}>
                {finished.map(p => <ProjectCard key={p.id} p={p} dark={dark}/>)}
              </div>
            )}
          </>
        )}
      </div>
      <TabBar active="home" dark={dark}/>
    </div>
    </Phone>
  );
}

// Sync indicator chip — shown in the home AppBar when an account is configured.
function SyncChip({ dark }) {
  const t = pickT(dark);
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '5px 10px', borderRadius: 999,
      background: dark ? 'rgba(136,185,140,0.12)' : 'rgba(63,107,74,0.10)',
      border: `1px solid ${t.forest}33`, color: t.forest,
      fontFamily: FontMono, fontSize: 10, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase',
      height: 28,
    }}>
      <div style={{ width: 6, height: 6, borderRadius: 3, background: t.forest, boxShadow: `0 0 0 3px ${t.forest}22` }}/>
      synced
    </div>
  );
}

// Language strings for the welcome screen — 8 languages.
// (Tagline kept in English everywhere — it's the brand voice.)
const LANGUAGES = [
  { code:'en', flag:'🇺🇸', name:'English',    welcome:'Welcome to YarnLog.', body:"Build a pattern, hit start, and we'll keep your place — row by row, repeat by repeat. Both hands free for the needles.",            cta:'Cast on first project',  alt:'Peek at the library',     note:'no account needed · ever' },
  { code:'es', flag:'🇪🇸', name:'Español',    welcome:'Bienvenida a YarnLog.',body:'Crea un patrón, dale a empezar, y nosotros guardamos tu lugar — fila por fila, repetición por repetición. Manos libres para las agujas.', cta:'Empezar primer proyecto', alt:'Ver la biblioteca',       note:'sin cuenta · nunca' },
  { code:'fr', flag:'🇫🇷', name:'Français',   welcome:'Bienvenue sur YarnLog.',body:'Crée un motif, lance la séance, et nous gardons ta place — rang par rang, répétition par répétition. Mains libres pour les aiguilles.',     cta:'Démarrer un projet',     alt:'Voir la bibliothèque',    note:'aucun compte requis · jamais' },
  { code:'de', flag:'🇩🇪', name:'Deutsch',    welcome:'Willkommen bei YarnLog.',body:'Bau ein Muster, leg los, und wir merken uns deine Stelle — Reihe für Reihe, Wiederholung für Wiederholung. Hände frei für die Nadeln.',     cta:'Erstes Projekt starten', alt:'Bibliothek ansehen',      note:'kein konto nötig · niemals' },
  { code:'it', flag:'🇮🇹', name:'Italiano',   welcome:'Benvenuta in YarnLog.', body:'Crea un motivo, parti, e teniamo noi il segno — riga per riga, ripetizione per ripetizione. Le mani restano libere.',                       cta:'Avvia primo progetto',   alt:'Sfoglia la libreria',     note:'nessun account · mai' },
  { code:'pt', flag:'🇵🇹', name:'Português',  welcome:'Olá, é o YarnLog.',     body:'Cria um padrão, começa, e nós guardamos o teu lugar — linha a linha, repetição a repetição. Mãos livres para as agulhas.',                  cta:'Começar projeto',        alt:'Ver biblioteca',          note:'sem conta · nunca' },
  { code:'ja', flag:'🇯🇵', name:'日本語',      welcome:'YarnLogへようこそ。',     body:'パターンを作って、始めるだけ。あとは段ごと・くり返しごとに進行を覚えています。両手は針に集中できます。',                                                                                          cta:'最初のプロジェクト',     alt:'ライブラリを見る',         note:'アカウント不要・ずっと' },
  { code:'nl', flag:'🇳🇱', name:'Nederlands', welcome:'Welkom bij YarnLog.',   body:'Bouw een patroon, druk op start, en wij houden je plek bij — rij voor rij, herhaling voor herhaling. Handen vrij voor de naalden.',         cta:'Eerste project starten', alt:'Bekijk de bibliotheek',   note:'geen account nodig · ooit' },
];

// Compact language pill — shows current flag + code.
function LangPill({ lang, onClick, dark = false }) {
  const t = pickT(dark);
  return (
    <button onClick={onClick} style={{
      background: t.card, border: `1px solid ${t.rule}`, borderRadius: 999,
      padding: '6px 10px 6px 8px', display: 'inline-flex', alignItems: 'center', gap: 6,
      cursor: 'pointer', height: 36, color: t.ink,
    }}>
      <Icon name="globe" size={14} color={t.inkSoft}/>
      <span style={{ fontFamily: FontMono, fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase' }}>{lang.code}</span>
      <Icon name="chevDown" size={12} color={t.inkMute}/>
    </button>
  );
}

// Popover with language options.
function LangPopover({ current, onPick, onClose, dark = false }) {
  const t = pickT(dark);
  return (
    <>
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, background: 'rgba(43,24,16,0.25)',
        backdropFilter: 'blur(2px)', zIndex: 40,
      }}/>
      <div style={{
        position: 'absolute', top: 92, right: 16, zIndex: 50,
        background: t.card, borderRadius: 18, padding: 8,
        border: `1px solid ${t.rule}`, boxShadow: '0 14px 36px -8px rgba(43,24,16,0.25)',
        minWidth: 200, maxHeight: 380, overflow: 'auto',
      }}>
        <div style={{
          fontFamily: FontMono, fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase',
          color: t.inkMute, padding: '6px 10px 8px',
        }}>Choose your language</div>
        {LANGUAGES.map(l => {
          const active = l.code === current;
          return (
            <button key={l.code} onClick={() => onPick(l.code)} style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 10px', borderRadius: 10, cursor: 'pointer', textAlign: 'left',
              background: active ? t.cream2 : 'transparent', border: 'none',
              color: t.ink, fontFamily: FontBody,
            }}>
              <span style={{
                fontFamily: FontMono, fontSize: 10, fontWeight: 700, letterSpacing: '0.06em',
                textTransform: 'uppercase', color: active ? t.brick : t.inkMute, minWidth: 22,
              }}>{l.code}</span>
              <span style={{ flex: 1, fontSize: 14, fontWeight: active ? 700 : 500 }}>{l.name}</span>
              {active && <Icon name="check" size={16} color={t.brick} stroke={2.6}/>}
            </button>
          );
        })}
        <div style={{
          padding: '8px 10px 6px', fontFamily: FontMono, fontSize: 10, color: t.inkMute,
          letterSpacing: '0.05em', borderTop: `1px solid ${t.rule}`, marginTop: 4,
        }}>
          You can switch anytime in Settings.
        </div>
      </div>
    </>
  );
}

// EMPTY STATE — first-time user. Includes language switcher.
function EmptyScreen({ dark = false }) {
  const t = pickT(dark);
  const [code, setCode] = React.useState('en');
  const [open, setOpen] = React.useState(false);
  const L = LANGUAGES.find(l => l.code === code) || LANGUAGES[0];
  return (
    <Phone dark={dark}>
      <div style={{ flex: 1, position: 'relative', display: 'flex', flexDirection: 'column' }}>
      <AppBar
        title=""
        dark={dark}
        leading={<LangPill lang={L} onClick={() => setOpen(o => !o)} dark={dark}/>}
        trailing={<IconBtn name="settings" dark={dark}/>}
      />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 32px 100px' }}>
        <div style={{ position: 'relative', marginBottom: 28 }}>
          <SkeinLogo size={120} fg={t.brick} accent={t.mustard}/>
          {/* little stitches surrounding */}
          <div style={{ position: 'absolute', top: -10, left: -22, fontFamily: FontMono, fontSize: 10, color: t.mustardDk, transform: 'rotate(-12deg)' }}>* * *</div>
          <div style={{ position: 'absolute', bottom: -8, right: -28, fontFamily: FontMono, fontSize: 10, color: t.forest, transform: 'rotate(8deg)' }}>// // //</div>
        </div>

        <div key={'w-'+code} style={{ fontFamily: FontDisplay, fontSize: 44, color: t.brick, lineHeight: 0.95, letterSpacing: '-0.02em', textAlign: 'center', animation: 'skeinFade 280ms ease' }}>
          {L.welcome}
        </div>
        <div style={{ fontFamily: FontDisplay, fontSize: 16, color: t.mustardDk, marginTop: 12, letterSpacing: '0.04em' }}>
          stitch happens.
        </div>
        <div key={'b-'+code} style={{ fontSize: 15, color: t.inkSoft, textAlign: 'center', marginTop: 18, lineHeight: 1.45, maxWidth: 300, animation: 'skeinFade 280ms ease 60ms backwards' }}>
          {L.body}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 36, width: '100%' }}>
          <Btn variant="primary" size="lg" full icon="plus" dark={dark}>{L.cta}</Btn>
          <Btn variant="ghost"   size="md" full icon="book" dark={dark}>{L.alt}</Btn>
        </div>

        <div style={{
          marginTop: 32, fontSize: 12, fontFamily: FontMono, color: t.inkMute,
          letterSpacing: '0.1em', textTransform: 'uppercase',
        }}>
          {L.note}
        </div>
      </div>

      {open && <LangPopover current={code} onPick={(c) => { setCode(c); setOpen(false); }} onClose={() => setOpen(false)} dark={dark}/>}
      <style>{`@keyframes skeinFade { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: none; } }`}</style>
    </div>
    </Phone>
  );
}

Object.assign(window, { HomeScreen, EmptyScreen, ProjectCard, YarnThumb });
